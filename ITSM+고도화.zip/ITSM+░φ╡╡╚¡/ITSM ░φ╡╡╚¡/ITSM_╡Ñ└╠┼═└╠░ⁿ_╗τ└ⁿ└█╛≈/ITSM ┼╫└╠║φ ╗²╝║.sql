
--------------------------------------------------------
--  ������ ������ - ������-4��-20-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ACL_AUDIT_LOG
--------------------------------------------------------

  CREATE TABLE "ITSM"."ACL_AUDIT_LOG" 
   (	"AUDIT_ID" NUMBER(*,0), 
	"LOGIN_ID" NUMBER(*,0), 
	"LOG_DATE" TIMESTAMP (6), 
	"USER_ID" VARCHAR2(255 BYTE), 
	"USER_NAME" VARCHAR2(255 BYTE), 
	"ROLE_ID" NUMBER(*,0), 
	"ROLE_NAME" VARCHAR2(255 BYTE), 
	"AUTH" VARCHAR2(255 BYTE), 
	"PERMISSION" VARCHAR2(255 BYTE), 
	"OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"IS_ROLE_OBJECT" NUMBER(1,0), 
	"OBJECT_ID" NUMBER(*,0), 
	"IS_LIVE_OBJECT" NUMBER(1,0), 
	"DEVICE_ID" NUMBER(*,0), 
	"OPERATION" VARCHAR2(4000 BYTE), 
	"IS_GRANTED" NUMBER(1,0), 
	"IS_SUCCESS" NUMBER(1,0), 
	"MESSAGE" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ACL_AUTH
--------------------------------------------------------

  CREATE TABLE "ITSM"."ACL_AUTH" 
   (	"AUTH" VARCHAR2(255 BYTE), 
	"IS_ENABLE_EXECUTE" NUMBER(1,0), 
	"DESCRIPTION" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ACL_LOGIN_LOG
--------------------------------------------------------

  CREATE TABLE "ITSM"."ACL_LOGIN_LOG" 
   (	"LOGIN_ID" NUMBER(*,0), 
	"USER_ID" VARCHAR2(255 BYTE), 
	"USER_NAME" VARCHAR2(255 BYTE), 
	"MANAGER_ID" VARCHAR2(255 BYTE), 
	"LOGIN_DATE" TIMESTAMP (6), 
	"LOGOUT_DATE" TIMESTAMP (6), 
	"USER_IP" VARCHAR2(255 BYTE), 
	"IS_LOGIN_SUCCESS" NUMBER(1,0), 
	"MESSAGE" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ACL_PERMISSION
--------------------------------------------------------

  CREATE TABLE "ITSM"."ACL_PERMISSION" 
   (	"PERMISSION_ID" NUMBER(*,0), 
	"ROLE_ID" NUMBER(*,0), 
	"AUTH" VARCHAR2(255 BYTE), 
	"IS_READABLE" NUMBER(1,0), 
	"IS_WRITABLE" NUMBER(1,0), 
	"IS_DELETABLE" NUMBER(1,0), 
	"IS_EXECUTABLE" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ACL_ROLE
--------------------------------------------------------

  CREATE TABLE "ITSM"."ACL_ROLE" 
   (	"ROLE_ID" NUMBER(*,0), 
	"ROLE_NAME" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"IS_SYSTEM_RESERVED" NUMBER(1,0), 
	"REG_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ACL_ROLE_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."ACL_ROLE_OBJECT" 
   (	"OBJECT_ID" NUMBER(*,0), 
	"ROLE_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ACL_USER
--------------------------------------------------------

  CREATE TABLE "ITSM"."ACL_USER" 
   (	"USER_ID" VARCHAR2(255 BYTE), 
	"USER_NAME" VARCHAR2(255 BYTE), 
	"PASSWORD" VARCHAR2(255 BYTE), 
	"EMAIL" VARCHAR2(255 BYTE), 
	"MOBILE_PHONE" VARCHAR2(255 BYTE), 
	"DEPT_NAME" VARCHAR2(255 BYTE), 
	"CORPORATION" VARCHAR2(255 BYTE), 
	"PWD_CHANGE_CYCLE" NUMBER(*,0), 
	"LAST_PWD_CHANGED" TIMESTAMP (6), 
	"IS_PWD_EXPIRED" NUMBER(1,0), 
	"FAILED_LOGINS" NUMBER(*,0), 
	"LAST_FAILED_LOGIN_DATE" TIMESTAMP (6), 
	"IS_BLOCKED" NUMBER(1,0), 
	"IS_SYSTEM_RESERVED" NUMBER(1,0), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"REG_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ACL_USER_PROPERTY
--------------------------------------------------------

  CREATE TABLE "ITSM"."ACL_USER_PROPERTY" 
   (	"PROPERTY_ID" NUMBER(*,0), 
	"USER_ID" VARCHAR2(255 BYTE), 
	"PROPERTY_KEY" VARCHAR2(255 BYTE), 
	"PROPERTY_VALUE" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ACL_USER_ROLE
--------------------------------------------------------

  CREATE TABLE "ITSM"."ACL_USER_ROLE" 
   (	"USER_ID" VARCHAR2(255 BYTE), 
	"ROLE_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ALARM
--------------------------------------------------------

  CREATE TABLE "ITSM"."ALARM" 
   (	"ALARM_ID" NUMBER(10,0), 
	"CONT_ALARM_ID" NUMBER(10,0), 
	"MANAGED_OBJECT_ID" NUMBER(10,0), 
	"ATTRIBUTE_ID" NUMBER(10,0), 
	"ALARM_DATE" TIMESTAMP (6), 
	"SEVERITY" NUMBER(10,0), 
	"PREVIOUS_SEVERITY" NUMBER(10,0), 
	"ALARM_MESSAGE" VARCHAR2(4000 CHAR), 
	"ATTRIBUTE_VALUE" VARCHAR2(4000 CHAR), 
	"ATTRIBUTE_NAME" VARCHAR2(255 CHAR), 
	"THRESHOLD_ID" NUMBER(10,0), 
	"LIVE_OBJECT_NAME" VARCHAR2(4000 CHAR), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 CHAR), 
	"ACK_USER_ID" VARCHAR2(255 CHAR), 
	"ACK_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ALARM_ACTIVE
--------------------------------------------------------

  CREATE TABLE "ITSM"."ALARM_ACTIVE" 
   (	"ATTRIBUTE_ID" NUMBER(10,0), 
	"ALARM_ID" NUMBER(10,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ALARM_BOX
--------------------------------------------------------

  CREATE TABLE "ITSM"."ALARM_BOX" 
   (	"ALARM_ID" VARCHAR2(20 BYTE), 
	"TITLE" VARCHAR2(200 BYTE), 
	"CONTENT" CLOB, 
	"TARGET_USER_ID" VARCHAR2(50 BYTE), 
	"READ_YN" VARCHAR2(1 BYTE), 
	"PRIORITY" NUMBER, 
	"UPD_USER_ID" VARCHAR2(50 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ALARM_LAST_VALUE
--------------------------------------------------------

  CREATE TABLE "ITSM"."ALARM_LAST_VALUE" 
   (	"LAST_VALUE_ID" NUMBER(19,0), 
	"ATTRIBUTE_ID" NUMBER(10,0), 
	"POLLING_ID" NUMBER(19,0), 
	"NUMERIC_VALUE" FLOAT(126), 
	"STRING_VALUE" VARCHAR2(4000 CHAR), 
	"IS_NUMERIC_TYPE" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ALARM_NOTE
--------------------------------------------------------

  CREATE TABLE "ITSM"."ALARM_NOTE" 
   (	"NOTE_ID" NUMBER(10,0), 
	"ALARM_ID" NUMBER(10,0), 
	"ATTRIBUTE_ID" NUMBER(10,0), 
	"USER_ID" VARCHAR2(255 CHAR), 
	"MESSAGE" VARCHAR2(4000 CHAR), 
	"NOTE_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_AD_DIF_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_AD_DIF_INFO" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"EMS_ATTR_CNT" VARCHAR2(200 BYTE), 
	"EMS_INST_CNT" VARCHAR2(200 BYTE), 
	"DCA_ATTR_CNT" VARCHAR2(200 BYTE), 
	"DCA_INST_CNT" VARCHAR2(200 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_APP
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_APP" 
   (	"APP_TYPE" VARCHAR2(10 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"APP_DESC" VARCHAR2(1000 BYTE), 
	"INTRO_METHOD" VARCHAR2(50 BYTE), 
	"INTRO_METHOD_DESC" VARCHAR2(500 BYTE), 
	"APP_STATE" VARCHAR2(10 BYTE), 
	"DISCARD_DESC" VARCHAR2(100 BYTE), 
	"IMPROVE_NM" VARCHAR2(400 BYTE), 
	"CHANNEL_YN" VARCHAR2(5 BYTE), 
	"CON_ORG" VARCHAR2(300 BYTE), 
	"OPER_MAIN_NM" VARCHAR2(300 BYTE), 
	"CONN_URL" VARCHAR2(200 BYTE), 
	"DELVEL_DT" VARCHAR2(30 BYTE), 
	"UPGRADE_DT" VARCHAR2(30 BYTE), 
	"LANGUAGE" VARCHAR2(30 BYTE), 
	"LANGUAGE_DESC" VARCHAR2(100 BYTE), 
	"FRM_CNT" VARCHAR2(5 BYTE), 
	"FRM_NM" VARCHAR2(150 BYTE), 
	"FRM_DESC" VARCHAR2(200 BYTE), 
	"REL_LAW" VARCHAR2(300 BYTE), 
	"BEGIN_COST" VARCHAR2(50 BYTE), 
	"ADD_COST" VARCHAR2(50 BYTE), 
	"NOW_MAINT_COST" VARCHAR2(50 BYTE), 
	"ACC_MAIN_COST" VARCHAR2(50 BYTE), 
	"BEGIN_YEAR_COST" VARCHAR2(50 BYTE), 
	"BEGIN_TWO_MAINT_COST" VARCHAR2(50 BYTE), 
	"BEGIN_THREE_MAINT_COST" VARCHAR2(50 BYTE), 
	"LATE_ONE_MAINT_COST" VARCHAR2(50 BYTE), 
	"LATE_TWO_MAINT_COST" VARCHAR2(50 BYTE), 
	"LATE_THREE_MAINT_COST" VARCHAR2(50 BYTE), 
	"OPER_COST" VARCHAR2(50 BYTE), 
	"BEGIN_ONE_OPER_COST" VARCHAR2(50 BYTE), 
	"BEGIN_TWO_OPER_COST" VARCHAR2(50 BYTE), 
	"BEGIN_THREE_OPER_COST" VARCHAR2(50 BYTE), 
	"LATE_ONE_OPER_COST" VARCHAR2(50 BYTE), 
	"LATE_TWO_OPER_COST" VARCHAR2(50 BYTE), 
	"LATE_THREE_OPER_COST" VARCHAR2(50 BYTE), 
	"APP_PURPOSE" VARCHAR2(1000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_APP_TMP
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_APP_TMP" 
   (	"APP_TYPE" VARCHAR2(10 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"APP_DESC" VARCHAR2(1000 BYTE), 
	"INTRO_METHOD" VARCHAR2(50 BYTE), 
	"INTRO_METHOD_DESC" VARCHAR2(500 BYTE), 
	"APP_STATE" VARCHAR2(10 BYTE), 
	"DISCARD_DESC" VARCHAR2(100 BYTE), 
	"IMPROVE_NM" VARCHAR2(400 BYTE), 
	"CHANNEL_YN" VARCHAR2(5 BYTE), 
	"CON_ORG" VARCHAR2(300 BYTE), 
	"OPER_MAIN_NM" VARCHAR2(300 BYTE), 
	"CONN_URL" VARCHAR2(200 BYTE), 
	"DELVEL_DT" VARCHAR2(30 BYTE), 
	"UPGRADE_DT" VARCHAR2(30 BYTE), 
	"LANGUAGE" VARCHAR2(30 BYTE), 
	"LANGUAGE_DESC" VARCHAR2(100 BYTE), 
	"FRM_CNT" VARCHAR2(5 BYTE), 
	"FRM_NM" VARCHAR2(150 BYTE), 
	"FRM_DESC" VARCHAR2(200 BYTE), 
	"REL_LAW" VARCHAR2(300 BYTE), 
	"BEGIN_COST" VARCHAR2(50 BYTE), 
	"ADD_COST" VARCHAR2(50 BYTE), 
	"NOW_MAINT_COST" VARCHAR2(50 BYTE), 
	"ACC_MAIN_COST" VARCHAR2(50 BYTE), 
	"BEGIN_YEAR_COST" VARCHAR2(50 BYTE), 
	"BEGIN_TWO_MAINT_COST" VARCHAR2(50 BYTE), 
	"BEGIN_THREE_MAINT_COST" VARCHAR2(50 BYTE), 
	"LATE_ONE_MAINT_COST" VARCHAR2(50 BYTE), 
	"LATE_TWO_MAINT_COST" VARCHAR2(50 BYTE), 
	"LATE_THREE_MAINT_COST" VARCHAR2(50 BYTE), 
	"OPER_COST" VARCHAR2(50 BYTE), 
	"BEGIN_ONE_OPER_COST" VARCHAR2(50 BYTE), 
	"BEGIN_TWO_OPER_COST" VARCHAR2(50 BYTE), 
	"BEGIN_THREE_OPER_COST" VARCHAR2(50 BYTE), 
	"LATE_ONE_OPER_COST" VARCHAR2(50 BYTE), 
	"LATE_TWO_OPER_COST" VARCHAR2(50 BYTE), 
	"LATE_THREE_OPER_COST" VARCHAR2(50 BYTE), 
	"APP_PURPOSE" VARCHAR2(1000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ASSET
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ASSET" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"MODEL_NM" VARCHAR2(300 BYTE), 
	"SERIAL_NO" VARCHAR2(50 BYTE), 
	"INTRO_COST" NUMBER, 
	"INTRO_DT" DATE, 
	"SERVICE_LIFE" VARCHAR2(4 BYTE), 
	"DOMESTIC_YN" CHAR(5 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"SUPPLY_ID" VARCHAR2(20 BYTE), 
	"LOCATION" VARCHAR2(1000 BYTE), 
	"ASSET_STATE" VARCHAR2(20 BYTE), 
	"ETC_DESC" VARCHAR2(4000 BYTE), 
	"LOCATION_DESC" VARCHAR2(100 BYTE), 
	"VENDOR_ETC" VARCHAR2(50 BYTE), 
	"OPER_USER_NM" VARCHAR2(20 BYTE), 
	"USE_USER_NM" VARCHAR2(20 BYTE), 
	"DUAL_YN" VARCHAR2(1 BYTE), 
	"VENDOR_ID" VARCHAR2(300 BYTE), 
	"ASSET_CUST_ID" VARCHAR2(40 BYTE), 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"DIV_HIERACHY" CHAR(1 BYTE), 
	"ASSET_ID_HI" VARCHAR2(20 BYTE), 
	"OPER_CUST_ID" VARCHAR2(20 BYTE), 
	"USE_CUST_ID" VARCHAR2(20 BYTE), 
	"VENDOR_DESC" VARCHAR2(100 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ASSET_CHG_HIS
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ASSET_CHG_HIS" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"SEQ" NUMBER DEFAULT 1, 
	"CHG_HIS_SEQ" NUMBER, 
	"CHG_TABLE" VARCHAR2(50 BYTE), 
	"CHG_COLUMN_ID" VARCHAR2(50 BYTE), 
	"CHG_COLUMN_NM" VARCHAR2(100 BYTE), 
	"CHG_PREV_VALUE" VARCHAR2(4000 BYTE), 
	"CHG_YN" CHAR(1 BYTE), 
	"CODE_YN" CHAR(1 BYTE), 
	"CHG_CUD" CHAR(1 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ASSET_CHG_HIS_SEQ
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ASSET_CHG_HIS_SEQ" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_SEQ" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ASSET_TEST
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ASSET_TEST" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"MODEL_NM" VARCHAR2(200 BYTE), 
	"SERIAL_NO" VARCHAR2(50 BYTE), 
	"ASSET_STATE" VARCHAR2(20 BYTE), 
	"INTRO_COST" NUMBER, 
	"INTRO_DT" DATE, 
	"SERVICE_LIFE" VARCHAR2(4 BYTE), 
	"DOMESTIC_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"SUPPLY_ID" VARCHAR2(20 BYTE), 
	"LOCATION" VARCHAR2(1000 BYTE), 
	"ASSET_CUST_ID" VARCHAR2(40 BYTE), 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ASSET_TO_SERVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ASSET_TO_SERVICE" 
   (	"SERVICE_ID" VARCHAR2(20 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ATTRIBUTE
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ATTRIBUTE" 
   (	"COL_ID" VARCHAR2(400 BYTE), 
	"COL_NAME" VARCHAR2(400 BYTE), 
	"COL_LEN" NUMBER, 
	"COL_TYPE" VARCHAR2(20 BYTE), 
	"BASE_COL_YN" VARCHAR2(4 BYTE), 
	"HTML_TYPE" VARCHAR2(20 BYTE), 
	"PK_YN" CHAR(1 BYTE), 
	"SYS_CODE" VARCHAR2(100 BYTE), 
	"CONST_TYPE" VARCHAR2(50 BYTE), 
	"UNIT" VARCHAR2(10 BYTE), 
	"POPUP_CODE" VARCHAR2(400 BYTE), 
	"MAX_VALUE" NUMBER, 
	"COL_DESC" VARCHAR2(4000 BYTE), 
	"HISTORY_YN" CHAR(1 BYTE), 
	"NOT_NULL" CHAR(1 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"DATE_TYPE" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"DISPLAY_TYPE" CHAR(1 BYTE), 
	"COMBO_TEXT" VARCHAR2(40 BYTE), 
	"EMS_YN" CHAR(1 BYTE), 
	"DEFAULT_VAL" VARCHAR2(20 BYTE), 
	"POPUP_SHOW_TYPE" VARCHAR2(10 BYTE), 
	"EMS_COL_ID" VARCHAR2(40 BYTE), 
	"DCA_YN" CHAR(1 BYTE), 
	"DCA_COL_ID" VARCHAR2(40 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ATTRIBUTE_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ATTRIBUTE_BACK" 
   (	"COL_ID" VARCHAR2(400 BYTE), 
	"COL_NAME" VARCHAR2(400 BYTE), 
	"COL_LEN" NUMBER, 
	"COL_TYPE" VARCHAR2(20 BYTE), 
	"BASE_COL_YN" VARCHAR2(4 BYTE), 
	"HTML_TYPE" VARCHAR2(20 BYTE), 
	"PK_YN" CHAR(1 BYTE), 
	"SYS_CODE" VARCHAR2(100 BYTE), 
	"CONST_TYPE" VARCHAR2(50 BYTE), 
	"UNIT" VARCHAR2(10 BYTE), 
	"POPUP_CODE" VARCHAR2(400 BYTE), 
	"MAX_VALUE" NUMBER, 
	"COL_DESC" VARCHAR2(4000 BYTE), 
	"HISTORY_YN" CHAR(1 BYTE), 
	"NOT_NULL" CHAR(1 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"DATE_TYPE" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"DISPLAY_TYPE" CHAR(1 BYTE), 
	"COMBO_TEXT" VARCHAR2(40 BYTE), 
	"EMS_YN" CHAR(1 BYTE), 
	"DEFAULT_VAL" VARCHAR2(20 BYTE), 
	"POPUP_SHOW_TYPE" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ATTR_USER_GRP_MAPPING
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ATTR_USER_GRP_MAPPING" 
   (	"COL_COMP_ID" VARCHAR2(400 BYTE), 
	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"AUTH_TYPE" CHAR(1 BYTE), 
	"ENTITY_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_AUTO_DISCOVERY_TABLE
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_AUTO_DISCOVERY_TABLE" 
   (	"AD_TABLE" VARCHAR2(40 BYTE), 
	"AD_TABLE_NM" VARCHAR2(100 BYTE), 
	"AD_TYPE" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"SORT" NUMBER, 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"AD_TARGET" VARCHAR2(40 BYTE), 
	"AD_DATA_TYPE" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_AUTO_DISCOVERY_TABLE_COLUMN
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_AUTO_DISCOVERY_TABLE_COLUMN" 
   (	"AD_TABLE" VARCHAR2(40 BYTE), 
	"COL_ID" VARCHAR2(40 BYTE), 
	"COL_NM" VARCHAR2(100 BYTE), 
	"SORT" NUMBER, 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"IS_KEY" CHAR(1 BYTE), 
	"IS_VISIBLE" CHAR(1 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_BARCODE_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_BARCODE_INFO" 
   (	"BARCODE_NO" VARCHAR2(20 BYTE), 
	"BARCODE_ID" VARCHAR2(20 BYTE), 
	"ASSET_ID" VARCHAR2(20 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_BARCODE_MNG
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_BARCODE_MNG" 
   (	"BARCODE_ID" VARCHAR2(20 BYTE), 
	"PUB_DESC" VARCHAR2(2000 BYTE), 
	"PUB_USER_ID" VARCHAR2(40 BYTE), 
	"PUB_DT" DATE, 
	"REMARK" VARCHAR2(2000 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_BEAM
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_BEAM" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"BEAM_TYPE" VARCHAR2(20 BYTE), 
	"BEAM_RESOL" VARCHAR2(20 BYTE), 
	"BEAM_BRIGHT" VARCHAR2(20 BYTE), 
	"BEAM_CONTRAST" VARCHAR2(20 BYTE), 
	"BEAM_RATIO" VARCHAR2(20 BYTE), 
	"BEAM_LENS" VARCHAR2(20 BYTE), 
	"BEAM_SIGN" VARCHAR2(20 BYTE), 
	"BEAM_LAMP" VARCHAR2(30 BYTE), 
	"BEAM_INOUT" VARCHAR2(50 BYTE), 
	"BEAM_SCTYPE" VARCHAR2(50 BYTE), 
	"BEAM_SCSIZE" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   )  TABLESPACE "ITSM" ;

--------------------------------------------------------
--  DDL for Table AM_BK
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_BK" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"DEVICE_SIZE" NUMBER, 
	"DEVICE_TYPE" VARCHAR2(8 BYTE), 
	"DEVICE_CNT" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"BK_DIV" VARCHAR2(20 BYTE), 
	"INT_DISK_SIZE" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_BK_20140904061933
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_BK_20140904061933" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"DEVICE_SIZE" NUMBER, 
	"DEVICE_TYPE" VARCHAR2(8 BYTE), 
	"DEVICE_CNT" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"BK_DIV" VARCHAR2(20 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_BZ_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_BZ_INFO" 
   (	"BZ_ID" VARCHAR2(30 BYTE), 
	"FSCL_YY" VARCHAR2(4 BYTE), 
	"OFFC_CD" VARCHAR2(3 BYTE), 
	"FSCL_CD" VARCHAR2(3 BYTE), 
	"ACCT_CD" VARCHAR2(2 BYTE), 
	"RSPN_OG_CD" VARCHAR2(10 BYTE), 
	"BZ_CD" VARCHAR2(5 BYTE), 
	"BZ_NM" VARCHAR2(200 BYTE), 
	"BZ_BEGN_DT" VARCHAR2(8 BYTE), 
	"BZ_CLSE_DT" VARCHAR2(8 BYTE), 
	"FLD_CD" VARCHAR2(4 BYTE), 
	"SECT_CD" VARCHAR2(4 BYTE), 
	"PGM" VARCHAR2(4 BYTE), 
	"ACTV_CD" VARCHAR2(4 BYTE), 
	"SACTV_CD" VARCHAR2(4 BYTE), 
	"LACTV1_CD" VARCHAR2(3 BYTE), 
	"LACTV2_CD" VARCHAR2(3 BYTE), 
	"LACTV3_CD" VARCHAR2(3 BYTE), 
	"FLD_NM" VARCHAR2(400 BYTE), 
	"SECT_NM" VARCHAR2(400 BYTE), 
	"PGM_NM" VARCHAR2(200 BYTE), 
	"ACTV_NM" VARCHAR2(200 BYTE), 
	"SACTV_NM" VARCHAR2(200 BYTE), 
	"LACTV1_NM" VARCHAR2(200 BYTE), 
	"LACTV2_NM" VARCHAR2(200 BYTE), 
	"LACTV3_NM" VARCHAR2(200 BYTE), 
	"UPR_BZ_ID" VARCHAR2(30 BYTE), 
	"LWR_BZ_EXI_YN" VARCHAR2(1 BYTE), 
	"BZ_DIV_CD" VARCHAR2(1 BYTE), 
	"PERM_STAT_CD" VARCHAR2(11 BYTE), 
	"BZ_STAT_CD" VARCHAR2(1 BYTE), 
	"BZ_USE_YN" VARCHAR2(1 BYTE), 
	"CITM_CD" VARCHAR2(4 BYTE), 
	"EITM_CD" VARCHAR2(4 BYTE), 
	"STRU1_CD" VARCHAR2(4 BYTE), 
	"STRU2_CD" VARCHAR2(4 BYTE), 
	"STRU1_NM" VARCHAR2(400 BYTE), 
	"STRU2_NM" VARCHAR2(400 BYTE), 
	"LWR_STRU_EXI_YN" VARCHAR2(1 BYTE), 
	"STRU_USE_YN" VARCHAR2(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_CLASS
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_CLASS" 
   (	"CLASS_ID" VARCHAR2(10 BYTE), 
	"CLASS_NM" VARCHAR2(100 BYTE), 
	"R_CLASS_ID" VARCHAR2(10 BYTE), 
	"UP_CLASS_ID" VARCHAR2(10 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CLASS_TYPE" VARCHAR2(10 BYTE), 
	"CLASS_DESC" VARCHAR2(500 BYTE), 
	"DURABLE_YEAR" NUMBER, 
	"DEPRE_METHOD" VARCHAR2(40 BYTE), 
	"DEPRE_RATE" VARCHAR2(20 BYTE), 
	"DEPRE_MIN_ASSET_COST" NUMBER, 
	"LOGICAL_YN" CHAR(1 BYTE), 
	"LOGICAL" CHAR(1 BYTE), 
	"CLASS_MNG_TYPE" CHAR(1 BYTE), 
	"CLASS_IMG" VARCHAR2(200 BYTE), 
	"APP_YN" VARCHAR2(5 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_CONF_NM_CODE
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_CONF_NM_CODE" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"CENTER_TYPE" VARCHAR2(2 BYTE), 
	"BUILDING" VARCHAR2(5 BYTE), 
	"FLOOR" VARCHAR2(3 BYTE), 
	"RACK_PERIOD" VARCHAR2(3 BYTE), 
	"RACK_ORDER" VARCHAR2(3 BYTE), 
	"CHASSIS" VARCHAR2(2 BYTE), 
	"MODULE" VARCHAR2(2 BYTE), 
	"NW_LINE_TYPE" VARCHAR2(2 BYTE), 
	"INSTALL_PERIOD" VARCHAR2(2 BYTE), 
	"CONF_TYPE" VARCHAR2(2 BYTE), 
	"CONF_FUNC" VARCHAR2(4 BYTE), 
	"SERIAL" VARCHAR2(2 BYTE), 
	"HA" VARCHAR2(2 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CONF_NM_CODE" VARCHAR2(30 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_CONF_REL
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_CONF_REL" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"REL_CONF_ID" VARCHAR2(20 BYTE), 
	"CONF_TYPE" VARCHAR2(8 BYTE), 
	"IF_TYPE" VARCHAR2(8 BYTE), 
	"CONTENT" VARCHAR2(1000 BYTE), 
	"RAID_TYPE" VARCHAR2(8 BYTE), 
	"INSTALL_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"REL_TYPE" VARCHAR2(40 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_CONF_REL_HIS
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_CONF_REL_HIS" 
   (	"CHG_HIS_ASSET_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_CONF_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_SEQ" NUMBER, 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"REL_CONF_ID" VARCHAR2(20 BYTE), 
	"CONF_TYPE" VARCHAR2(40 BYTE), 
	"IF_TYPE" VARCHAR2(40 BYTE), 
	"CONTENT" VARCHAR2(1000 BYTE), 
	"RAID_TYPE" VARCHAR2(40 BYTE), 
	"INSTALL_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CHG_HIS_INS_USER_ID" VARCHAR2(40 BYTE), 
	"CHG_HIS_INS_DT" DATE, 
	"CHG_YN" CHAR(1 BYTE), 
	"REL_TYPE" VARCHAR2(40 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_DEPRE
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_DEPRE" 
   (	"DEPRE_YEAR" CHAR(4 BYTE), 
	"DEPRE_MONTH" CHAR(2 BYTE), 
	"ASSET_ID" VARCHAR2(20 BYTE), 
	"DEPRE_DEGREE" NUMBER, 
	"INTRO_COST" NUMBER, 
	"INTRO_DT" DATE, 
	"DEPRE_METHOD" VARCHAR2(40 BYTE), 
	"REMAIN_COST" NUMBER, 
	"DEPRE_COST" NUMBER, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_DEPRE_RATE" 
   (	"YEAR" CHAR(2 BYTE), 
	"S_RATE" VARCHAR2(5 BYTE), 
	"D_RATE" VARCHAR2(5 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_EMS_INFO_TABLE" 
   (	"EMS_TABLE" VARCHAR2(40 BYTE), 
	"EMS_TABLE_NM" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"SORT" NUMBER, 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_EMS_INFO_TABLE_COLUMN
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_EMS_INFO_TABLE_COLUMN" 
   (	"EMS_TABLE" VARCHAR2(40 BYTE), 
	"COL_ID" VARCHAR2(40 BYTE), 
	"COL_NM" VARCHAR2(40 BYTE), 
	"SORT" NUMBER, 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ENTITY
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ENTITY" 
   (	"ENTITY_ID" VARCHAR2(20 BYTE), 
	"ENTITY_NM" VARCHAR2(400 BYTE), 
	"UP_ENTITY_ID" VARCHAR2(20 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"SORT_ORDER" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"ENTITY_TYPE" VARCHAR2(10 BYTE), 
	"COMP_CODE" VARCHAR2(20 BYTE), 
	"GROUP_DESC" VARCHAR2(4000 BYTE), 
	"COL_SIZE" NUMBER, 
	"MOD_YN" CHAR(1 BYTE), 
	"DISPLAY_TYPE" VARCHAR2(40 BYTE), 
	"BTN_YN" VARCHAR2(1 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ENTITY_ATTR_MAPPING
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ENTITY_ATTR_MAPPING" 
   (	"ENTITY_ID" VARCHAR2(20 BYTE), 
	"COL_ID" VARCHAR2(400 BYTE), 
	"GEN_TABLE_NM" VARCHAR2(100 BYTE), 
	"SORT" NUMBER
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ENTITY_ATTR_MAPPING_BAK
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ENTITY_ATTR_MAPPING_BAK" 
   (	"ENTITY_ID" VARCHAR2(20 BYTE), 
	"COL_ID" VARCHAR2(400 BYTE), 
	"GEN_TABLE_NM" VARCHAR2(100 BYTE), 
	"SORT" NUMBER
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ENTITY_BAK
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ENTITY_BAK" 
   (	"ENTITY_ID" VARCHAR2(20 BYTE), 
	"ENTITY_NM" VARCHAR2(400 BYTE), 
	"UP_ENTITY_ID" VARCHAR2(20 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"SORT_ORDER" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"ENTITY_TYPE" VARCHAR2(10 BYTE), 
	"COMP_CODE" VARCHAR2(20 BYTE), 
	"GROUP_DESC" VARCHAR2(4000 BYTE), 
	"COL_SIZE" NUMBER, 
	"MOD_YN" CHAR(1 BYTE), 
	"DISPLAY_TYPE" VARCHAR2(40 BYTE), 
	"BTN_YN" VARCHAR2(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ENTITY_BTN_MAPPING
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ENTITY_BTN_MAPPING" 
   (	"ENTITY_ID" VARCHAR2(20 BYTE), 
	"BTN_ID" VARCHAR2(40 BYTE), 
	"SORT" NUMBER, 
	"BTN_NM" VARCHAR2(20 BYTE)
   )    TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ENTITY_COMP_MAPPING
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ENTITY_COMP_MAPPING" 
   (	"ENTITY_ID" VARCHAR2(20 BYTE), 
	"INSTALL_CODE" VARCHAR2(40 BYTE), 
	"SORT" NUMBER
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ENTITY_REL_MAPPING
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ENTITY_REL_MAPPING" 
   (	"ENTITY_ID" VARCHAR2(20 BYTE), 
	"REL_CODE" VARCHAR2(40 BYTE), 
	"SORT" NUMBER
   )   TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ENTITY_TBL_MAPPING
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ENTITY_TBL_MAPPING" 
   (	"ENTITY_ID" VARCHAR2(20 BYTE), 
	"GEN_TABLE_NM" VARCHAR2(100 BYTE), 
	"SET_TYPE" CHAR(1 BYTE), 
	"SORT" NUMBER
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ET
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ET" 
   (	"CONF_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ETC
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ETC" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"CPU_RATE" NUMBER, 
	"MEM_RATE" NUMBER, 
	"INT_DISK_SIZE" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER, 
	"MEM_SIZE" VARCHAR2(10 BYTE), 
	"CPU_CNT" NUMBER
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ETC_20140904062205
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ETC_20140904062205" 
   (	"CONF_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_FILESYSTEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_FILESYSTEM" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"NODE_ID" VARCHAR2(50 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"DISK_NAME" VARCHAR2(100 BYTE), 
	"TOTAL_SIZE" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_FSCL_ACCT
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_FSCL_ACCT" 
   (	"FSCL_CD" VARCHAR2(3 BYTE), 
	"ACCT_CD" VARCHAR2(2 BYTE), 
	"FSCL_NM" VARCHAR2(50 BYTE), 
	"ACCT_NM" VARCHAR2(50 BYTE), 
	"FBAL_FSCL_ACCT_CD" VARCHAR2(3 BYTE), 
	"BOK_FSCL_ACCT_CD" VARCHAR2(3 BYTE), 
	"MPB_ACCT_CD" VARCHAR2(3 BYTE), 
	"BAL_YN" VARCHAR2(1 BYTE), 
	"BGN_DT" VARCHAR2(8 BYTE), 
	"CLSE_DT" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_HA_GRP
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_HA_GRP" 
   (	"HA_GRP_ID" VARCHAR2(20 BYTE), 
	"HA_GRP_NM" VARCHAR2(100 BYTE), 
	"HA_DESC" VARCHAR2(1000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"HA_TYPE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INFRA
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INFRA" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"CONF_NM" VARCHAR2(300 BYTE), 
	"OPER_STATE" VARCHAR2(50 BYTE), 
	"INSTALL_DT" DATE, 
	"TANGIBLE_ASSET_YN" VARCHAR2(50 BYTE), 
	"CONF_LEVEL" VARCHAR2(4 BYTE), 
	"DR_YN" CHAR(1 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"EMS_ID" VARCHAR2(100 BYTE), 
	"UPD_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"CONF_TYPE" VARCHAR2(4 BYTE), 
	"CLASS_ID" VARCHAR2(30 BYTE), 
	"CLASS_TYPE" VARCHAR2(10 BYTE), 
	"INTRO_DT" DATE, 
	"DCA_ID" VARCHAR2(20 BYTE), 
	"RACK" VARCHAR2(60 BYTE), 
	"PROJECT_NO" VARCHAR2(20 BYTE), 
	"OPER_TYPE" VARCHAR2(5 BYTE), 
	"CLASS_DESC" VARCHAR2(100 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INFRA_20140904060822
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INFRA_20140904060822" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"CONF_NM" VARCHAR2(300 BYTE), 
	"OPER_STATE" VARCHAR2(50 BYTE), 
	"INSTALL_DT" DATE, 
	"TANGIBLE_ASSET_YN" VARCHAR2(50 BYTE), 
	"CONF_LEVEL" VARCHAR2(4 BYTE), 
	"DR_YN" CHAR(1 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"EMS_ID" VARCHAR2(100 BYTE), 
	"UPD_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"CONF_TYPE" VARCHAR2(4 BYTE), 
	"CLASS_ID" VARCHAR2(10 BYTE), 
	"CLASS_TYPE" VARCHAR2(10 BYTE), 
	"INTRO_DT" DATE, 
	"DCA_ID" VARCHAR2(20 BYTE), 
	"RACK" VARCHAR2(60 BYTE), 
	"PROJECT_NO" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INFRA_20140904060914
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INFRA_20140904060914" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"CONF_NM" VARCHAR2(300 BYTE), 
	"OPER_STATE" VARCHAR2(50 BYTE), 
	"INSTALL_DT" DATE, 
	"TANGIBLE_ASSET_YN" VARCHAR2(50 BYTE), 
	"CONF_LEVEL" VARCHAR2(4 BYTE), 
	"DR_YN" CHAR(1 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"EMS_ID" VARCHAR2(100 BYTE), 
	"UPD_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"CONF_TYPE" VARCHAR2(4 BYTE), 
	"CLASS_ID" VARCHAR2(10 BYTE), 
	"CLASS_TYPE" VARCHAR2(10 BYTE), 
	"INTRO_DT" DATE, 
	"DCA_ID" VARCHAR2(20 BYTE), 
	"RACK" VARCHAR2(60 BYTE), 
	"PROJECT_NO" VARCHAR2(20 BYTE), 
	"OPER_TYPE" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INFRA_TMP
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INFRA_TMP" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"CONF_NM" VARCHAR2(300 BYTE), 
	"OPER_STATE" VARCHAR2(50 BYTE), 
	"INSTALL_DT" DATE, 
	"TANGIBLE_ASSET_YN" VARCHAR2(50 BYTE), 
	"CONF_LEVEL" VARCHAR2(4 BYTE), 
	"DR_YN" CHAR(1 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"EMS_ID" VARCHAR2(100 BYTE), 
	"UPD_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"CONF_TYPE" VARCHAR2(4 BYTE), 
	"CLASS_ID" VARCHAR2(30 BYTE), 
	"CLASS_TYPE" VARCHAR2(10 BYTE), 
	"INTRO_DT" DATE, 
	"DCA_ID" VARCHAR2(20 BYTE), 
	"RACK" VARCHAR2(60 BYTE), 
	"PROJECT_NO" VARCHAR2(20 BYTE), 
	"OPER_TYPE" VARCHAR2(5 BYTE), 
	"CLASS_DESC" VARCHAR2(100 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INFRA_TO_HA_GRP
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INFRA_TO_HA_GRP" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"HA_GRP_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INFRA_TO_HA_GRP_HIS
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INFRA_TO_HA_GRP_HIS" 
   (	"CHG_HIS_ASSET_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_CONF_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_SEQ" NUMBER, 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"HA_GRP_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CHG_HIS_INS_USER_ID" VARCHAR2(40 BYTE), 
	"CHG_HIS_INS_DT" DATE, 
	"CHG_YN" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INSTALL_TABLE
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INSTALL_TABLE" 
   (	"COMP_ID" VARCHAR2(20 BYTE), 
	"COMP_NM" VARCHAR2(50 BYTE), 
	"TABLE_NM" VARCHAR2(400 BYTE), 
	"EMS_SHOW_YN" CHAR(1 BYTE), 
	"EMS_YN" CHAR(1 BYTE), 
	"EMS_TABLE_NM" VARCHAR2(100 BYTE), 
	"SORT" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MULTI_YN" VARCHAR2(1 BYTE), 
	"DCA_SHOW_YN" CHAR(1 BYTE), 
	"DCA_YN" CHAR(1 BYTE), 
	"DCA_TABLE_NM" VARCHAR2(100 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INSTALL_TABLE_COLUMN
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INSTALL_TABLE_COLUMN" 
   (	"TABLE_NM" VARCHAR2(400 BYTE), 
	"COL_ID" VARCHAR2(20 BYTE), 
	"COL_NM" VARCHAR2(20 BYTE), 
	"FLEX" VARCHAR2(2 BYTE), 
	"XTYPE" VARCHAR2(40 BYTE), 
	"SORTABLE" VARCHAR2(2 BYTE), 
	"TPL" VARCHAR2(2 BYTE), 
	"ALIGN" VARCHAR2(20 BYTE), 
	"HIDDEN" VARCHAR2(2 BYTE), 
	"EMS_COL_ID" VARCHAR2(20 BYTE), 
	"SORT" NUMBER, 
	"SYS_CODE" VARCHAR2(20 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"ORDER_COL" CHAR(1 BYTE), 
	"WIDTH" VARCHAR2(4 BYTE), 
	"IDX_COL" CHAR(1 BYTE), 
	"COMPARE_COL" CHAR(1 BYTE), 
	"DCA_COL_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_CPU
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_CPU" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_DISK
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_DISK" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"INDX" VARCHAR2(10 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"VENDOR" VARCHAR2(300 BYTE), 
	"DISK_TYPE" VARCHAR2(100 BYTE), 
	"TOTAL_SIZE" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_FAN
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_FAN" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_FILESYSTEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_FILESYSTEM" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"DISK_NAME" VARCHAR2(100 BYTE), 
	"TOTAL_SIZE" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_MEMORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_MEMORY" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"MEM_SIZE" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_MODULE
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_MODULE" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"MODULE_NAME" VARCHAR2(100 BYTE), 
	"SLO_NUM" VARCHAR2(40 BYTE), 
	"HW_VERSION" VARCHAR2(15 BYTE), 
	"SW_VERSION" VARCHAR2(15 BYTE), 
	"MODULE_TYPE" VARCHAR2(40 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_NIC
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_NIC" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"NODE_ID" VARCHAR2(50 BYTE), 
	"INDX" VARCHAR2(10 BYTE), 
	"MODEL" VARCHAR2(300 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_NIF
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_NIF" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"MAC_ADDRESS" VARCHAR2(50 BYTE), 
	"IPADDRESS" VARCHAR2(300 BYTE), 
	"NETMASK" VARCHAR2(100 BYTE), 
	"IF_TYPE" VARCHAR2(50 BYTE), 
	"BAND_WIDTH" NUMBER, 
	"MTU" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_NW_NIF
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_NW_NIF" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"IDX" NUMBER, 
	"NAME" VARCHAR2(255 BYTE), 
	"MAC_ADDRESS" VARCHAR2(40 BYTE), 
	"IF_TYPE" VARCHAR2(100 BYTE), 
	"MTU" VARCHAR2(20 BYTE), 
	"BAND_WIDTH" VARCHAR2(20 BYTE), 
	"ADMIN_STATUS" VARCHAR2(100 BYTE), 
	"OPER_STATUS" VARCHAR2(100 BYTE), 
	"ALIAS" VARCHAR2(50 BYTE), 
	"IP" VARCHAR2(20 BYTE), 
	"REMARKS" VARCHAR2(2000 BYTE), 
	"NETMASK" VARCHAR2(50 BYTE), 
	"PORT" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_PORT
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_PORT" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"IPADDRESS" VARCHAR2(40 BYTE), 
	"MAC_ADDRESS" VARCHAR2(50 BYTE), 
	"MTU" NUMBER, 
	"BAND_WIDTH" NUMBER, 
	"IF_TYPE" VARCHAR2(40 BYTE), 
	"IF_DESC" VARCHAR2(100 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_INS_POWER
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_INS_POWER" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_LIFECYCLE
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_LIFECYCLE" 
   (	"REQ_NO" VARCHAR2(20 BYTE), 
	"REQ_TITLE" VARCHAR2(200 BYTE), 
	"REQ_CONTENT" VARCHAR2(2000 BYTE), 
	"REQ_DEPT_CODE" VARCHAR2(20 BYTE), 
	"REQ_USER_ID" VARCHAR2(20 BYTE), 
	"REQ_DT" DATE, 
	"APPR_USER_ID" VARCHAR2(20 BYTE), 
	"APPR_DT" DATE, 
	"REJECT_USER_ID" VARCHAR2(20 BYTE), 
	"REJECT_DT" DATE, 
	"REJECT_COMMENT" VARCHAR2(2000 BYTE), 
	"LIFECYCLE_TYPE" VARCHAR2(20 BYTE), 
	"LIFECYCLE_REQ_STATE" VARCHAR2(20 BYTE), 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_LIFECYCLE_ASSET
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_LIFECYCLE_ASSET" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"REQ_NO" VARCHAR2(20 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_MAINT" 
   (	"MAINT_ID" VARCHAR2(20 BYTE), 
	"MAINT_NM" VARCHAR2(200 BYTE), 
	"CONTRACT_COST" NUMBER, 
	"CONTRACT_START_DT" DATE, 
	"CONTRACT_END_DT" DATE, 
	"CONTRACT_CUST_ID" VARCHAR2(20 BYTE), 
	"CONTRACT_USER_ID" VARCHAR2(20 BYTE), 
	"CONTRACT_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MAINT_TYPE" VARCHAR2(10 BYTE), 
	"MAINT_RATE" NUMBER, 
	"SALES_USER_ID" VARCHAR2(20 BYTE), 
	"VENDOR_ID" VARCHAR2(300 BYTE), 
	"FILE_ID" VARCHAR2(20 BYTE), 
	"CONTRACT_DESC" VARCHAR2(2000 BYTE), 
	"MAINT_SUPPLY_METHOD" VARCHAR2(8 BYTE), 
	"MAINT_PLAN" VARCHAR2(2000 BYTE), 
	"MAINT_PAID_YN" CHAR(1 BYTE), 
	"CONTRACT_STATE" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_MAINT_CONT_REQ_ASSET" 
   (	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MAINT_ID" VARCHAR2(20 BYTE), 
	"ASSET_ID" VARCHAR2(20 BYTE), 
	"MAINT_REQ_NO" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_MAINT_HIS" 
   (	"MAINT_ID" VARCHAR2(20 BYTE), 
	"SEQ" NUMBER, 
	"HIS_DESC" VARCHAR2(4000 BYTE), 
	"UPD_USER" VARCHAR2(40 BYTE), 
	"UPD_DATE" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_MAINT_NONE_CONT_REQ_ASSET
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_MAINT_NONE_CONT_REQ_ASSET" 
   (	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"MAINT_COST" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"ASSET_ID" VARCHAR2(20 BYTE), 
	"MAINT_REQ_NO" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_MAINT_REQUEST" 
   (	"MAINT_REQ_NO" VARCHAR2(20 BYTE), 
	"REQ_TITLE" VARCHAR2(300 BYTE), 
	"REQ_CUST_ID" VARCHAR2(20 BYTE), 
	"REQ_USER_ID" VARCHAR2(20 BYTE), 
	"REQ_DT" DATE, 
	"MAINT_REQ_TYPE" VARCHAR2(8 BYTE), 
	"WISH_DT" DATE, 
	"MAINT_REQ_STATE" VARCHAR2(8 BYTE), 
	"MAINT_CHECK_TYPE" VARCHAR2(8 BYTE), 
	"APPR_USER_ID" VARCHAR2(20 BYTE), 
	"APPR_DT" DATE, 
	"REJECT_USER_ID" VARCHAR2(20 BYTE), 
	"REJECT_DT" DATE, 
	"REJECT_COMMENT" VARCHAR2(2000 BYTE), 
	"WORK_CONTENT" VARCHAR2(2000 BYTE), 
	"WORK_START_DT" DATE, 
	"WORK_END_DT" DATE, 
	"WORK_DISPOSER" VARCHAR2(20 BYTE), 
	"WORK_CONFIRM_USER_ID" VARCHAR2(20 BYTE), 
	"WORK_CONFIRM_DT" DATE, 
	"WORK_REJECT_USER_ID" VARCHAR2(20 BYTE), 
	"WORK_REJECT_DT" DATE, 
	"WORK_REJECT_COMMENT" VARCHAR2(2000 BYTE), 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"REQ_CONTENT" VARCHAR2(2000 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_MAINT_TO_ASSET" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"MAINT_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_MONITOR" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"MONI_RATIO" VARCHAR2(20 BYTE), 
	"MONI_SPEED" VARCHAR2(20 BYTE), 
	"MONI_BRIGHT" VARCHAR2(20 BYTE), 
	"MONI_RESOL" VARCHAR2(20 BYTE), 
	"MONI_CONTRAST" VARCHAR2(20 BYTE), 
	"MONI_INTERFACE" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_NW" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"MAIN_IP" VARCHAR2(16 BYTE), 
	"UPD_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"MAC_ADDR" VARCHAR2(100 BYTE), 
	"MAX_SLOT_CNT" NUMBER, 
	"IF_MAX_OPTICAL" VARCHAR2(10 BYTE), 
	"IF_USE_OPTICAL" VARCHAR2(10 BYTE), 
	"IF_MAX_UTP" VARCHAR2(10 BYTE), 
	"IF_USE_UTP" VARCHAR2(10 BYTE), 
	"USE_SLOT_CNT" NUMBER, 
	"POWER_INFO" VARCHAR2(20 BYTE), 
	"DR_INFO" VARCHAR2(20 BYTE), 
	"INT_DISK_SIZE" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_NW_20140904061830" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"MAIN_IP" VARCHAR2(16 BYTE), 
	"UPD_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"MAC_ADDR" VARCHAR2(100 BYTE), 
	"MAX_SLOT_CNT" NUMBER, 
	"IF_MAX_OPTICAL" VARCHAR2(10 BYTE), 
	"IF_USE_OPTICAL" VARCHAR2(10 BYTE), 
	"IF_MAX_UTP" VARCHAR2(10 BYTE), 
	"IF_USE_UTP" VARCHAR2(10 BYTE), 
	"USE_SLOT_CNT" NUMBER, 
	"POWER_INFO" VARCHAR2(20 BYTE), 
	"DR_INFO" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_OA
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_OA" 
   (	"CONF_ID" VARCHAR2(20 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_OFFC
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_OFFC" 
   (	"OFFC_CD" VARCHAR2(3 BYTE), 
	"OFFC_NM" VARCHAR2(50 BYTE), 
	"OFFC_ENG_NM" VARCHAR2(100 BYTE), 
	"ORG_CD" VARCHAR2(3 BYTE), 
	"FBAL_OFFC_CD" VARCHAR2(2 BYTE), 
	"WIP_NO" VARCHAR2(6 BYTE), 
	"ADDR" VARCHAR2(200 BYTE), 
	"TEL_NO" VARCHAR2(30 BYTE), 
	"GOF_JANG" VARCHAR2(30 BYTE), 
	"BOK_OFFC_CD" VARCHAR2(2 BYTE), 
	"MPB_OFFC_CD" VARCHAR2(7 BYTE), 
	"BULK_CLCT_INST_YN" VARCHAR2(1 BYTE), 
	"FT_YN" VARCHAR2(1 BYTE), 
	"BGN_DT" VARCHAR2(8 BYTE), 
	"CLSE_DT" VARCHAR2(8 BYTE), 
	"BAI_OFFC_CD" VARCHAR2(3 BYTE), 
	"GOC_PSIT_NM" VARCHAR2(20 BYTE), 
	"BZR_RG_NO" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_OPER" 
   (	"SEQ" NUMBER, 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"OPER_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MAIN_YN" CHAR(1 BYTE)
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_OPER_HIS" 
   (	"CHG_HIS_ASSET_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_CONF_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_SEQ" NUMBER, 
	"SEQ" NUMBER, 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"OPER_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CHG_HIS_INS_USER_ID" VARCHAR2(40 BYTE), 
	"CHG_HIS_INS_DT" DATE, 
	"MAIN_YN" CHAR(1 BYTE), 
	"CHG_YN" CHAR(1 BYTE)
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_PC" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"MAC_ADDR" VARCHAR2(100 BYTE), 
	"HDD_SERIAL" VARCHAR2(20 BYTE), 
	"CPU_NM" VARCHAR2(30 BYTE), 
	"MEM_SIZE" VARCHAR2(10 BYTE), 
	"HDD_SIZE" VARCHAR2(12 BYTE), 
	"GRAPHIC_NM" VARCHAR2(50 BYTE), 
	"USBPORT_CNT" VARCHAR2(5 BYTE), 
	"LAN_SPEED" VARCHAR2(20 BYTE), 
	"PC_TYPE" VARCHAR2(12 BYTE), 
	"OS_TYPE" VARCHAR2(50 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_POPUP_MNG" 
   (	"POPUP_CODE" VARCHAR2(40 BYTE), 
	"POPUP_NM" VARCHAR2(400 BYTE), 
	"POPUP_NM_FN" VARCHAR2(400 BYTE), 
	"POPUP_DETAIL_YN" CHAR(1 BYTE), 
	"USE_YN" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_PORT
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_PORT" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"OBJECT_NAME" VARCHAR2(300 BYTE), 
	"INTERFACE_TYPE" VARCHAR2(200 BYTE), 
	"MTU" VARCHAR2(200 BYTE), 
	"BAND_WIDTH" VARCHAR2(200 BYTE), 
	"MAC_ADDRESS" VARCHAR2(200 BYTE), 
	"IP_ADDRESS" VARCHAR2(200 BYTE), 
	"PORT_DESC" VARCHAR2(200 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_PROJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_PROJECT" 
   (	"PROJECT_ID" VARCHAR2(20 BYTE), 
	"PROJECT_NM" VARCHAR2(200 BYTE), 
	"PROJECT_YYYY" CHAR(4 BYTE), 
	"PROJECT_CONTENT" VARCHAR2(2000 BYTE), 
	"PROJECT_START_DT" DATE, 
	"PROJECT_END_DT" DATE, 
	"CUST_ID" VARCHAR2(20 BYTE), 
	"USER_ID" VARCHAR2(40 BYTE), 
	"PROJECT_STATE" VARCHAR2(8 BYTE), 
	"FILE_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_PROJECT_SUB" 
   (	"PROJECT_ID" VARCHAR2(20 BYTE), 
	"SEQ" NUMBER, 
	"SUB_PROJECT_NM" VARCHAR2(200 BYTE), 
	"SUB_PROJECT_CONTENT" VARCHAR2(2000 BYTE), 
	"SUB_CUST_ID" VARCHAR2(40 BYTE), 
	"SUB_USER_ID" VARCHAR2(40 BYTE), 
	"SUB_START_DT" DATE, 
	"SUB_END_DT" DATE, 
	"SUB_PROJECT_STATE" VARCHAR2(8 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_PRT" 
   (	"PRT_SPEED" VARCHAR2(10 BYTE), 
	"PRT_TYPE" VARCHAR2(20 BYTE), 
	"PRT_CPU" VARCHAR2(30 BYTE), 
	"PRT_MEM" VARCHAR2(10 BYTE), 
	"PRT_RESOL" VARCHAR2(20 BYTE), 
	"PRT_PAPER" VARCHAR2(10 BYTE), 
	"PRTTWO_YN" VARCHAR2(10 BYTE), 
	"USE_INTFACE" VARCHAR2(20 BYTE), 
	"USE_ADD" VARCHAR2(50 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_RACK_ASSET" 
   (	"ASSET_ID" VARCHAR2(20 BYTE), 
	"RACK_PLAN_CODE" VARCHAR2(20 BYTE), 
	"RACK_FLOOR" NUMBER, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"RACK_FLOOR_DIV" NUMBER
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_RACK_INFO" 
   (	"RACK_CODE" VARCHAR2(20 BYTE), 
	"RACK_TYPE" VARCHAR2(40 BYTE), 
	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"MODEL_NM" VARCHAR2(200 BYTE), 
	"MOUNT_CNT" NUMBER, 
	"RACK_IMAGE" VARCHAR2(20 BYTE), 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"REMARKS" VARCHAR2(2000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"WIDTH_SIZE" NUMBER, 
	"HEIGHT_SIZE" NUMBER
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_RACK_PLAN" 
   (	"RACK_PLAN_CODE" VARCHAR2(20 BYTE), 
	"LOC_PLAN_CODE" VARCHAR2(20 BYTE), 
	"RACK_CODE" VARCHAR2(20 BYTE), 
	"RACK_PLAN_X" NUMBER, 
	"RACK_PLAN_Y" NUMBER, 
	"RACK_PLAN_TYPE" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"WIDTH_SIZE" NUMBER, 
	"HEIGHT_SIZE" NUMBER
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SC" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"OS_NM" VARCHAR2(50 BYTE), 
	"OS_VER" VARCHAR2(50 BYTE), 
	"MAIN_IP" VARCHAR2(20 BYTE), 
	"MAC_ADDR" VARCHAR2(100 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MEM_SIZE" VARCHAR2(10 BYTE), 
	"CPU_CNT" NUMBER, 
	"CPU_TYPE" VARCHAR2(50 BYTE), 
	"DISK_CNT" NUMBER, 
	"MEM_CNT" NUMBER, 
	"LICENCE_CNT" NUMBER, 
	"LICENCE_POLICY" VARCHAR2(20 BYTE), 
	"LICENCE_POLICY_ETC" VARCHAR2(50 BYTE), 
	"VERSION" VARCHAR2(70 BYTE), 
	"CPU_RATE" NUMBER, 
	"MEM_RATE" NUMBER, 
	"INT_DISK_SIZE" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SCAN" 
   (	"USE_INTFACE" VARCHAR2(20 BYTE), 
	"USE_ADD" VARCHAR2(50 BYTE), 
	"SCAN_SPEED" VARCHAR2(10 BYTE), 
	"SCAN_RESOL" VARCHAR2(20 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SC_20140904062036" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"OS_NM" VARCHAR2(50 BYTE), 
	"OS_VER" VARCHAR2(50 BYTE), 
	"MAIN_IP" VARCHAR2(20 BYTE), 
	"MAC_ADDR" VARCHAR2(100 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MEM_SIZE" VARCHAR2(10 BYTE), 
	"CPU_CNT" NUMBER, 
	"CPU_TYPE" VARCHAR2(50 BYTE), 
	"DISK_CNT" NUMBER, 
	"MEM_CNT" NUMBER, 
	"LICENCE_CNT" NUMBER, 
	"LICENCE_POLICY" VARCHAR2(20 BYTE), 
	"LICENCE_POLICY_ETC" VARCHAR2(50 BYTE), 
	"VERSION" VARCHAR2(70 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SERVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SERVICE" 
   (	"SERVICE_ID" VARCHAR2(10 BYTE), 
	"SERVICE_NM" VARCHAR2(200 BYTE), 
	"R_SERVICE_ID" VARCHAR2(10 BYTE), 
	"UP_SERVICE_ID" VARCHAR2(10 BYTE), 
	"SERVICE_EFFECT" VARCHAR2(20 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"SERVICE_DESC" VARCHAR2(2000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"SERVICE_IMG" VARCHAR2(100 BYTE), 
	"SERVICE_SIMPLE_ID" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SERVICE_BAK
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SERVICE_BAK" 
   (	"SERVICE_ID" VARCHAR2(10 BYTE), 
	"SERVICE_NM" VARCHAR2(200 BYTE), 
	"R_SERVICE_ID" VARCHAR2(10 BYTE), 
	"UP_SERVICE_ID" VARCHAR2(10 BYTE), 
	"SERVICE_EFFECT" VARCHAR2(20 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"SERVICE_DESC" VARCHAR2(2000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"SERVICE_IMG" VARCHAR2(100 BYTE), 
	"SERVICE_SIMPLE_ID" VARCHAR2(10 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SERVICE_OPER
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SERVICE_OPER" 
   (	"SERVICE_ID" VARCHAR2(10 BYTE), 
	"SEQ" NUMBER, 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"OPER_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SERVICE_OPER_BAK
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SERVICE_OPER_BAK" 
   (	"SERVICE_ID" VARCHAR2(10 BYTE), 
	"SEQ" NUMBER, 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"OPER_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SERVICE_REL
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SERVICE_REL" 
   (	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"SERVICE_ID" VARCHAR2(10 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SERVICE_REL_HIS
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SERVICE_REL_HIS" 
   (	"CHG_HIS_ASSET_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_CONF_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_SEQ" NUMBER, 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"SERVICE_ID" VARCHAR2(10 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CHG_HIS_INS_USER_ID" VARCHAR2(40 BYTE), 
	"CHG_HIS_INS_DT" DATE, 
	"CHG_YN" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SERVICE_TMP
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SERVICE_TMP" 
   (	"SERVICE_ID" VARCHAR2(10 BYTE), 
	"SERVICE_NM" VARCHAR2(200 BYTE), 
	"R_SERVICE_ID" VARCHAR2(10 BYTE), 
	"UP_SERVICE_ID" VARCHAR2(10 BYTE), 
	"SERVICE_EFFECT" VARCHAR2(20 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"SERVICE_DESC" VARCHAR2(2000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"SERVICE_IMG" VARCHAR2(100 BYTE), 
	"SERVICE_SIMPLE_ID" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_ST
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_ST" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"UPD_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"ST_TYPE" VARCHAR2(10 BYTE), 
	"INT_DISK_SIZE" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER, 
	"DISK_CNT" NUMBER, 
	"OS_NM" VARCHAR2(50 BYTE)
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_ST_20140912113532" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"UPD_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"ST_TYPE" VARCHAR2(10 BYTE), 
	"INT_DISK_SIZE" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER, 
	"DISK_CNT" NUMBER
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SUPPLY
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SUPPLY" 
   (	"SUPPLY_ID" VARCHAR2(20 BYTE), 
	"PROJECT_ID" VARCHAR2(20 BYTE), 
	"SEQ" NUMBER, 
	"SUPPLY_NM" VARCHAR2(200 BYTE), 
	"SUPPLY_START_DT" DATE, 
	"SUPPLY_TYPE" VARCHAR2(50 BYTE), 
	"SUPPLY_METHOD" VARCHAR2(50 BYTE), 
	"CONTRACT_CUST_ID" VARCHAR2(40 BYTE), 
	"CONTRACT_USER_ID" VARCHAR2(40 BYTE), 
	"VENDOR_ID" VARCHAR2(40 BYTE), 
	"SUPPLY_STATE" VARCHAR2(8 BYTE), 
	"TOT_COST" NUMBER, 
	"SUPPLY_DESC" VARCHAR2(1000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"FILE_ID" VARCHAR2(20 BYTE), 
	"BUY_AMOUNT" NUMBER, 
	"CL_LSNUM" VARCHAR2(40 BYTE), 
	"CL_LSDT" DATE, 
	"CL_LSCOMPANY" VARCHAR2(200 BYTE), 
	"CL_PRICE" NUMBER, 
	"CL_LSTOTALPRICE" NUMBER, 
	"CL_LSRATE1" VARCHAR2(20 BYTE), 
	"CL_LSRATE2" VARCHAR2(20 BYTE), 
	"CL_LSSDT" DATE, 
	"CL_LSEDT" DATE, 
	"CL_LSINTEREST" VARCHAR2(50 BYTE), 
	"CL_LSPAYMENT" VARCHAR2(50 BYTE), 
	"CL_LSEXPIREDACT" VARCHAR2(100 BYTE), 
	"CL_LSPDAY2" DATE, 
	"CL_LSDEFAULTPRICE" NUMBER, 
	"DRIMS_YN" VARCHAR2(1 BYTE), 
	"DRIMS_SUPPLY_ID" VARCHAR2(40 BYTE), 
	"BZ_ID" VARCHAR2(40 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SUPPLY_HIS" 
   (	"SUPPLY_ID" VARCHAR2(20 BYTE), 
	"SEQ" NUMBER, 
	"HIS_DESC" VARCHAR2(4000 BYTE), 
	"UPD_USER" VARCHAR2(40 BYTE), 
	"UPD_DATE" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SUPPLY_INFRA
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SUPPLY_INFRA" 
   (	"SEQ" NUMBER, 
	"CLASS_ID" VARCHAR2(10 BYTE), 
	"CONF_NM" VARCHAR2(300 BYTE), 
	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"MODEL_NM" VARCHAR2(200 BYTE), 
	"COST" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CHECK_DT" DATE, 
	"SUPPLY_ID" VARCHAR2(20 BYTE), 
	"AMOUNT" VARCHAR2(100 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SUPPLY_SW" 
   (	"SEQ" NUMBER, 
	"CLASS_ID" VARCHAR2(10 BYTE), 
	"LICENCE_TYPE" VARCHAR2(50 BYTE), 
	"LICENCE_TERM" VARCHAR2(50 BYTE), 
	"LICENCE_CNT" NUMBER, 
	"LICENCE_START_DT" DATE, 
	"LICENCE_END_DT" DATE, 
	"COST" NUMBER, 
	"TOT_COST" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CONF_NM" VARCHAR2(300 BYTE), 
	"CHECK_DT" DATE, 
	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"MODEL_NM" VARCHAR2(200 BYTE), 
	"SUPPLY_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SV_LOGIC" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"PHYSI_CONF_ID" VARCHAR2(20 BYTE), 
	"LOGIC_TYPE" VARCHAR2(40 BYTE), 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"OS_NM" VARCHAR2(50 BYTE), 
	"OS_VER" VARCHAR2(50 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"VM_ID" VARCHAR2(40 BYTE), 
	"OS_CODE" VARCHAR2(20 BYTE), 
	"MEM_SIZE" VARCHAR2(10 BYTE), 
	"CPU_CORE" NUMBER, 
	"INT_DISK_SIZE" NUMBER, 
	"MAIN_IP" VARCHAR2(16 BYTE), 
	"CPU_RATE" NUMBER, 
	"MEM_RATE" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER, 
	"CPU_CNT" NUMBER, 
	"OS_DESC" VARCHAR2(100 BYTE), 
	"MAC_ADDR" VARCHAR2(100 BYTE)
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SV_LOGIC_20140904062253" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"PHYSI_CONF_ID" VARCHAR2(20 BYTE), 
	"LOGIC_TYPE" VARCHAR2(40 BYTE), 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"OS_NM" VARCHAR2(50 BYTE), 
	"OS_VER" VARCHAR2(50 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"VM_ID" VARCHAR2(40 BYTE), 
	"OS_CODE" VARCHAR2(20 BYTE), 
	"MEM_SIZE" VARCHAR2(10 BYTE), 
	"CPU_CORE" NUMBER, 
	"INT_DISK_SIZE" NUMBER, 
	"MAIN_IP" VARCHAR2(16 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SV_LOGIC_20140904064441
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SV_LOGIC_20140904064441" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"PHYSI_CONF_ID" VARCHAR2(20 BYTE), 
	"LOGIC_TYPE" VARCHAR2(40 BYTE), 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"OS_NM" VARCHAR2(50 BYTE), 
	"OS_VER" VARCHAR2(50 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"VM_ID" VARCHAR2(40 BYTE), 
	"OS_CODE" VARCHAR2(20 BYTE), 
	"MEM_SIZE" VARCHAR2(10 BYTE), 
	"CPU_CORE" NUMBER, 
	"INT_DISK_SIZE" NUMBER, 
	"MAIN_IP" VARCHAR2(16 BYTE), 
	"CPU_RATE" NUMBER, 
	"MEM_RATE" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER, 
	"CPU_CNT" NUMBER
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SV_LOGIC_20140911070151
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SV_LOGIC_20140911070151" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"PHYSI_CONF_ID" VARCHAR2(20 BYTE), 
	"LOGIC_TYPE" VARCHAR2(40 BYTE), 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"OS_NM" VARCHAR2(50 BYTE), 
	"OS_VER" VARCHAR2(50 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"VM_ID" VARCHAR2(40 BYTE), 
	"OS_CODE" VARCHAR2(20 BYTE), 
	"MEM_SIZE" VARCHAR2(10 BYTE), 
	"CPU_CORE" NUMBER, 
	"INT_DISK_SIZE" NUMBER, 
	"MAIN_IP" VARCHAR2(16 BYTE), 
	"CPU_RATE" NUMBER, 
	"MEM_RATE" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER, 
	"CPU_CNT" NUMBER, 
	"OS_DESC" VARCHAR2(100 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SV_LOGIC_HIS
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SV_LOGIC_HIS" 
   (	"CHG_HIS_ASSET_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_CONF_ID" VARCHAR2(20 BYTE), 
	"CHG_HIS_SEQ" NUMBER, 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"PHYSI_CONF_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CHG_HIS_INS_USER_ID" VARCHAR2(40 BYTE), 
	"CHG_HIS_INS_DT" DATE, 
	"CHG_YN" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SV_PHYSI
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SV_PHYSI" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"MAX_CPU_CNT" NUMBER, 
	"INT_DISK_SIZE" NUMBER, 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"MAX_MEM_SIZE" NUMBER, 
	"OS_NM" VARCHAR2(50 BYTE), 
	"OS_VER" VARCHAR2(100 BYTE), 
	"MAIN_IP" VARCHAR2(16 BYTE), 
	"MAC_ADDR" VARCHAR2(100 BYTE), 
	"MAX_MEM_CNT" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CPU_CNT" NUMBER, 
	"CPU_CORE" NUMBER, 
	"CPU_TYPE" VARCHAR2(50 BYTE), 
	"CPU_MODEL" VARCHAR2(100 BYTE), 
	"CPU_VENDOR" VARCHAR2(100 BYTE), 
	"CPU_CLOCK" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER, 
	"CPU_NM" VARCHAR2(30 BYTE), 
	"OS_NM_ETC" VARCHAR2(100 BYTE), 
	"CPU_RATE" NUMBER, 
	"MEM_RATE" NUMBER, 
	"DISK_VENDOR" VARCHAR2(20 BYTE), 
	"DISK_MODEL" VARCHAR2(20 BYTE), 
	"NIC_VENDOR" VARCHAR2(50 BYTE), 
	"NIC_MODEL" VARCHAR2(50 BYTE), 
	"NIC_SPEED" VARCHAR2(10 BYTE), 
	"MEM_SIZE" VARCHAR2(10 BYTE), 
	"OS_DESC" VARCHAR2(100 BYTE)
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SV_PHYSI_20140904062335" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"MAX_CPU_CNT" NUMBER, 
	"INT_DISK_SIZE" NUMBER, 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"MAX_MEM_SIZE" NUMBER, 
	"OS_NM" VARCHAR2(50 BYTE), 
	"OS_VER" VARCHAR2(100 BYTE), 
	"MAIN_IP" VARCHAR2(16 BYTE), 
	"MAC_ADDR" VARCHAR2(100 BYTE), 
	"MAX_MEM_CNT" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CPU_CNT" NUMBER, 
	"CPU_CORE" NUMBER, 
	"CPU_TYPE" VARCHAR2(50 BYTE), 
	"CPU_MODEL" VARCHAR2(100 BYTE), 
	"CPU_VENDOR" VARCHAR2(100 BYTE), 
	"CPU_CLOCK" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER, 
	"CPU_NM" VARCHAR2(30 BYTE), 
	"OS_NM_ETC" VARCHAR2(100 BYTE), 
	"CPU_RATE" NUMBER, 
	"MEM_RATE" NUMBER, 
	"DISK_VENDOR" VARCHAR2(20 BYTE), 
	"DISK_MODEL" VARCHAR2(20 BYTE), 
	"NIC_VENDOR" VARCHAR2(50 BYTE), 
	"NIC_MODEL" VARCHAR2(50 BYTE), 
	"NIC_SPEED" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SV_PHYSI_20140904064419
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SV_PHYSI_20140904064419" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"MAX_CPU_CNT" NUMBER, 
	"INT_DISK_SIZE" NUMBER, 
	"HOST_NM" VARCHAR2(50 BYTE), 
	"MAX_MEM_SIZE" NUMBER, 
	"OS_NM" VARCHAR2(50 BYTE), 
	"OS_VER" VARCHAR2(100 BYTE), 
	"MAIN_IP" VARCHAR2(16 BYTE), 
	"MAC_ADDR" VARCHAR2(100 BYTE), 
	"MAX_MEM_CNT" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CPU_CNT" NUMBER, 
	"CPU_CORE" NUMBER, 
	"CPU_TYPE" VARCHAR2(50 BYTE), 
	"CPU_MODEL" VARCHAR2(100 BYTE), 
	"CPU_VENDOR" VARCHAR2(100 BYTE), 
	"CPU_CLOCK" NUMBER, 
	"TOT_INT_DISK_SIZE" NUMBER, 
	"CPU_NM" VARCHAR2(30 BYTE), 
	"OS_NM_ETC" VARCHAR2(100 BYTE), 
	"CPU_RATE" NUMBER, 
	"MEM_RATE" NUMBER, 
	"DISK_VENDOR" VARCHAR2(20 BYTE), 
	"DISK_MODEL" VARCHAR2(20 BYTE), 
	"NIC_VENDOR" VARCHAR2(50 BYTE), 
	"NIC_MODEL" VARCHAR2(50 BYTE), 
	"NIC_SPEED" VARCHAR2(10 BYTE), 
	"MEM_SIZE" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SW
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SW" 
   (	"CONF_NM" VARCHAR2(300 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"CLASS_ID" VARCHAR2(40 BYTE), 
	"CLASS_TYPE" VARCHAR2(10 BYTE), 
	"LICENCE_CNT" NUMBER, 
	"LICENCE_START_DT" DATE, 
	"LICENCE_END_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"ASSET_ID" VARCHAR2(20 BYTE), 
	"LICENSE_SORT" VARCHAR2(20 BYTE), 
	"VERSION" VARCHAR2(70 BYTE), 
	"INSTALL_DT" DATE, 
	"LICENCE_POLICY" VARCHAR2(20 BYTE), 
	"LICENCE_POLICY_ETC" VARCHAR2(50 BYTE), 
	"TANGIBLE_ASSET_YN" VARCHAR2(50 BYTE), 
	"PROJECT_NO" VARCHAR2(20 BYTE), 
	"OPER_STATE" VARCHAR2(50 BYTE), 
	"SW_NM" VARCHAR2(50 BYTE), 
	"SW_INST_DT" DATE, 
	"SW_SN" VARCHAR2(50 BYTE), 
	"CLASS_DESC" VARCHAR2(100 BYTE), 
	"FREEWARE_YN" VARCHAR2(40 BYTE)
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SW_20140904061629" 
   (	"CONF_NM" VARCHAR2(300 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"CLASS_ID" VARCHAR2(10 BYTE), 
	"CLASS_TYPE" VARCHAR2(10 BYTE), 
	"LICENCE_CNT" NUMBER, 
	"LICENCE_START_DT" DATE, 
	"LICENCE_END_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"ASSET_ID" VARCHAR2(20 BYTE), 
	"LICENSE_SORT" VARCHAR2(20 BYTE), 
	"VERSION" VARCHAR2(70 BYTE), 
	"INSTALL_DT" DATE, 
	"LICENCE_POLICY" VARCHAR2(20 BYTE), 
	"LICENCE_POLICY_ETC" VARCHAR2(50 BYTE), 
	"TANGIBLE_ASSET_YN" VARCHAR2(50 BYTE), 
	"PROJECT_NO" VARCHAR2(20 BYTE), 
	"OPER_STATE" VARCHAR2(50 BYTE), 
	"SW_NM" VARCHAR2(50 BYTE), 
	"SW_INST_DT" DATE, 
	"SW_SN" VARCHAR2(50 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_SW_GROUP
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_SW_GROUP" 
   (	"SW_GROUP_ID" NUMBER, 
	"SW_GROUP_NAME" VARCHAR2(200 BYTE), 
	"P_SW_GROUP_ID" NUMBER, 
	"PRODUCT_FAMILY_YN" CHAR(1 BYTE), 
	"SW_ISSUES_YN" CHAR(1 BYTE), 
	"OBJECT_ID" NUMBER(*,0), 
	"SW_GROUP_VERSION" VARCHAR2(50 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_SW_LICENCE" 
   (	"CONF_ID" VARCHAR2(20 BYTE), 
	"IDX" NUMBER, 
	"LICENCE_TYPE" VARCHAR2(40 BYTE), 
	"LICENCE_CNT" NUMBER, 
	"LICENCE_ACQ_DATE" DATE, 
	"LICENCE_EXPIRE_DATE" DATE, 
	"UNIT_COST" NUMBER, 
	"TOT_COST" NUMBER, 
	"REMARKS" VARCHAR2(500 BYTE), 
	"UPD_USER_ID" VARCHAR2(100 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_TBL_ATTR_MAPPING" 
   (	"GEN_TABLE_NM" VARCHAR2(100 BYTE), 
	"COL_ID" VARCHAR2(400 BYTE), 
	"SORT" NUMBER, 
	"GEN_YN" CHAR(1 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_TBL_ATTR_MAPPING_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_TBL_ATTR_MAPPING_BACK" 
   (	"GEN_TABLE_NM" VARCHAR2(100 BYTE), 
	"COL_ID" VARCHAR2(400 BYTE), 
	"SORT" NUMBER, 
	"GEN_YN" CHAR(1 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_TBL_BACKUP_HITORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_TBL_BACKUP_HITORY" 
   (	"GEN_TABLE_NM" VARCHAR2(100 BYTE), 
	"BACK_TABLE_NM" VARCHAR2(100 BYTE), 
	"CRE_USER" VARCHAR2(40 BYTE), 
	"CRE_DT" DATE
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_TBL_GEN
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_TBL_GEN" 
   (	"GEN_TABLE_NM" VARCHAR2(100 BYTE), 
	"GEN_TABLE_NM_LOG" VARCHAR2(50 BYTE), 
	"GEN_TABLE_DESC" VARCHAR2(4000 BYTE), 
	"BASE_TBL_YN" CHAR(1 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"GEN_YN" CHAR(1 BYTE), 
	"GEN_DT" DATE, 
	"GEN_USER" VARCHAR2(40 BYTE), 
	"EMS_YN" CHAR(1 BYTE), 
	"EMS_TBL_NM" VARCHAR2(40 BYTE), 
	"DCA_YN" CHAR(1 BYTE), 
	"DCA_TBL_NM" VARCHAR2(40 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_TBL_JOIN
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_TBL_JOIN" 
   (	"ENTITY_ID" VARCHAR2(20 BYTE), 
	"LEFT_COL_ID" VARCHAR2(100 BYTE), 
	"RIGHT_COL_ID" VARCHAR2(100 BYTE), 
	"SET_TYPE" CHAR(1 BYTE), 
	"SORT" NUMBER
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table AM_YY_CITM
--------------------------------------------------------

  CREATE TABLE "ITSM"."AM_YY_CITM" 
   (	"FSCL_YY" VARCHAR2(4 BYTE), 
	"CITM_CD" VARCHAR2(4 BYTE), 
	"CITM_NM" VARCHAR2(400 BYTE), 
	"USE_YN" VARCHAR2(1 BYTE), 
	"DEL_DT" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."AM_YY_EITM" 
   (	"FSCL_YY" VARCHAR2(4 BYTE), 
	"CITM_CD" VARCHAR2(4 BYTE), 
	"EITM_CD" VARCHAR2(4 BYTE), 
	"EITM_NM" VARCHAR2(400 BYTE), 
	"USE_YN" VARCHAR2(1 BYTE), 
	"DEL_DT" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."ASSET_TEMP_DATA" 
   (	"ASSET_TEMP_ID" VARCHAR2(20 BYTE), 
	"CONF_TEMP_ID" VARCHAR2(20 BYTE), 
	"SEQ" NUMBER, 
	"TABLE_NM" VARCHAR2(40 BYTE), 
	"COLUMN_ID" VARCHAR2(40 BYTE), 
	"COLUMN_NM" VARCHAR2(40 BYTE), 
	"COL_VALUE" VARCHAR2(40 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ASSET_TEMP_MAPPING
--------------------------------------------------------

  CREATE TABLE "ITSM"."ASSET_TEMP_MAPPING" 
   (	"TEMP_SEQ" VARCHAR2(20 BYTE), 
	"ASSET_TEMP_ID" VARCHAR2(20 BYTE), 
	"CONF_TEMP_ID" VARCHAR2(20 BYTE), 
	"STATUS" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ASSET_TEMP_REL_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."ASSET_TEMP_REL_DATA" 
   (	"CONF_TEMP_ID" VARCHAR2(20 BYTE), 
	"REL_CONF_ID" VARCHAR2(20 BYTE), 
	"CONF_TYPE" VARCHAR2(40 BYTE), 
	"IF_TYPE" VARCHAR2(40 BYTE), 
	"CONTENT" VARCHAR2(1000 BYTE), 
	"RAID_TYPE" VARCHAR2(40 BYTE), 
	"INSTALL_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ASSET_TEMP_SEQ
--------------------------------------------------------

  CREATE TABLE "ITSM"."ASSET_TEMP_SEQ" 
   (	"TEMP_SEQ" VARCHAR2(20 BYTE), 
	"TITLE" VARCHAR2(200 BYTE), 
	"CLASS_ID" VARCHAR2(40 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ASSET_TEMP_SERVICE_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."ASSET_TEMP_SERVICE_DATA" 
   (	"CONF_TEMP_ID" VARCHAR2(20 BYTE), 
	"SERVICE_ID" VARCHAR2(10 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ATTACHMENT
--------------------------------------------------------

  CREATE TABLE "ITSM"."ATTACHMENT" 
   (	"ID" NUMBER(19,0), 
	"ACCESSTYPE" NUMBER(10,0), 
	"ATTACHEDAT" DATE, 
	"ATTACHMENTCONTENTID" NUMBER(19,0), 
	"CONTENTTYPE" VARCHAR2(255 BYTE), 
	"NAME" VARCHAR2(255 BYTE), 
	"ATTACHMENT_SIZE" NUMBER(10,0), 
	"ATTACHEDBY_ID" VARCHAR2(255 BYTE), 
	"TASKDATA_ATTACHMENTS_ID" NUMBER(19,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table BOOLEANEXPRESSION
--------------------------------------------------------

  CREATE TABLE "ITSM"."BOOLEANEXPRESSION" 
   (	"ID" NUMBER(19,0), 
	"EXPRESSION" CLOB, 
	"TYPE" VARCHAR2(255 BYTE), 
	"ESCALATION_CONSTRAINTS_ID" NUMBER(19,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table BULLETIN
--------------------------------------------------------

  CREATE TABLE "ITSM"."BULLETIN" 
   (	"BULLETIN_ID" NUMBER(*,0), 
	"REGISTER_USER_ID" VARCHAR2(255 BYTE), 
	"REGISTER_USER_NAME" VARCHAR2(255 BYTE), 
	"TARGET_ROLE_ID" NUMBER(*,0), 
	"EXPIRATION_DATE" TIMESTAMP (6), 
	"IS_EXPIRED" NUMBER(1,0), 
	"TITLE" VARCHAR2(4000 BYTE), 
	"CONTENTS" VARCHAR2(4000 BYTE), 
	"REGISTER_DATE" TIMESTAMP (6), 
	"IS_POPUP" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CATALOG
--------------------------------------------------------

  CREATE TABLE "ITSM"."CATALOG" 
   (	"CATALOG_ID" VARCHAR2(10 BYTE), 
	"CATALOG_NM" VARCHAR2(50 BYTE), 
	"UP_CATALOG_ID" VARCHAR2(10 BYTE), 
	"DESCR" VARCHAR2(200 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CATALOG_ITEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."CATALOG_ITEM" 
   (	"CATALOG_ID" VARCHAR2(10 BYTE), 
	"MCLASS_ID" VARCHAR2(5 BYTE), 
	"SLA_YN" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CHECK_LIST_ANSWER_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."CHECK_LIST_ANSWER_BACK" 
   (	"QUE_ID" VARCHAR2(10 BYTE), 
	"CHECK_LIST_ID" VARCHAR2(10 BYTE), 
	"WORK_DT" VARCHAR2(8 BYTE), 
	"REG_USER" VARCHAR2(40 BYTE), 
	"REG_DT" DATE, 
	"UPD_USER" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"WORK_STATE" VARCHAR2(1 BYTE), 
	"ANS_DATA1" VARCHAR2(1 BYTE), 
	"ANS_DATA2" VARCHAR2(1 BYTE), 
	"ANS_DATA3" VARCHAR2(1 BYTE), 
	"ANS_DATA4" VARCHAR2(1 BYTE), 
	"ANS_DATA5" VARCHAR2(1 BYTE), 
	"ANS_DATA6" VARCHAR2(1 BYTE), 
	"ANS_DATA7" VARCHAR2(1 BYTE), 
	"ANS_DATA8" VARCHAR2(1 BYTE), 
	"ANS_DATA9" VARCHAR2(1 BYTE), 
	"ANS_DATA10" VARCHAR2(1 BYTE), 
	"ANS_DATA11" VARCHAR2(1 BYTE), 
	"ANS_DATA12" VARCHAR2(1 BYTE), 
	"ANS_DATA13" VARCHAR2(1 BYTE), 
	"ANS_DATA14" VARCHAR2(1 BYTE), 
	"ANS_DATA15" VARCHAR2(1 BYTE), 
	"ANS_DATA16" VARCHAR2(1 BYTE), 
	"ANS_DATA17" VARCHAR2(1 BYTE), 
	"ANS_DATA18" VARCHAR2(1 BYTE), 
	"ANS_DATA19" VARCHAR2(1 BYTE), 
	"ANS_DATA20" VARCHAR2(1 BYTE), 
	"ANS_DATA21" VARCHAR2(1 BYTE), 
	"ANS_DATA22" VARCHAR2(1 BYTE), 
	"ANS_DATA23" VARCHAR2(1 BYTE), 
	"ANS_DATA24" VARCHAR2(1 BYTE), 
	"ANS_DATA25" VARCHAR2(1 BYTE), 
	"ANS_DATA26" VARCHAR2(1 BYTE), 
	"ANS_DATA27" VARCHAR2(1 BYTE), 
	"ANS_DATA28" VARCHAR2(1 BYTE), 
	"ANS_DATA29" VARCHAR2(1 BYTE), 
	"ANS_DATA30" VARCHAR2(1 BYTE), 
	"UP_CHECK_LIST_ID" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CHECK_LIST_ANS_DETAIL
--------------------------------------------------------

  CREATE TABLE "ITSM"."CHECK_LIST_ANS_DETAIL" 
   (	"ANS_DATA1" VARCHAR2(1 BYTE), 
	"ANS_DATA2" VARCHAR2(1 BYTE), 
	"ANS_DATA3" VARCHAR2(1 BYTE), 
	"ANS_DATA4" VARCHAR2(1 BYTE), 
	"ANS_DATA5" VARCHAR2(1 BYTE), 
	"ANS_DATA6" VARCHAR2(1 BYTE), 
	"ANS_DATA7" VARCHAR2(1 BYTE), 
	"ANS_DATA8" VARCHAR2(1 BYTE), 
	"ANS_DATA9" VARCHAR2(1 BYTE), 
	"ANS_DATA10" VARCHAR2(1 BYTE), 
	"ANS_DATA11" VARCHAR2(1 BYTE), 
	"ANS_DATA12" VARCHAR2(1 BYTE), 
	"ANS_DATA13" VARCHAR2(1 BYTE), 
	"ANS_DATA14" VARCHAR2(1 BYTE), 
	"ANS_DATA15" VARCHAR2(1 BYTE), 
	"ANS_DATA16" VARCHAR2(1 BYTE), 
	"ANS_DATA17" VARCHAR2(1 BYTE), 
	"ANS_DATA18" VARCHAR2(1 BYTE), 
	"ANS_DATA19" VARCHAR2(1 BYTE), 
	"ANS_DATA20" VARCHAR2(1 BYTE), 
	"ANS_DATA21" VARCHAR2(1 BYTE), 
	"ANS_DATA22" VARCHAR2(1 BYTE), 
	"ANS_DATA23" VARCHAR2(1 BYTE), 
	"ANS_DATA24" VARCHAR2(1 BYTE), 
	"ANS_DATA25" VARCHAR2(1 BYTE), 
	"ANS_DATA26" VARCHAR2(1 BYTE), 
	"ANS_DATA27" VARCHAR2(1 BYTE), 
	"ANS_DATA28" VARCHAR2(1 BYTE), 
	"ANS_DATA29" VARCHAR2(1 BYTE), 
	"ANS_DATA30" VARCHAR2(1 BYTE), 
	"QUE_ID" VARCHAR2(10 BYTE), 
	"CHECK_LIST_ID" VARCHAR2(10 BYTE), 
	"WORK_DT" VARCHAR2(8 BYTE), 
	"UP_CHECK_LIST_ID" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CHECK_LIST_ANS_MASTER
--------------------------------------------------------

  CREATE TABLE "ITSM"."CHECK_LIST_ANS_MASTER" 
   (	"WORK_DT" VARCHAR2(8 BYTE), 
	"WORK_STATE" VARCHAR2(1 BYTE), 
	"REG_USER" VARCHAR2(40 BYTE), 
	"UPD_USER" VARCHAR2(40 BYTE), 
	"REG_DT" DATE, 
	"UPD_DT" DATE, 
	"UP_CHECK_LIST_ID" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CHECK_LIST_COUNT
--------------------------------------------------------

  CREATE TABLE "ITSM"."CHECK_LIST_COUNT" 
   (	"NUM" NUMBER
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CHECK_LIST_MASTER
--------------------------------------------------------

  CREATE TABLE "ITSM"."CHECK_LIST_MASTER" 
   (	"CHECK_LIST_ID" VARCHAR2(10 BYTE), 
	"CHECK_LIST_NM" VARCHAR2(100 BYTE), 
	"UP_CHECK_LIST_ID" VARCHAR2(10 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" VARCHAR2(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"CHECK_LIST_DESC" VARCHAR2(2000 BYTE), 
	"REG_USER_ID" VARCHAR2(40 BYTE), 
	"REG_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CHECK_LIST_MASTER_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."CHECK_LIST_MASTER_BACK" 
   (	"CHECK_LIST_ID" VARCHAR2(10 BYTE), 
	"CHECK_LIST_NM" VARCHAR2(100 BYTE), 
	"UP_CHECK_LIST_ID" VARCHAR2(10 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" VARCHAR2(1 BYTE), 
	"CHECK_LIST_DESC" VARCHAR2(2000 BYTE), 
	"REG_USER_ID" VARCHAR2(40 BYTE), 
	"REG_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CHECK_LIST_QUESTION
--------------------------------------------------------

  CREATE TABLE "ITSM"."CHECK_LIST_QUESTION" 
   (	"QUE_DATA1" VARCHAR2(2000 BYTE), 
	"QUE_DATA2" VARCHAR2(2000 BYTE), 
	"QUE_DATA3" VARCHAR2(2000 BYTE), 
	"QUE_DATA4" VARCHAR2(2000 BYTE), 
	"QUE_DATA5" VARCHAR2(2000 BYTE), 
	"QUE_DATA6" VARCHAR2(2000 BYTE), 
	"QUE_DATA7" VARCHAR2(2000 BYTE), 
	"QUE_DATA8" VARCHAR2(2000 BYTE), 
	"QUE_DATA9" VARCHAR2(2000 BYTE), 
	"QUE_DATA10" VARCHAR2(2000 BYTE), 
	"QUE_DATA11" VARCHAR2(2000 BYTE), 
	"QUE_DATA12" VARCHAR2(2000 BYTE), 
	"QUE_DATA13" VARCHAR2(2000 BYTE), 
	"QUE_DATA14" VARCHAR2(2000 BYTE), 
	"QUE_DATA15" VARCHAR2(2000 BYTE), 
	"QUE_DATA16" VARCHAR2(2000 BYTE), 
	"QUE_DATA17" VARCHAR2(2000 BYTE), 
	"QUE_DATA18" VARCHAR2(2000 BYTE), 
	"QUE_DATA19" VARCHAR2(2000 BYTE), 
	"QUE_DATA20" VARCHAR2(2000 BYTE), 
	"QUE_DATA21" VARCHAR2(2000 BYTE), 
	"QUE_DATA22" VARCHAR2(2000 BYTE), 
	"QUE_DATA23" VARCHAR2(2000 BYTE), 
	"QUE_DATA24" VARCHAR2(2000 BYTE), 
	"QUE_DATA25" VARCHAR2(2000 BYTE), 
	"QUE_DATA26" VARCHAR2(2000 BYTE), 
	"QUE_DATA27" VARCHAR2(2000 BYTE), 
	"QUE_DATA28" VARCHAR2(2000 BYTE), 
	"QUE_DATA29" VARCHAR2(2000 BYTE), 
	"QUE_DATA30" VARCHAR2(2000 BYTE), 
	"QUE_ID" VARCHAR2(10 BYTE), 
	"CHECK_LIST_ID" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CHECK_LIST_QUESTION_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."CHECK_LIST_QUESTION_BACK" 
   (	"QUE_ID" VARCHAR2(10 BYTE), 
	"CHECK_LIST_ID" VARCHAR2(10 BYTE), 
	"QUE_DATA1" VARCHAR2(2000 BYTE), 
	"QUE_DATA2" VARCHAR2(2000 BYTE), 
	"QUE_DATA3" VARCHAR2(2000 BYTE), 
	"QUE_DATA4" VARCHAR2(2000 BYTE), 
	"QUE_DATA5" VARCHAR2(2000 BYTE), 
	"QUE_DATA6" VARCHAR2(2000 BYTE), 
	"QUE_DATA7" VARCHAR2(2000 BYTE), 
	"QUE_DATA8" VARCHAR2(2000 BYTE), 
	"QUE_DATA9" VARCHAR2(2000 BYTE), 
	"QUE_DATA10" VARCHAR2(2000 BYTE), 
	"QUE_DATA11" VARCHAR2(2000 BYTE), 
	"QUE_DATA12" VARCHAR2(2000 BYTE), 
	"QUE_DATA13" VARCHAR2(2000 BYTE), 
	"QUE_DATA14" VARCHAR2(2000 BYTE), 
	"QUE_DATA15" VARCHAR2(2000 BYTE), 
	"QUE_DATA16" VARCHAR2(2000 BYTE), 
	"QUE_DATA17" VARCHAR2(2000 BYTE), 
	"QUE_DATA18" VARCHAR2(2000 BYTE), 
	"QUE_DATA19" VARCHAR2(2000 BYTE), 
	"QUE_DATA20" VARCHAR2(2000 BYTE), 
	"QUE_DATA21" VARCHAR2(2000 BYTE), 
	"QUE_DATA22" VARCHAR2(2000 BYTE), 
	"QUE_DATA23" VARCHAR2(2000 BYTE), 
	"QUE_DATA24" VARCHAR2(2000 BYTE), 
	"QUE_DATA25" VARCHAR2(2000 BYTE), 
	"QUE_DATA26" VARCHAR2(2000 BYTE), 
	"QUE_DATA27" VARCHAR2(2000 BYTE), 
	"QUE_DATA28" VARCHAR2(2000 BYTE), 
	"QUE_DATA29" VARCHAR2(2000 BYTE), 
	"QUE_DATA30" VARCHAR2(2000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table COMMAND_FORBIDDEN
--------------------------------------------------------

  CREATE TABLE "ITSM"."COMMAND_FORBIDDEN" 
   (	"COMMAND_ID" NUMBER(*,0), 
	"COMMAND" VARCHAR2(4000 BYTE), 
	"IS_ENABLE" NUMBER(1,0), 
	"IS_SYSTEM_RESERVED" NUMBER(1,0), 
	"DESCRIPTION" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table COMMAND_INSTANT
--------------------------------------------------------

  CREATE TABLE "ITSM"."COMMAND_INSTANT" 
   (	"COMMAND_ID" NUMBER(10,0), 
	"USER_ID" VARCHAR2(255 CHAR), 
	"NAME" VARCHAR2(255 CHAR), 
	"DESCRIPTION" VARCHAR2(4000 CHAR), 
	"IS_SHARED" NUMBER(1,0), 
	"COMMAND" LONG, 
	"SCRIPT_TYPE" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table COMMAND_REGISTERED
--------------------------------------------------------

  CREATE TABLE "ITSM"."COMMAND_REGISTERED" 
   (	"COMMAND_ID" NUMBER(*,0), 
	"NAME" VARCHAR2(255 BYTE), 
	"COMMAND" VARCHAR2(4000 BYTE), 
	"SCRIPT_TYPE" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table COMPLIANCE
--------------------------------------------------------

  CREATE TABLE "ITSM"."COMPLIANCE" 
   (	"COMPLIANCE_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table COMPLIANCE_EXCEPTED
--------------------------------------------------------

  CREATE TABLE "ITSM"."COMPLIANCE_EXCEPTED" 
   (	"POLICY_ID" NUMBER(*,0), 
	"DEVICE_ID" NUMBER(*,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table COMPLIANCE_POLICY_ATTR
--------------------------------------------------------

  CREATE TABLE "ITSM"."COMPLIANCE_POLICY_ATTR" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"POLICY_ID" NUMBER(*,0), 
	"ATTRIBUTE_NAME" VARCHAR2(255 BYTE), 
	"UNIT" VARCHAR2(255 BYTE), 
	"DATA_TYPE" VARCHAR2(255 BYTE), 
	"IS_WRITABLE" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table COMPLIANCE_POLICY_OP
--------------------------------------------------------

  CREATE TABLE "ITSM"."COMPLIANCE_POLICY_OP" 
   (	"OPERATION_ID" NUMBER(*,0), 
	"POLICY_ID" NUMBER(*,0), 
	"OPERATION_NAME" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table COMPLIANCE_POLICY_RULE
--------------------------------------------------------

  CREATE TABLE "ITSM"."COMPLIANCE_POLICY_RULE" 
   (	"RULE_ID" NUMBER(*,0), 
	"POLICY_ID" NUMBER(*,0), 
	"DATA_TYPE" VARCHAR2(255 BYTE), 
	"TARGET_ATTRIBUTE_NAME" VARCHAR2(255 BYTE), 
	"COMPARISON_OPERATOR" VARCHAR2(100 BYTE), 
	"IS_CONJUNCTION" NUMBER(1,0), 
	"RULE_ORDER" NUMBER(*,0), 
	"INTEGER_VALUE" NUMBER(*,0), 
	"INTEGER_VALUE2" NUMBER(*,0), 
	"DOUBLE_VALUE" FLOAT(126), 
	"DOUBLE_VALUE2" FLOAT(126), 
	"DATE_VALUE" TIMESTAMP (6), 
	"DATE_VALUE2" TIMESTAMP (6), 
	"STRING_VALUE" VARCHAR2(4000 BYTE), 
	"BOOLEAN_VALUE" NUMBER(1,0), 
	"LONG_VALUE" NUMBER(*,0), 
	"LONG_VALUE2" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CONFIG_DICTIONARY
--------------------------------------------------------

  CREATE TABLE "ITSM"."CONFIG_DICTIONARY" 
   (	"CONFIG_ID" NUMBER(*,0), 
	"CONFIG_NAME" VARCHAR2(255 BYTE), 
	"GRAMMAR_NAME" VARCHAR2(255 BYTE), 
	"OS_TYPE" VARCHAR2(255 BYTE), 
	"USE_SYSTEM_ENCODING" NUMBER(1,0), 
	"ENCODING_TYPE" VARCHAR2(255 BYTE), 
	"CLASSIFICATION" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"UUID" VARCHAR2(255 CHAR)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CONFIG_FILE
--------------------------------------------------------

  CREATE TABLE "ITSM"."CONFIG_FILE" 
   (	"CONFIG_ID" NUMBER(*,0), 
	"CONFIG_FILE" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CONFIG_NETWORK_OID
--------------------------------------------------------

  CREATE TABLE "ITSM"."CONFIG_NETWORK_OID" 
   (	"OID_ID" NUMBER(10,0), 
	"OID" VARCHAR2(255 CHAR), 
	"OID_ORDER" NUMBER(10,0), 
	"CONFIG_ID" NUMBER(10,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CONFIG_OMP_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."CONFIG_OMP_OBJECT" 
   (	"CONFIG_ID" NUMBER(*,0), 
	"OID" VARCHAR2(255 BYTE), 
	"IS_SINGULAR" NUMBER(1,0), 
	"SECTION_NAME" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table CONTENT
--------------------------------------------------------

  CREATE TABLE "ITSM"."CONTENT" 
   (	"ID" NUMBER(19,0), 
	"CONTENT" BLOB
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DASHBOARD_GADGET
--------------------------------------------------------

  CREATE TABLE "ITSM"."DASHBOARD_GADGET" 
   (	"GADGET_ID" VARCHAR2(255 BYTE), 
	"GADGET_NAME" VARCHAR2(255 BYTE), 
	"GADGET_TYPE" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"PROVIDER" VARCHAR2(4000 BYTE), 
	"GADGET_VERSION" FLOAT(126)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DASHBOARD_USER
--------------------------------------------------------

  CREATE TABLE "ITSM"."DASHBOARD_USER" 
   (	"USER_ID" VARCHAR2(255 BYTE), 
	"DASHBOARD_ID" NUMBER(*,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DATA_TYPE
--------------------------------------------------------

  CREATE TABLE "ITSM"."DATA_TYPE" 
   (	"DATA_TYPE" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DATA_TYPE_COMPARISON_OPERATOR
--------------------------------------------------------

  CREATE TABLE "ITSM"."DATA_TYPE_COMPARISON_OPERATOR" 
   (	"OPERATOR_ID" NUMBER(*,0), 
	"DATA_TYPE" VARCHAR2(255 BYTE), 
	"COMPARISON_OPERATOR" VARCHAR2(255 BYTE), 
	"NUM_OF_DATA" NUMBER(*,0), 
	"IS_USE_SMART_GROUP" NUMBER(1,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DEADLINE
--------------------------------------------------------

  CREATE TABLE "ITSM"."DEADLINE" 
   (	"ID" NUMBER(19,0), 
	"DEADLINE_DATE" DATE, 
	"ESCALATED" NUMBER(5,0), 
	"DEADLINES_STARTDEADLINE_ID" NUMBER(19,0), 
	"DEADLINES_ENDDEADLINE_ID" NUMBER(19,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DELEGATION_DELEGATES
--------------------------------------------------------

  CREATE TABLE "ITSM"."DELEGATION_DELEGATES" 
   (	"TASK_ID" NUMBER(19,0), 
	"ENTITY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DEVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."DEVICE" 
   (	"DEVICE_ID" NUMBER(*,0), 
	"HOSTNAME" VARCHAR2(255 BYTE), 
	"IP_ADDRESS" VARCHAR2(255 BYTE), 
	"OS_VERSION" VARCHAR2(255 BYTE), 
	"REACHABLE" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DEVICE_NETWORK
--------------------------------------------------------

  CREATE TABLE "ITSM"."DEVICE_NETWORK" 
   (	"DEVICE_ID" NUMBER(*,0), 
	"SNMP_VERSION" NUMBER(10,0), 
	"SNMP_PORT" NUMBER(10,0), 
	"READ_COMMUNITY" VARCHAR2(255 CHAR), 
	"WRITE_COMMUNITY" VARCHAR2(255 CHAR), 
	"NETWORK_TYPE" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DEVICE_SERVER
--------------------------------------------------------

  CREATE TABLE "ITSM"."DEVICE_SERVER" 
   (	"DEVICE_ID" NUMBER(*,0), 
	"AGENT_PORT" NUMBER(*,0), 
	"AGENT_KEY" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DEVICE_STORAGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."DEVICE_STORAGE" 
   (	"DEVICE_ID" NUMBER(10,0), 
	"STORAGE_TYPE" VARCHAR2(255 CHAR), 
	"GATEWAY_NAME" VARCHAR2(255 CHAR), 
	"GATEWAY_IP" VARCHAR2(255 CHAR), 
	"PROVIDER_URL" VARCHAR2(255 CHAR), 
	"PROVIDER_USER" VARCHAR2(255 CHAR), 
	"PROVIDER_PW" VARCHAR2(255 CHAR), 
	"PROVIDER_NAMESPACE" VARCHAR2(255 CHAR), 
	"STSPA_IP" VARCHAR2(255 CHAR), 
	"STSPB_IP" VARCHAR2(255 CHAR), 
	"GATEWAY_PORT" NUMBER(10,0), 
	"PROVIDER_KEY" VARCHAR2(255 CHAR), 
	"OBJECT_KEY" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DM_ADDITIONAL_PORT
--------------------------------------------------------

  CREATE TABLE "ITSM"."DM_ADDITIONAL_PORT" 
   (	"PORT_ID" NUMBER(*,0), 
	"SERVICE_ID" NUMBER(*,0), 
	"PORT_NUM" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DM_CONTACT
--------------------------------------------------------

  CREATE TABLE "ITSM"."DM_CONTACT" 
   (	"CONTACT_ID" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0), 
	"DIRECTION" NUMBER(10,0), 
	"IS_SKIP_VISUALIZATION" NUMBER(1,0), 
	"IS_STRONG" NUMBER(1,0), 
	"DEVICE_TYPE" VARCHAR2(255 CHAR), 
	"IS_LIVE_OBJECT_CONTACT" NUMBER(1,0), 
	"LIVE_OBJECT_NAME" VARCHAR2(255 CHAR), 
	"DISPLAY_NAME" VARCHAR2(255 CHAR), 
	"CONTACT_TYPE" VARCHAR2(255 CHAR), 
	"LINK_KEY" VARCHAR2(255 CHAR), 
	"LINK_KEY_TYPE" VARCHAR2(255 CHAR), 
	"IS_HAS_OUTBOUND_LINK" NUMBER(1,0), 
	"IS_HAS_INBOUND_LINK" NUMBER(1,0), 
	"PERSISTED_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DM_DLINK
--------------------------------------------------------

  CREATE TABLE "ITSM"."DM_DLINK" 
   (	"LINK_ID" NUMBER(10,0), 
	"INBOUND_CONTACT_ID" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0), 
	"LINK_DISPLAY_NAME" VARCHAR2(255 CHAR), 
	"LINK_TYPE" VARCHAR2(255 CHAR), 
	"LINK_KEY" VARCHAR2(255 CHAR), 
	"LINK_KEY_TYPE" VARCHAR2(255 CHAR), 
	"OUTBOUND_CONTACT_ID" NUMBER(10,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DM_LINK
--------------------------------------------------------

  CREATE TABLE "ITSM"."DM_LINK" 
   (	"LINK_ID" NUMBER(*,0), 
	"SOURCE_NODE_ID" NUMBER(*,0), 
	"TARGET_NODE_ID" NUMBER(*,0), 
	"SERVICE_ID" NUMBER(*,0), 
	"PORT_NUM" NUMBER(*,0), 
	"SCAN_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DM_NODE
--------------------------------------------------------

  CREATE TABLE "ITSM"."DM_NODE" 
   (	"NODE_ID" NUMBER(*,0), 
	"DEVICE_ID" NUMBER(*,0), 
	"HOSTNAME" VARCHAR2(255 BYTE), 
	"IP_ADDRESS" VARCHAR2(255 BYTE), 
	"IS_AGENT" NUMBER(1,0), 
	"SCAN_DATE" TIMESTAMP (6), 
	"NODE_TYPE" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table DM_SERVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."DM_SERVICE" 
   (	"SERVICE_ID" NUMBER(*,0), 
	"SERVICE_NAME" VARCHAR2(255 BYTE), 
	"SERVICE_TYPE" VARCHAR2(255 BYTE), 
	"DEFAULT_PORT" NUMBER(*,0), 
	"DESCRIPTION" VARCHAR2(4000 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table EMS_SMSQUEUE
--------------------------------------------------------

  CREATE TABLE "ITSM"."EMS_SMSQUEUE" 
   (	"SEQ" NUMBER(18,0), 
	"SMS_CODE" VARCHAR2(3 BYTE), 
	"TO_NAME" VARCHAR2(80 BYTE), 
	"TO_PHONE" VARCHAR2(100 BYTE), 
	"FROM_NAME" VARCHAR2(80 BYTE), 
	"FROM_PHONE" VARCHAR2(100 BYTE), 
	"REG_DATE" DATE DEFAULT SYSDATE, 
	"MAP1" VARCHAR2(100 BYTE), 
	"MAP2" VARCHAR2(100 BYTE), 
	"MAP3" VARCHAR2(100 BYTE), 
	"MAP4" VARCHAR2(100 BYTE), 
	"MAP5" VARCHAR2(100 BYTE), 
	"MAP_CONTENT" VARCHAR2(2000 BYTE), 
	"TARGET_FLAG" VARCHAR2(1 BYTE) DEFAULT 'N', 
	"TARGET_DATE" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ESCALATION
--------------------------------------------------------

  CREATE TABLE "ITSM"."ESCALATION" 
   (	"ID" NUMBER(19,0), 
	"NAME" VARCHAR2(255 BYTE), 
	"DEADLINE_ESCALATION_ID" NUMBER(19,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table EVENTTYPES
--------------------------------------------------------

  CREATE TABLE "ITSM"."EVENTTYPES" 
   (	"INSTANCEID" NUMBER(19,0), 
	"ELEMENT" VARCHAR2(255 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table E_2
--------------------------------------------------------

  CREATE TABLE "ITSM"."E_2" 
   (	"DASHBOARD_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table GRAMMAR_DICTIONARY
--------------------------------------------------------

  CREATE TABLE "ITSM"."GRAMMAR_DICTIONARY" 
   (	"GRAMMAR_NAME" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table HIBERNATE_SEQUENCES
--------------------------------------------------------

  CREATE TABLE "ITSM"."HIBERNATE_SEQUENCES" 
   (	"SEQUENCE_NAME" VARCHAR2(255 BYTE), 
	"NEXT_VAL" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table HT_DEVICE
--------------------------------------------------------

  CREATE GLOBAL TEMPORARY TABLE "ITSM"."HT_DEVICE" 
   (	"DEVICE_ID" NUMBER(10,0)
   ) ON COMMIT DELETE ROWS ;
--------------------------------------------------------
--  DDL for Table HT_JOB
--------------------------------------------------------

  CREATE GLOBAL TEMPORARY TABLE "ITSM"."HT_JOB" 
   (	"JOB_ID" NUMBER(10,0)
   ) ON COMMIT DELETE ROWS ;
--------------------------------------------------------
--  DDL for Table I18NTEXT
--------------------------------------------------------

  CREATE TABLE "ITSM"."I18NTEXT" 
   (	"ID" NUMBER(19,0), 
	"LANGUAGE" VARCHAR2(255 BYTE), 
	"SHORTTEXT" VARCHAR2(255 BYTE), 
	"TEXT" CLOB, 
	"NOTIFICATION_SUBJECTS_ID" NUMBER(19,0), 
	"NOTIFICATION_NAMES_ID" NUMBER(19,0), 
	"NOTIFICATION_DOCUMENTATION_ID" NUMBER(19,0), 
	"NOTIFICATION_DESCRIPTIONS_ID" NUMBER(19,0), 
	"REASSIGNMENT_DOCUMENTATION_ID" NUMBER(19,0), 
	"DEADLINE_DOCUMENTATION_ID" NUMBER(19,0), 
	"TASK_SUBJECTS_ID" NUMBER(19,0), 
	"TASK_NAMES_ID" NUMBER(19,0), 
	"TASK_DESCRIPTIONS_ID" NUMBER(19,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DCA_INSTALLED_SW
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DCA_INSTALLED_SW" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"DISPLAYNAME" VARCHAR2(511 CHAR), 
	"SWNAME" VARCHAR2(255 CHAR), 
	"VERSION" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0), 
	"SWMASTER_ID" NUMBER(10,0), 
	"UNIQNAME" VARCHAR2(255 CHAR), 
	"SCRIPTVERSION" VARCHAR2(255 CHAR), 
	"PERMITTED" VARCHAR2(5 BYTE), 
	"MANAGED" VARCHAR2(5 BYTE), 
	"INSTALLEDDATE" TIMESTAMP (6), 
	"CREATED_DATE" TIMESTAMP (6), 
	"PERSISTED_DATE" TIMESTAMP (6), 
	"CLASSIFICATION" VARCHAR2(4000 BYTE)
   )TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DCA_NW_INTERFACE
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DCA_NW_INTERFACE" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0), 
	"IF_INDEX" NUMBER(10,0), 
	"IF_DESCR" VARCHAR2(255 CHAR), 
	"IF_PHYADDRESS" VARCHAR2(255 CHAR), 
	"IF_TYPE" VARCHAR2(255 CHAR), 
	"IF_MTU" NUMBER(10,0), 
	"IF_SPEED" NUMBER(19,0), 
	"IF_ADMIN_STATUS" VARCHAR2(255 CHAR), 
	"IF_OPER_STATUS" VARCHAR2(255 CHAR), 
	"IF_NAME" VARCHAR2(255 CHAR), 
	"IF_ALIAS" VARCHAR2(255 CHAR), 
	"AD_ADDRESS" VARCHAR2(255 CHAR), 
	"AD_NETMASK" VARCHAR2(255 CHAR), 
	"PORT" NUMBER(10,0), 
	"PERSISTED_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DCA_NW_SYSTEM_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DCA_NW_SYSTEM_INFO" 
   (	"DEVICE_ID" NUMBER(*,0), 
	"SYSOBJECTID" VARCHAR2(4000 BYTE), 
	"SYSUPTIME" TIMESTAMP (6), 
	"SYSDESCR" VARCHAR2(4000 BYTE), 
	"SYSLOCATION" VARCHAR2(4000 BYTE), 
	"SYSCONTACT" VARCHAR2(4000 BYTE), 
	"SYSNAME" VARCHAR2(4000 BYTE), 
	"MODEL" VARCHAR2(4000 BYTE), 
	"VENDOR" VARCHAR2(4000 BYTE), 
	"OSVERSION" VARCHAR2(4000 BYTE), 
	"LAST_MODIFIED_DATE" TIMESTAMP (6), 
	"PERSISTED_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DCA_SERVER_CPUS
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DCA_SERVER_CPUS" 
   (	"DEVICE_ID" NUMBER(*,0), 
	"CLOCK" VARCHAR2(4000 BYTE), 
	"CPUCOUNT" NUMBER, 
	"MODEL" VARCHAR2(4000 BYTE), 
	"VENDOR" VARCHAR2(4000 BYTE), 
	"LAST_MODIFIED_DATE" TIMESTAMP (6), 
	"PERSISTED_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DCA_SERVER_DISK
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DCA_SERVER_DISK" 
   (	"DEVICE_ID" NUMBER(*,0), 
	"DISK_NAME" VARCHAR2(4000 BYTE), 
	"CAPACITY" NUMBER, 
	"VENDOR" VARCHAR2(4000 BYTE), 
	"LAST_MODIFIED_DATE" TIMESTAMP (6), 
	"PERSISTED_DATE" TIMESTAMP (6), 
	"IDX" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DCA_SERVER_MEMORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DCA_SERVER_MEMORY" 
   (	"DEVICE_ID" NUMBER(*,0), 
	"CAPACITY" NUMBER, 
	"LAST_MODIFIED_DATE" TIMESTAMP (6), 
	"PERSISTED_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DCA_SERVER_NW_INTERFACE
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DCA_SERVER_NW_INTERFACE" 
   (	"DEVICE_ID" NUMBER(*,0), 
	"NIC_NAME" VARCHAR2(4000 BYTE), 
	"BANDWIDTH" NUMBER, 
	"IP" VARCHAR2(4000 BYTE), 
	"MAC" VARCHAR2(4000 BYTE), 
	"MTU" NUMBER, 
	"NETMASK" VARCHAR2(4000 BYTE), 
	"MANAGED" NUMBER, 
	"LAST_MODIFIED_DATE" TIMESTAMP (6), 
	"PERSISTED_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DCA_SERVER_OS
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DCA_SERVER_OS" 
   (	"DEVICE_ID" NUMBER(*,0), 
	"HOSTNAME" VARCHAR2(4000 BYTE), 
	"OSNAME" VARCHAR2(4000 BYTE), 
	"OSVERSION" VARCHAR2(4000 BYTE), 
	"PATCHLEVEL" VARCHAR2(4000 BYTE), 
	"SERIALNO" VARCHAR2(4000 BYTE), 
	"TIMEZONE" VARCHAR2(4000 BYTE), 
	"VENDOR" VARCHAR2(4000 BYTE), 
	"MODEL" VARCHAR2(4000 BYTE), 
	"OSBIT" VARCHAR2(4000 BYTE), 
	"LASTBOOTUPTIME" TIMESTAMP (6), 
	"UNIX_OSVERSION" VARCHAR2(4000 BYTE), 
	"WIN_OSVERSION" VARCHAR2(4000 BYTE), 
	"LAST_MODIFIED_DATE" TIMESTAMP (6), 
	"PERSISTED_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DCA_SW_MASTER_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DCA_SW_MASTER_OBJECT" 
   (	"OBJECT_ID" NUMBER(*,0), 
	"OBJECT_NAME" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"MASTER" NUMBER(1,0), 
	"DATE_CREATED" TIMESTAMP (6), 
	"DATE_MODIFIED" TIMESTAMP (6), 
	"USER_CREATED" VARCHAR2(255 BYTE), 
	"USER_MODIFIED" VARCHAR2(255 BYTE), 
	"CLASSIFICATION" VARCHAR2(4000 BYTE), 
	"IS_STARRED" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_DISK
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_DISK" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"INDX" VARCHAR2(10 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"VENDOR" VARCHAR2(300 BYTE), 
	"DISK_TYPE" VARCHAR2(100 BYTE), 
	"TOTAL_SIZE" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table IF_FILESYSTEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."IF_FILESYSTEM" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"DISK_NAME" VARCHAR2(100 BYTE), 
	"TOTAL_SIZE" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_NETWORK" 
   (	"MANAGER_ID" VARCHAR2(50 BYTE), 
	"NODE_ID" VARCHAR2(50 BYTE), 
	"HOSTNAME" VARCHAR2(50 BYTE), 
	"IPADDRESS" VARCHAR2(16 BYTE), 
	"VENDOR" VARCHAR2(300 BYTE), 
	"EQUIP_CATEGORY" VARCHAR2(20 BYTE), 
	"MODEL" VARCHAR2(300 BYTE), 
	"SYSTEM_DESCRIPTOR" VARCHAR2(300 BYTE), 
	"PORT_NUM" NUMBER, 
	"SERIAL_NUMBER" VARCHAR2(64 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_NIC" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"INDX" VARCHAR2(10 BYTE), 
	"MODEL" VARCHAR2(300 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_NIF" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"MAC_ADDRESS" VARCHAR2(50 BYTE), 
	"IPADDRESS" VARCHAR2(300 BYTE), 
	"NETMASK" VARCHAR2(100 BYTE), 
	"IF_TYPE" VARCHAR2(50 BYTE), 
	"BAND_WIDTH" NUMBER, 
	"MTU" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_NW_CPU" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_NW_FAN" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_NW_MEMORY" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"MEM_SIZE" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_NW_MODULE" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"MODULE_NAME" VARCHAR2(100 BYTE), 
	"SLO_NUM" VARCHAR2(40 BYTE), 
	"HW_VERSION" VARCHAR2(15 BYTE), 
	"SW_VERSION" VARCHAR2(15 BYTE), 
	"MODULE_TYPE" VARCHAR2(40 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_NW_PORT" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"IPADDRESS" VARCHAR2(40 BYTE), 
	"MAC_ADDRESS" VARCHAR2(50 BYTE), 
	"MTU" NUMBER, 
	"BAND_WIDTH" NUMBER, 
	"IF_TYPE" VARCHAR2(40 BYTE), 
	"IF_DESC" VARCHAR2(100 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_NW_POWER" 
   (	"NODE_ID" VARCHAR2(50 BYTE), 
	"INDX" VARCHAR2(40 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"INS_DATE" VARCHAR2(8 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_SERVER" 
   (	"MANAGER_ID" VARCHAR2(50 BYTE), 
	"NODE_ID" VARCHAR2(50 BYTE), 
	"VENDOR" VARCHAR2(300 BYTE), 
	"MODEL" VARCHAR2(300 BYTE), 
	"IPADDRESS" VARCHAR2(16 BYTE), 
	"HOSTNAME" VARCHAR2(50 BYTE), 
	"OS_TYPE" VARCHAR2(50 BYTE), 
	"OS_VERSION" VARCHAR2(100 BYTE), 
	"CPU_PHY_NUM" NUMBER, 
	"CPU_CORE_NUM" NUMBER, 
	"CPU_TYPE" VARCHAR2(50 BYTE), 
	"CPU_MODEL" VARCHAR2(100 BYTE), 
	"CPU_VENDOR" VARCHAR2(100 BYTE), 
	"CPU_CLOCK" NUMBER, 
	"MEM_SIZE" NUMBER, 
	"DISK_NUM" NUMBER, 
	"DISK_SIZE" NUMBER, 
	"INS_DATE" VARCHAR2(8 BYTE)
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."IF_SMS_EVENT_LOG" 
   (	"EVT_ID" VARCHAR2(40 BYTE), 
	"SV_ID" VARCHAR2(200 BYTE), 
	"EVT_NM" VARCHAR2(200 BYTE), 
	"EVT_MSG" VARCHAR2(4000 BYTE), 
	"EVT_DATE" DATE, 
	"SEVERITY" VARCHAR2(40 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB" 
   (	"JOB_ID" NUMBER(*,0), 
	"NUM_OF_THREADS" NUMBER(*,0), 
	"IS_PAUSE" NUMBER(1,0), 
	"NEXT_FIRE_TIME" TIMESTAMP (6), 
	"JOB_TIMEOUT" NUMBER(*,0), 
	"IS_SYSTEM_RESERVED" NUMBER(1,0), 
	"IS_NOTI_MAIL" NUMBER(1,0), 
	"IS_NOTI_SMS" NUMBER(1,0), 
	"IS_NOTI_SUCCESS" NUMBER(1,0), 
	"IS_NOTI_FAIL" NUMBER(1,0), 
	"IS_NOTI_CREATED_USER" NUMBER(1,0), 
	"IS_NOTI_ROLE" NUMBER(1,0), 
	"IS_NOTI_TARGET" NUMBER(1,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_AUDIT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_AUDIT" 
   (	"JOB_ID" NUMBER(*,0), 
	"IS_AUDIT_WITH_MASTER_DEVICE" NUMBER(1,0), 
	"MASTER_DEVICE_ID" NUMBER(*,0), 
	"MASTER_SNAPSHOT_JOB_ID" NUMBER(*,0), 
	"AUDIT_WITH_LAST_SNAPSHOT" NUMBER(1,0), 
	"MASTER_SNAPSHOT_JOB_RUN_ID" NUMBER(*,0), 
	"AUDIT_MASTER_TYPE" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_BATCH
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_BATCH" 
   (	"JOB_ID" NUMBER(*,0), 
	"IS_EXECUTE_PARALLEL" NUMBER(1,0), 
	"IS_OWN_DEVICES" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_BATCH_ITEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_BATCH_ITEM" 
   (	"ITEM_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"TARGET_JOB_ID" NUMBER(*,0), 
	"EXECUTING_ORDER" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_COLLECT_FILE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_COLLECT_FILE" 
   (	"JOB_ID" NUMBER(*,0), 
	"TARGET_DIRECTORY" VARCHAR2(4000 BYTE), 
	"IS_PRESERVE_SOURCE_PATH" NUMBER(1,0), 
	"DUPLICATED_ACTION" NUMBER(*,0), 
	"TARGET_DEVICE_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_COMPLIANCE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_COMPLIANCE" 
   (	"JOB_ID" NUMBER(*,0), 
	"IS_AUTO_REMEDIATE" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_COMPLIANCE_TARGET
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_COMPLIANCE_TARGET" 
   (	"COMPLIANCE_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_DEPLOY
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_DEPLOY" 
   (	"JOB_ID" NUMBER(*,0), 
	"AGENT_TIMEOUT" NUMBER(*,0), 
	"PRE_COMMAND" VARCHAR2(4000 BYTE), 
	"PRE_SCRIPT_TYPE" VARCHAR2(255 BYTE), 
	"PRE_DECISION_TYPE" NUMBER(*,0), 
	"PRE_SUCCESS_MESSAGE" VARCHAR2(4000 BYTE), 
	"POST_COMMAND" VARCHAR2(4000 BYTE), 
	"POST_SCRIPT_TYPE" VARCHAR2(255 BYTE), 
	"POST_DECISION_TYPE" NUMBER(*,0), 
	"POST_SUCCESS_MESSAGE" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_DEPLOY_CUSTOM_PACKAGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_DEPLOY_CUSTOM_PACKAGE" 
   (	"JOB_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_DEPLOY_FILE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_DEPLOY_FILE" 
   (	"JOB_ID" NUMBER(*,0), 
	"TARGET_DIRECTORY" VARCHAR2(4000 BYTE), 
	"IS_PRESERVE_SOURCE_PATH" NUMBER(1,0), 
	"DUPLICATED_ACTION" NUMBER(*,0), 
	"IS_SYNC_OWNERSHIP" NUMBER(1,0), 
	"IS_SYNC_PERMISSION" NUMBER(1,0), 
	"IS_SYNC_LAST_MODIFIED" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_DEPLOY_ITEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_DEPLOY_ITEM" 
   (	"ITEM_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"LIBRARY_ID" NUMBER(*,0), 
	"DEVICE_ID" NUMBER(*,0), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"SIMPLE_NAME" VARCHAR2(255 BYTE), 
	"EXECUTING_ORDER" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_DEPLOY_SCRIPT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_DEPLOY_SCRIPT" 
   (	"JOB_ID" NUMBER(*,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_DEPLOY_SW_PACKAGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_DEPLOY_SW_PACKAGE" 
   (	"JOB_ID" NUMBER(*,0), 
	"REBOOT_OPTION" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_DEPLOY_WINDOWS_UPDATE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_DEPLOY_WINDOWS_UPDATE" 
   (	"JOB_ID" NUMBER(*,0), 
	"UPDATE_ITEM_TYPE" NUMBER(*,0), 
	"IS_EXCLUDE_SERVICE_PACK" NUMBER(1,0), 
	"IS_EXCLUDE_NON_SECURITY" NUMBER(1,0), 
	"FAIL_ACTION" NUMBER(*,0), 
	"REBOOT_OPTION" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_DEVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_DEVICE" 
   (	"JOB_ID" NUMBER(*,0), 
	"DEVICE_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_DEVICE_GROUP
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_DEVICE_GROUP" 
   (	"JOB_ID" NUMBER(*,0), 
	"GROUP_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_LAST_RESULT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_LAST_RESULT" 
   (	"JOB_LAST_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"JOB_RUN_ID" NUMBER(*,0), 
	"ORDER_RECENTLY" NUMBER(*,0), 
	"IS_LAST_COMPLETED" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_MULTI_TASK
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_MULTI_TASK" 
   (	"JOB_ID" NUMBER(10,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_MULTI_TASK_DET
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_MULTI_TASK_DET" 
   (	"JOB_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_MULTI_TASK_DET_TASK_ROOT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_MULTI_TASK_DET_TASK_ROOT" 
   (	"JOB_MULTI_TASK_DET_JOB_ID" NUMBER(10,0), 
	"TASKS_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_NOTI_TARGET
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_NOTI_TARGET" 
   (	"TARGET_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"TARGET_TYPE" NUMBER(*,0), 
	"TARGET_MAIL_SMS" VARCHAR2(255 BYTE), 
	"TARGET_USER_ID" VARCHAR2(255 BYTE), 
	"TARGET_ROLE_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_RESULT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_RESULT" 
   (	"JOB_RUN_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"BATCH_JOB_RUN_ID" NUMBER(*,0), 
	"JOB_TYPE" VARCHAR2(255 BYTE), 
	"JOB_VERSION" NUMBER(*,0), 
	"SCHEDULE_ID" NUMBER(*,0), 
	"SCHEDULE_INFO" VARCHAR2(255 BYTE), 
	"MANAGER_ID" VARCHAR2(255 BYTE), 
	"START_DATE" TIMESTAMP (6), 
	"END_DATE" TIMESTAMP (6), 
	"PROGRESS_STATUS" NUMBER(*,0), 
	"IS_REBOOT" NUMBER(1,0), 
	"IS_ERRORS" NUMBER(1,0), 
	"IS_CANCELLED" NUMBER(1,0), 
	"TOTAL_WORK_ITEMS" NUMBER(*,0), 
	"FINISHED_WORK_ITEMS" NUMBER(*,0), 
	"ERROR_WORK_ITEMS" NUMBER(*,0), 
	"RUN_USER_ID" VARCHAR2(255 BYTE), 
	"CANCEL_USER_ID" VARCHAR2(255 BYTE), 
	"MESSAGE" VARCHAR2(4000 BYTE), 
	"ERROR_MESSAGE" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_RESULT_AUDIT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_RESULT_AUDIT" 
   (	"JOB_RESULT_AUDIT_ID" NUMBER(*,0), 
	"JOB_RESULT_ID" NUMBER(*,0), 
	"RESULT_DATE" TIMESTAMP (6), 
	"IS_ERRORS" NUMBER(1,0), 
	"ERROR_MESSAGE" VARCHAR2(4000 BYTE), 
	"TOTAL_ITEMS" NUMBER(*,0), 
	"EXTRA_ITEMS" NUMBER(*,0), 
	"MISSING_ITEMS" NUMBER(*,0), 
	"CHANGED_ITEMS" NUMBER(*,0), 
	"UNCHANGED_ITEMS" NUMBER(*,0), 
	"IS_AUDIT_WITH_MASTER_DEVICE" NUMBER(1,0), 
	"MASTER_DEVICE_ID" NUMBER(*,0), 
	"MASTER_SNAPSHOT_JOB_RUN_ID" NUMBER(*,0), 
	"MASTER_JOB_RESULT_SNAPSHOT_ID" NUMBER(*,0), 
	"MASTER_DATE" TIMESTAMP (6), 
	"MASTER_DEVICE_NAME" VARCHAR2(255 CHAR)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_RESULT_AUDIT_DETAIL
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_RESULT_AUDIT_DETAIL" 
   (	"JOB_RESULT_AUDIT_DETAIL_ID" NUMBER(*,0), 
	"JOB_RESULT_AUDIT_ID" NUMBER(*,0), 
	"RESULT_DATE" TIMESTAMP (6), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"SIMPLE_NAME" VARCHAR2(255 BYTE), 
	"PARENT_LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"PARENT_LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"DELTA_TYPE" NUMBER(*,0), 
	"DELTA_STRING" VARCHAR2(4000 BYTE), 
	"IS_ERROR" NUMBER(1,0), 
	"ERROR_MESSAGE" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_RESULT_COMPLIANCE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_RESULT_COMPLIANCE" 
   (	"JOB_RESULT_COMPLIANCE_ID" NUMBER(*,0), 
	"JOB_RESULT_ID" NUMBER(*,0), 
	"COMPLIANCE_ID" NUMBER(*,0), 
	"RESULT_DATE" TIMESTAMP (6), 
	"TOTAL_POLICIES" NUMBER(*,0), 
	"TOTAL_CONSISTENT" NUMBER(*,0), 
	"TOTAL_INCONSISTENT" NUMBER(*,0), 
	"TOTAL_CONSISTENT_EXCEPTION" NUMBER(*,0), 
	"TOTAL_UNKNOWN" NUMBER(*,0), 
	"TOTAL_REMEDIATION" NUMBER(*,0), 
	"TOTAL_REMEDIATED" NUMBER(*,0), 
	"IS_ERRORS" NUMBER(1,0), 
	"COMPLIANCE_VERSION" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_RESULT_COMPLIANCE_POLICY
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_RESULT_COMPLIANCE_POLICY" 
   (	"JOB_RESULT_POLICY_ID" NUMBER(*,0), 
	"JOB_RESULT_COMPLIANCE_ID" NUMBER(*,0), 
	"POLICY_ID" NUMBER(*,0), 
	"RESULT_DATE" TIMESTAMP (6), 
	"IS_CONSISTENT" NUMBER(1,0), 
	"IS_INCONSISTENT" NUMBER(1,0), 
	"IS_CONSISTENT_EXCEPTION" NUMBER(1,0), 
	"IS_UNKNOWN" NUMBER(1,0), 
	"IS_REMEDIATION" NUMBER(1,0), 
	"IS_REMEDIATED" NUMBER(1,0), 
	"RESULT_STRING" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_RESULT_DEPLOY
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_RESULT_DEPLOY" 
   (	"JOB_RESULT_DEPLOY_ID" NUMBER(*,0), 
	"JOB_RESULT_ID" NUMBER(*,0), 
	"LIBRARY_ID" NUMBER(*,0), 
	"DEVICE_ID" NUMBER(*,0), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"SIMPLE_NAME" VARCHAR2(255 BYTE), 
	"LIBRARY_VERSION" NUMBER(*,0), 
	"START_DATE" TIMESTAMP (6), 
	"END_DATE" TIMESTAMP (6), 
	"PROGRESS_STATUS" NUMBER(*,0), 
	"IS_ERRORS" NUMBER(1,0), 
	"MESSAGE" VARCHAR2(4000 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_RESULT_DEVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_RESULT_DEVICE" 
   (	"JOB_RESULT_ID" NUMBER(*,0), 
	"JOB_RUN_ID" NUMBER(*,0), 
	"DEVICE_ID" NUMBER(*,0), 
	"START_DATE" TIMESTAMP (6), 
	"END_DATE" TIMESTAMP (6), 
	"PROGRESS_STATUS" NUMBER(*,0), 
	"IS_REBOOT" NUMBER(1,0), 
	"IS_ERRORS" NUMBER(1,0), 
	"IS_CANCELLED" NUMBER(1,0), 
	"TOTAL_ITEMS" NUMBER(*,0), 
	"ERROR_ITEMS" NUMBER(*,0), 
	"MESSAGE" VARCHAR2(4000 BYTE), 
	"ERROR_MESSAGE" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_RESULT_SNAPSHOT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_RESULT_SNAPSHOT" 
   (	"JOB_RESULT_SNAPSHOT_ID" NUMBER(*,0), 
	"JOB_RESULT_ID" NUMBER(*,0), 
	"PARENT_SNAPSHOT_ID" NUMBER(*,0), 
	"RESULT_DATE" TIMESTAMP (6), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"SIMPLE_NAME" VARCHAR2(255 BYTE), 
	"PARENT_LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"PARENT_LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"IS_ERRORS" NUMBER(1,0), 
	"ERROR_MESSAGE" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_SCHEDULE
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_SCHEDULE" 
   (	"SCHEDULE_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"CRON_EXPRESSION" VARCHAR2(255 BYTE), 
	"EXPRESSION_SUMMARY" VARCHAR2(255 BYTE), 
	"INTERVAL_TYPE" NUMBER(*,0), 
	"START_TIME" TIMESTAMP (6), 
	"END_TIME" TIMESTAMP (6), 
	"NEXT_FIRE_TIME" TIMESTAMP (6)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_SCRIPT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_SCRIPT" 
   (	"JOB_ID" NUMBER(*,0), 
	"IS_LINK_LIBRARY" NUMBER(1,0), 
	"SCRIPT_TYPE" VARCHAR2(255 BYTE), 
	"LIBRARY_ID" NUMBER(*,0), 
	"EXECUTION_PATH" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_SCRIPT_PARAMETER
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_SCRIPT_PARAMETER" 
   (	"PARAMETER_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"PARAMETER_NAME" VARCHAR2(255 BYTE), 
	"PARAMETER_VALUE" VARCHAR2(2000 BYTE), 
	"PARAMETER_ORDER" NUMBER(*,0), 
	"DESCRIPTION" VARCHAR2(2000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_SNAPSHOT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_SNAPSHOT" 
   (	"JOB_ID" NUMBER(*,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_SNAPSHOT_AUDIT
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_SNAPSHOT_AUDIT" 
   (	"JOB_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_SNAPSHOT_AUDIT_ITEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_SNAPSHOT_AUDIT_ITEM" 
   (	"ITEM_ID" NUMBER(*,0), 
	"POLICY_ID" NUMBER(*,0), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"TARGET_ATTRIBUTE_NAME" VARCHAR2(255 BYTE), 
	"UNIT" VARCHAR2(255 BYTE), 
	"IS_SNAPSHOT" NUMBER(1,0), 
	"IS_AUDIT" NUMBER(1,0), 
	"DATA_TYPE" VARCHAR2(255 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_SNAPSHOT_AUDIT_POLICY
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_SNAPSHOT_AUDIT_POLICY" 
   (	"POLICY_ID" NUMBER(*,0), 
	"JOB_ID" NUMBER(*,0), 
	"LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"SIMPLE_NAME" VARCHAR2(4000 BYTE), 
	"IS_RECURSION" NUMBER(1,0), 
	"IS_ENABLE_RECURSION" NUMBER(1,0), 
	"INCLUDES" VARCHAR2(4000 BYTE), 
	"EXCLUDES" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table JOB_VARIABLES
--------------------------------------------------------

  CREATE TABLE "ITSM"."JOB_VARIABLES" 
   (	"JOB_ID" NUMBER(10,0), 
	"VAR_KEY" VARCHAR2(255 CHAR), 
	"VAR_VALUE" VARCHAR2(4000 CHAR)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIBRARY
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIBRARY" 
   (	"LIBRARY_ID" NUMBER(*,0), 
	"SOURCE_AGENT_KEY" VARCHAR2(255 BYTE), 
	"SOURCE_LOCATION" VARCHAR2(4000 BYTE), 
	"REPOSITORY_LOCATION" VARCHAR2(4000 BYTE), 
	"LOCATION_TYPE" VARCHAR2(255 BYTE), 
	"FILE_NAME" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIBRARY_CUSTOM_ITEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIBRARY_CUSTOM_ITEM" 
   (	"ITEM_ID" NUMBER(*,0), 
	"LIBRARY_ID" NUMBER(*,0), 
	"ITEM_NAME" VARCHAR2(255 BYTE), 
	"ITEM_TYPE" VARCHAR2(255 BYTE), 
	"ACTION_TYPE" VARCHAR2(255 BYTE), 
	"EXECUTING_ORDER" NUMBER(*,0), 
	"COMMAND" VARCHAR2(4000 BYTE), 
	"UNDO_COMMAND" VARCHAR2(4000 BYTE), 
	"FAIL_ACTION" VARCHAR2(255 BYTE), 
	"SOURCE_OBJECT_NAME" VARCHAR2(255 BYTE), 
	"SOURCE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"IS_RECURSION" NUMBER(1,0), 
	"IS_DECIDE_SUCCESS" NUMBER(1,0), 
	"DECISION_TYPE" VARCHAR2(255 BYTE), 
	"SUCCESS_MESSAGE" VARCHAR2(4000 BYTE), 
	"FILE_DESTINATION" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIBRARY_CUSTOM_PACKAGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIBRARY_CUSTOM_PACKAGE" 
   (	"LIBRARY_ID" NUMBER(*,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIBRARY_FILE
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIBRARY_FILE" 
   (	"LIBRARY_ID" NUMBER(*,0), 
	"SOURCE_FILE_NAME" VARCHAR2(4000 BYTE), 
	"SOURCE_MODIFIED_DATE" TIMESTAMP (6), 
	"SOURCE_USER" VARCHAR2(255 BYTE), 
	"SOURCE_GROUP" VARCHAR2(255 BYTE), 
	"FILE_MODE" VARCHAR2(255 BYTE), 
	"FILE_SIZE" FLOAT(126), 
	"IS_DIRECTORY" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIBRARY_SCRIPT
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIBRARY_SCRIPT" 
   (	"LIBRARY_ID" NUMBER(*,0), 
	"SCRIPT_TYPE" VARCHAR2(255 BYTE), 
	"ENCODING_TYPE" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIBRARY_SCRIPT_PARAMETER
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIBRARY_SCRIPT_PARAMETER" 
   (	"PARAMETER_ID" NUMBER(*,0), 
	"LIBRARY_ID" NUMBER(*,0), 
	"PARAMETER_NAME" VARCHAR2(255 BYTE), 
	"DEFAULT_VALUE" VARCHAR2(4000 BYTE), 
	"PARAMETER_ORDER" NUMBER(*,0), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"PARAMETER_VALUE" VARCHAR2(4000 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIBRARY_SOFTWARE_PACKAGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIBRARY_SOFTWARE_PACKAGE" 
   (	"LIBRARY_ID" NUMBER(*,0), 
	"INSTALL_COMMAND" VARCHAR2(4000 BYTE), 
	"UNINSTALL_COMMAND" VARCHAR2(4000 BYTE), 
	"SW_TYPE" VARCHAR2(255 BYTE), 
	"SW_NAME" VARCHAR2(255 BYTE), 
	"SW_VERSION" VARCHAR2(255 BYTE), 
	"VENDOR" VARCHAR2(255 BYTE), 
	"IS_REQUIRED_REBOOT" NUMBER(1,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIBRARY_SOFTWARE_PACKAGE_PARAM
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIBRARY_SOFTWARE_PACKAGE_PARAM" 
   (	"PARAMETER_ID" NUMBER(*,0), 
	"LIBRARY_ID" NUMBER(*,0), 
	"PARAMETER_NAME" VARCHAR2(255 BYTE), 
	"REPOSITORY_LOCATION" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIVE_OBJECT_ATTR_MASTER
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIVE_OBJECT_ATTR_MASTER" 
   (	"ATTRIBUTE_CODE" VARCHAR2(255 CHAR), 
	"DEFAULT_THRESHOLD_ID" NUMBER(10,0), 
	"IS_STATISTICS" NUMBER(1,0), 
	"DATA_TYPE" VARCHAR2(255 CHAR), 
	"ATTRIBUTE_NAME" VARCHAR2(255 CHAR), 
	"UNIT" VARCHAR2(255 CHAR), 
	"IS_ON_DEMAND" NUMBER(1,0), 
	"DISPLAY_NAME" VARCHAR2(255 CHAR), 
	"VISIBILITY" NUMBER(10,0), 
	"CLASSIFICATION" VARCHAR2(255 CHAR), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table LIVE_OBJECT_TYPE_MASTER
--------------------------------------------------------

  CREATE TABLE "ITSM"."LIVE_OBJECT_TYPE_MASTER" 
   (	"LIVE_OBJECT_TYPE" VARCHAR2(255 CHAR), 
	"SYSTEM_OBJECT_TYPE" VARCHAR2(255 CHAR), 
	"DISPLAY_NAME" VARCHAR2(255 CHAR), 
	"DEFAULT_LIVE_OBJECT_NAME" VARCHAR2(4000 CHAR), 
	"DEFAULT_SIMPLE_NAME" VARCHAR2(255 CHAR), 
	"IS_MULTIPLE" NUMBER(1,0), 
	"MANAGEMENT_POLICY" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table MANAGED_LIVE_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."MANAGED_LIVE_OBJECT" 
   (	"LIVE_OBJECT_ID" NUMBER(10,0), 
	"MANAGED_OBJECT_ID" NUMBER(10,0), 
	"LIVE_OBJECT_NAME" VARCHAR2(255 CHAR), 
	"SIMPLE_NAME" VARCHAR2(255 CHAR), 
	"OBJECT_DISPLAY_NAME" VARCHAR2(4000 CHAR), 
	"LAST_MODIFIED_DATE" TIMESTAMP (6), 
	"IS_DELETED" NUMBER(1,0), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table MANAGED_LIVE_OBJECT_ATTR
--------------------------------------------------------

  CREATE TABLE "ITSM"."MANAGED_LIVE_OBJECT_ATTR" 
   (	"ATTRIBUTE_ID" NUMBER(10,0), 
	"LIVE_OBJECT_ID" NUMBER(10,0), 
	"ATTRIBUTE_NAME" VARCHAR2(255 CHAR), 
	"ATTRIBUTE_DISPLAY_NAME" VARCHAR2(4000 CHAR), 
	"THRESHOLD_ID" NUMBER(10,0), 
	"IS_STATISTICS" NUMBER(1,0), 
	"ATTRIBUTE_CODE" VARCHAR2(255 CHAR)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table MANAGED_LIVE_OBJECT_TRACE
--------------------------------------------------------

  CREATE TABLE "ITSM"."MANAGED_LIVE_OBJECT_TRACE" 
   (	"TRACE_ID" NUMBER(10,0), 
	"ATTRIBUTE_ID" NUMBER(10,0), 
	"OLD_NUMERIC_VALUE" FLOAT(126), 
	"OLD_STRING_VALUE" VARCHAR2(4000 CHAR), 
	"NEW_NUMERIC_VALUE" FLOAT(126), 
	"NEW_STRING_VALUE" VARCHAR2(4000 CHAR), 
	"OLD_DATE_VALUE" TIMESTAMP (6), 
	"NEW_DATE_VALUE" TIMESTAMP (6), 
	"TRACE_DATE" TIMESTAMP (6)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table MANAGED_LIVE_OBJECT_VALUE
--------------------------------------------------------

  CREATE TABLE "ITSM"."MANAGED_LIVE_OBJECT_VALUE" 
   (	"ATTRIBUTE_ID" NUMBER(10,0), 
	"LIVE_OBJECT_ID" NUMBER(10,0), 
	"ATTRIBUTE_NAME" VARCHAR2(255 CHAR), 
	"POLLING_TIME" TIMESTAMP (6), 
	"POLLING_ID" NUMBER(19,0), 
	"EXCEPTION_TYPE" NUMBER(10,0), 
	"NUMERIC_VALUE" FLOAT(126), 
	"STRING_VALUE" VARCHAR2(4000 CHAR), 
	"DATE_VALUE" TIMESTAMP (6), 
	"LAST_STAT_TIME" TIMESTAMP (6), 
	"POLLING_COUNT" NUMBER(10,0), 
	"TOTAL_VALUE" FLOAT(126), 
	"MIN_VALUE" FLOAT(126), 
	"MAX_VALUE" FLOAT(126)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table MANAGED_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."MANAGED_OBJECT" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"PARENT_OBJECT_ID" NUMBER(10,0), 
	"MANAGING_KEY" VARCHAR2(255 CHAR), 
	"OBJECT_PATH" VARCHAR2(4000 CHAR), 
	"STATUS" VARCHAR2(255 CHAR), 
	"IS_MANAGED" NUMBER(1,0), 
	"AVAILABILITY_POLLING_INTERVAL" NUMBER(10,0), 
	"HEALTH_POLLING_INTERVAL" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table MANAGER_STATE
--------------------------------------------------------

  CREATE TABLE "ITSM"."MANAGER_STATE" 
   (	"MANAGER_ID" VARCHAR2(255 BYTE), 
	"MANAGER_GROUP" VARCHAR2(255 BYTE), 
	"IP_ADDRESS" VARCHAR2(255 BYTE), 
	"PORT" NUMBER(*,0), 
	"LAST_CHECKIN_TIME" NUMBER(*,0), 
	"IS_USE_REMOTE_SERVICE" NUMBER(1,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NBPM_DEPLOY
--------------------------------------------------------

  CREATE TABLE "ITSM"."NBPM_DEPLOY" 
   (	"DEPLOY_ID" NUMBER(19,0), 
	"VERSION" NUMBER(10,0), 
	"BLOB_VALUE" BLOB, 
	"PROCESS_NM" VARCHAR2(200 BYTE), 
	"FILE_NM" VARCHAR2(400 BYTE), 
	"PROCESSID" VARCHAR2(120 BYTE), 
	"PROCESS_TYPE" VARCHAR2(100 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NBPM_NODE_ALAM
--------------------------------------------------------

  CREATE TABLE "ITSM"."NBPM_NODE_ALAM" 
   (	"PROCESSID" VARCHAR2(120 BYTE), 
	"NODEID" VARCHAR2(100 BYTE), 
	"DEPLOY_ID" NUMBER(19,0), 
	"ALAM_TYPE" VARCHAR2(50 BYTE), 
	"TARGET_TYPE" VARCHAR2(50 BYTE), 
	"TEMPLATE_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NBPM_NODE_DETAIL
--------------------------------------------------------

  CREATE TABLE "ITSM"."NBPM_NODE_DETAIL" 
   (	"PROCESSID" VARCHAR2(120 BYTE), 
	"NODEID" VARCHAR2(100 BYTE), 
	"NODENAME" VARCHAR2(100 BYTE), 
	"WORK_STATE" VARCHAR2(20 BYTE), 
	"TASK_NAME" VARCHAR2(50 BYTE), 
	"ROLE_ID" VARCHAR2(50 BYTE), 
	"VERSION" NUMBER, 
	"DEPLOY_ID" NUMBER(19,0), 
	"MULTI_YN" VARCHAR2(1 BYTE), 
	"WORK_DT_UPDATE_YN" CHAR(1 BYTE), 
	"PROC_STATE" VARCHAR2(50 BYTE), 
	"EMAIL_SEND" VARCHAR2(1 BYTE) DEFAULT 'N', 
	"SMS_SEND" VARCHAR2(1 BYTE) DEFAULT 'N', 
	"EMAIL_TEMPLATE_ID" VARCHAR2(50 BYTE), 
	"SMS_TEMPLATE_ID" VARCHAR2(50 BYTE)
   )    TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NBPM_PROCESS_VARIABLE
--------------------------------------------------------

  CREATE TABLE "ITSM"."NBPM_PROCESS_VARIABLE" 
   (	"DIVISION_VAILABLE" VARCHAR2(50 BYTE), 
	"DEPLOY_ID" NUMBER(19,0), 
	"PROCESSID" VARCHAR2(120 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NBPM_PROC_REL_TABLE
--------------------------------------------------------

  CREATE TABLE "ITSM"."NBPM_PROC_REL_TABLE" 
   (	"PROCESS_TYPE" VARCHAR2(100 BYTE), 
	"TABLE_NAME" VARCHAR2(100 BYTE), 
	"TABLE_DESC" VARCHAR2(1000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NBPM_WORK_STATE_HISTORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."NBPM_WORK_STATE_HISTORY" 
   (	"PROCESS_TYPE" VARCHAR2(40 BYTE), 
	"TASK_NAME" VARCHAR2(100 BYTE), 
	"WORK_STATE" VARCHAR2(50 BYTE), 
	"WORK_DT_UPDATE_YN" CHAR(1 BYTE), 
	"PROC_STATE" VARCHAR2(50 BYTE), 
	"EMAIL_SEND" VARCHAR2(1 BYTE), 
	"SMS_SEND" VARCHAR2(1 BYTE), 
	"EMAIL_TEMPLATE_ID" VARCHAR2(50 BYTE), 
	"SMS_TEMPLATE_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NODEINSTANCELOG
--------------------------------------------------------

  CREATE TABLE "ITSM"."NODEINSTANCELOG" 
   (	"ID" NUMBER(19,0), 
	"LOG_DATE" DATE, 
	"NODEID" VARCHAR2(255 BYTE), 
	"NODEINSTANCEID" VARCHAR2(255 BYTE), 
	"NODENAME" VARCHAR2(255 BYTE), 
	"PROCESSID" VARCHAR2(255 BYTE), 
	"PROCESSINSTANCEID" NUMBER(19,0), 
	"TYPE" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NOTIFICATION
--------------------------------------------------------

  CREATE TABLE "ITSM"."NOTIFICATION" 
   (	"ID" NUMBER(19,0), 
	"PRIORITY" NUMBER(10,0), 
	"ESCALATION_NOTIFICATIONS_ID" NUMBER(19,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NOTIFICATION_BAS
--------------------------------------------------------

  CREATE TABLE "ITSM"."NOTIFICATION_BAS" 
   (	"TASK_ID" NUMBER(19,0), 
	"ENTITY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table NOTIFICATION_RECIPIENTS
--------------------------------------------------------

  CREATE TABLE "ITSM"."NOTIFICATION_RECIPIENTS" 
   (	"TASK_ID" NUMBER(19,0), 
	"ENTITY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table OBJECT_GROUP_CONDITION
--------------------------------------------------------

  CREATE TABLE "ITSM"."OBJECT_GROUP_CONDITION" 
   (	"CONDITION_ID" NUMBER(*,0), 
	"GROUP_ID" NUMBER(*,0), 
	"CLASS_ID" NUMBER(*,0), 
	"COMPARISON_OPERATOR" VARCHAR2(255 BYTE), 
	"INTEGER_VALUE" NUMBER(*,0), 
	"INTEGER_VALUE2" NUMBER(*,0), 
	"DOUBLE_VALUE" FLOAT(126), 
	"DOUBLE_VALUE2" FLOAT(126), 
	"DATE_VALUE" TIMESTAMP (6), 
	"DATE_VALUE2" TIMESTAMP (6), 
	"LONG_VALUE" NUMBER(*,0), 
	"LONG_VALUE2" NUMBER(*,0), 
	"STRING_VALUE" VARCHAR2(4000 BYTE), 
	"BOOLEAN_VALUE" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table OBJECT_GROUP_MAP
--------------------------------------------------------

  CREATE TABLE "ITSM"."OBJECT_GROUP_MAP" 
   (	"GROUP_ID" NUMBER(*,0), 
	"OBJECT_ID" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ORGANIZATIONALENTITY
--------------------------------------------------------

  CREATE TABLE "ITSM"."ORGANIZATIONALENTITY" 
   (	"DTYPE" VARCHAR2(31 BYTE), 
	"ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table OS_TYPE
--------------------------------------------------------

  CREATE TABLE "ITSM"."OS_TYPE" 
   (	"OS_TYPE" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"ORDER_NUM" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PEOPLEASSIGNMENTS_BAS
--------------------------------------------------------

  CREATE TABLE "ITSM"."PEOPLEASSIGNMENTS_BAS" 
   (	"TASK_ID" NUMBER(19,0), 
	"ENTITY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PEOPLEASSIGNMENTS_EXCLOWNERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."PEOPLEASSIGNMENTS_EXCLOWNERS" 
   (	"TASK_ID" NUMBER(19,0), 
	"ENTITY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PEOPLEASSIGNMENTS_POTOWNERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."PEOPLEASSIGNMENTS_POTOWNERS" 
   (	"TASK_ID" NUMBER(19,0), 
	"ENTITY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PEOPLEASSIGNMENTS_RECIPIENTS
--------------------------------------------------------

  CREATE TABLE "ITSM"."PEOPLEASSIGNMENTS_RECIPIENTS" 
   (	"TASK_ID" NUMBER(19,0), 
	"ENTITY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PEOPLEASSIGNMENTS_STAKEHOLDERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."PEOPLEASSIGNMENTS_STAKEHOLDERS" 
   (	"TASK_ID" NUMBER(19,0), 
	"ENTITY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PERSISTENT_LIVE_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."PERSISTENT_LIVE_OBJECT" 
   (	"OBJECT_ID" NUMBER(*,0), 
	"DEVICE_ID" NUMBER(*,0), 
	"LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"SIMPLE_NAME" VARCHAR2(4000 BYTE), 
	"PARENT_LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"PARENT_LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"LAST_MODIFIED_DATE" TIMESTAMP (6), 
	"HAS_CHILDREN" NUMBER(1,0), 
	"IS_DELETED" NUMBER(1,0), 
	"PERSISTED_DATE" TIMESTAMP (6)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PERSISTENT_LIVE_OBJECT_ATTR
--------------------------------------------------------

  CREATE TABLE "ITSM"."PERSISTENT_LIVE_OBJECT_ATTR" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"OBJECT_ID" NUMBER(*,0), 
	"ATTRIBUTE_NAME" VARCHAR2(255 BYTE), 
	"DISPLAY_NAME" VARCHAR2(255 BYTE), 
	"DATA_TYPE" VARCHAR2(255 BYTE), 
	"UNIT" VARCHAR2(255 BYTE), 
	"IS_ON_DEMAND" NUMBER(1,0), 
	"VISIBILITY" NUMBER(*,0), 
	"INTEGER_VALUE" NUMBER(*,0), 
	"DOUBLE_VALUE" FLOAT(126), 
	"DATE_VALUE" TIMESTAMP (6), 
	"STRING_VALUE" VARCHAR2(4000 BYTE), 
	"BOOLEAN_VALUE" NUMBER(1,0), 
	"LONG_VALUE" FLOAT(126), 
	"CLASSIFICATION" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PERSISTENT_LIVE_OBJECT_TRACE
--------------------------------------------------------

  CREATE TABLE "ITSM"."PERSISTENT_LIVE_OBJECT_TRACE" 
   (	"TRACE_ID" NUMBER(*,0), 
	"ATTRIBUTE_ID" NUMBER(*,0), 
	"TRACE_DATE" TIMESTAMP (6), 
	"OLD_INTEGER_VALUE" NUMBER(*,0), 
	"OLD_DOUBLE_VALUE" FLOAT(126), 
	"OLD_STRING_VALUE" VARCHAR2(4000 BYTE), 
	"OLD_DATE_VALUE" TIMESTAMP (6), 
	"OLD_BOOLEAN_VALUE" NUMBER(1,0), 
	"OLD_LONG_VALUE" NUMBER(*,0), 
	"NEW_INTEGER_VALUE" NUMBER(*,0), 
	"NEW_DOUBLE_VALUE" FLOAT(126), 
	"NEW_DATE_VALUE" TIMESTAMP (6), 
	"NEW_STRING_VALUE" VARCHAR2(4000 BYTE), 
	"NEW_BOOLEAN_VALUE" NUMBER(1,0), 
	"NEW_LONG_VALUE" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_ADDRESS
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_ADDRESS" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"AD_ADDRESS" VARCHAR2(255 CHAR), 
	"AD_IF_INDEX" NUMBER(10,0), 
	"AD_NETMASK" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_ALTEON_ARP
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_ALTEON_ARP" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"DEST_IP" VARCHAR2(255 CHAR), 
	"MAC" VARCHAR2(255 CHAR), 
	"VLAN" NUMBER(10,0), 
	"PORT" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_ALTEON_PORT
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_ALTEON_PORT" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"PORT" NUMBER(10,0), 
	"PORT_NAME" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_AT
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_AT" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"IF_INDEX" NUMBER(10,0), 
	"PHY_ADDRESS" VARCHAR2(255 CHAR), 
	"NET_ADDRESS" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_BRIDGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_BRIDGE" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"PORT" NUMBER(10,0), 
	"PORT_STATE" NUMBER(10,0), 
	"PORT_DESIGNATED_ROOT" VARCHAR2(255 CHAR), 
	"PORT_DESIGNATED_BRIDGE" VARCHAR2(255 CHAR), 
	"PORT_DESIGNATED_PORT" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_CONNECTIVITY
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_CONNECTIVITY" 
   (	"CONNECTIVITY_ID" VARCHAR2(255 CHAR), 
	"SRC_DEVICE_ID" NUMBER(10,0), 
	"DEST_DEVICE_ID" NUMBER(10,0), 
	"SRC_PORT" NUMBER(10,0), 
	"CONNECTED_MAC" VARCHAR2(255 CHAR), 
	"CONNECTED_IP" VARCHAR2(255 CHAR), 
	"HOSTNAME" VARCHAR2(255 CHAR), 
	"VLAN_ID" NUMBER(10,0), 
	"VLAN_NAME" VARCHAR2(255 CHAR), 
	"PERSISTED_DATE" TIMESTAMP (6), 
	"CONNECTIVITY_TYPE" NUMBER(10,0), 
	"DEST_PORT" NUMBER(10,0), 
	"SRC_INTERFACE_ID" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_DEVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_DEVICE" 
   (	"DEVICE_ID" NUMBER(10,0), 
	"SYS_SERVICES" NUMBER(10,0), 
	"SYS_DESCR" VARCHAR2(255 CHAR), 
	"SYS_OBJECT_ID" VARCHAR2(255 CHAR), 
	"SYS_NAME" VARCHAR2(255 CHAR), 
	"SYS_LOCATION" VARCHAR2(255 CHAR), 
	"IP_FORWARDING" NUMBER(10,0), 
	"SUBNET_MASK" VARCHAR2(255 CHAR), 
	"SUBNET" VARCHAR2(255 CHAR), 
	"IS_L2" NUMBER(1,0), 
	"IS_L3" NUMBER(1,0), 
	"IS_L4" NUMBER(1,0), 
	"IS_L7" NUMBER(1,0), 
	"LAST_POLLING_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_INTERFACE
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_INTERFACE" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"IF_INDEX" NUMBER(10,0), 
	"IF_DESCR" VARCHAR2(255 CHAR), 
	"IF_PHYADDRESS" VARCHAR2(255 CHAR), 
	"IF_TYPE" VARCHAR2(255 CHAR), 
	"IF_MTU" NUMBER(10,0), 
	"IF_SPEED" NUMBER(19,0), 
	"IF_ADMIN_STATUS" VARCHAR2(255 CHAR), 
	"IF_OPER_STATUS" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_INTERFACE_X
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_INTERFACE_X" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"IF_INDEX" NUMBER(10,0), 
	"IF_NAME" VARCHAR2(255 CHAR), 
	"IF_ALIAS" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_MEDIA
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_MEDIA" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"MEDIA_IF_INDEX" NUMBER(10,0), 
	"NET_ADDRESS" VARCHAR2(255 CHAR), 
	"PHY_ADDRESS" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_PORT
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_PORT" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"PORT" NUMBER(10,0), 
	"PORT_IF_INDEX" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_ROUTE
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_ROUTE" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"ROUTE_DEST" VARCHAR2(255 CHAR), 
	"ROUTE_IF_INDEX" NUMBER(10,0), 
	"ROUTE_NEXT_HOP" VARCHAR2(255 CHAR), 
	"ROUTE_TYPE" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_SNMP_TARGET
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_SNMP_TARGET" 
   (	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_TP
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_TP" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"FDB_ADDRESS" VARCHAR2(255 CHAR), 
	"PORT" NUMBER(10,0), 
	"FDB_STATUS" NUMBER(10,0), 
	"VLAN_ID" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PNC_VLAN
--------------------------------------------------------

  CREATE TABLE "ITSM"."PNC_VLAN" 
   (	"ENTITY_ID" VARCHAR2(255 CHAR), 
	"VLAN_NAME" VARCHAR2(255 CHAR), 
	"VLAN_TYPE" VARCHAR2(255 CHAR), 
	"VLAN_ID" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PORTAL_AUTH_CONTENTS
--------------------------------------------------------

  CREATE TABLE "ITSM"."PORTAL_AUTH_CONTENTS" 
   (	"CONTENTS_ID" VARCHAR2(20 BYTE), 
	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_ID" VARCHAR2(40 BYTE), 
	"UPD" DATE
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PORTAL_BOARD_DOWN
--------------------------------------------------------

  CREATE TABLE "ITSM"."PORTAL_BOARD_DOWN" 
   (	"NO_ID" NUMBER, 
	"CATEGORY_TYPE" VARCHAR2(50 BYTE), 
	"CATEGORY_ID" VARCHAR2(10 BYTE), 
	"TITLE" VARCHAR2(200 BYTE), 
	"CONTENT" CLOB, 
	"BOARD_COUNT" NUMBER, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"FAMILY_TYPE" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM"; 
--------------------------------------------------------
--  DDL for Table PORTAL_BOARD_NOTICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."PORTAL_BOARD_NOTICE" 
   (	"NO_ID" NUMBER, 
	"TITLE" VARCHAR2(200 BYTE), 
	"CONTENT" CLOB, 
	"BOARD_COUNT" NUMBER, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"POP_YN" CHAR(1 BYTE), 
	"NOTICE_POSITION" CHAR(1 BYTE), 
	"POP_SDT" VARCHAR2(10 BYTE), 
	"POP_EDT" VARCHAR2(10 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"POP_WIDTH" VARCHAR2(4 BYTE), 
	"POP_HEIGHT" VARCHAR2(4 BYTE), 
	"FAMILY_TYPE" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PORTAL_CONTENTS
--------------------------------------------------------

  CREATE TABLE "ITSM"."PORTAL_CONTENTS" 
   (	"CONTENTS_ID" VARCHAR2(20 BYTE), 
	"TITLE" VARCHAR2(30 BYTE), 
	"XTYPE" VARCHAR2(50 BYTE), 
	"CATEGORY" VARCHAR2(20 BYTE), 
	"CLASSPATH" VARCHAR2(50 BYTE), 
	"DESCR" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PORTAL_CONTENTS_TOOLITEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."PORTAL_CONTENTS_TOOLITEM" 
   (	"CONTENTS_ID" VARCHAR2(20 BYTE), 
	"USER_ID" VARCHAR2(40 BYTE), 
	"KEY" VARCHAR2(20 BYTE), 
	"VALUE" VARCHAR2(200 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PORTAL_USER_CONTENTS
--------------------------------------------------------

  CREATE TABLE "ITSM"."PORTAL_USER_CONTENTS" 
   (	"USER_ID" VARCHAR2(40 BYTE), 
	"CONTENTS_ID" VARCHAR2(20 BYTE), 
	"COL_INDEX" VARCHAR2(2 BYTE), 
	"ROW_INDEX" VARCHAR2(2 BYTE), 
	"HEIGHT" VARCHAR2(4 BYTE), 
	"OPACITY" VARCHAR2(4 BYTE), 
	"X" VARCHAR2(6 BYTE), 
	"Y" VARCHAR2(6 BYTE), 
	"WIDTH" VARCHAR2(4 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PORTAL_USER_SETTING
--------------------------------------------------------

  CREATE TABLE "ITSM"."PORTAL_USER_SETTING" 
   (	"USER_ID" VARCHAR2(40 BYTE), 
	"WINDOW_WIDTH" VARCHAR2(5 BYTE), 
	"WINDOW_HEIGHT" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PORTAL_USER_WIDGET
--------------------------------------------------------

  CREATE TABLE "ITSM"."PORTAL_USER_WIDGET" 
   (	"USER_ID" VARCHAR2(40 BYTE), 
	"WIDGET_ID" VARCHAR2(30 BYTE), 
	"ROW_COUNT" VARCHAR2(10 BYTE), 
	"WIDE_VIEW_YN" CHAR(1 BYTE), 
	"WIDGET_ORDER" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PORTAL_WIDGET
--------------------------------------------------------

  CREATE TABLE "ITSM"."PORTAL_WIDGET" 
   (	"WIDGET_ID" VARCHAR2(30 BYTE), 
	"WIDGET_TITLE" VARCHAR2(100 BYTE), 
	"WIDGET_TYPE" VARCHAR2(20 BYTE), 
	"WIDGET_DETAIL_TYPE" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROCESSINSTANCEEVENTINFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROCESSINSTANCEEVENTINFO" 
   (	"ID" NUMBER(19,0), 
	"EVENTTYPE" VARCHAR2(255 BYTE), 
	"PROCESSINSTANCEID" NUMBER(19,0), 
	"OPTLOCK" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROCESSINSTANCEINFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROCESSINSTANCEINFO" 
   (	"INSTANCEID" NUMBER(19,0), 
	"OPTLOCK" NUMBER(10,0), 
	"PROCESSID" VARCHAR2(255 BYTE), 
	"STARTDATE" DATE, 
	"LASTREADDATE" DATE, 
	"LASTMODIFICATIONDATE" DATE, 
	"STATE" NUMBER(10,0), 
	"PROCESSINSTANCEBYTEARRAY" BLOB
   ) TABLESPACE "ITSM"  ;
--------------------------------------------------------
--  DDL for Table PROCESSINSTANCELOG
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROCESSINSTANCELOG" 
   (	"ID" NUMBER(19,0), 
	"END_DATE" DATE, 
	"OUTCOME" VARCHAR2(255 BYTE), 
	"PARENTPROCESSINSTANCEID" NUMBER(19,0), 
	"PROCESSID" VARCHAR2(255 BYTE), 
	"PROCESSINSTANCEID" NUMBER(19,0), 
	"START_DATE" DATE, 
	"STATUS" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROC_CALLBACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_CALLBACK" 
   (	"IN_ID" NUMBER, 
	"IN_TEL_NO" VARCHAR2(32 BYTE), 
	"IN_USER_ID" VARCHAR2(32 BYTE), 
	"IN_DT" DATE, 
	"CALLBACK_YN" CHAR(1 BYTE), 
	"LAST_CALLBACK_DT" DATE, 
	"LAST_CALLBACK_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."PROC_CHANGE" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"CHA_TYPE" VARCHAR2(40 BYTE), 
	"CHA_LEVEL" VARCHAR2(40 BYTE), 
	"CHA_REQ_CONTENT" CLOB, 
	"CHA_PLAN_ST_DT" DATE, 
	"CHA_PLAN_END_DT" DATE, 
	"CHA_SER_STOP_YN" CHAR(1 BYTE), 
	"CHA_PLAN_CONTENT" CLOB, 
	"CHA_RESULT" VARCHAR2(40 BYTE), 
	"CHA_RESULT_CONTENT" CLOB, 
	"CHA_REAL_ST_DT" DATE, 
	"CHA_REAL_END_DT" DATE, 
	"CHA_CI_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(20 BYTE), 
	"UPD_DT" DATE, 
	"SUB_WORK" VARCHAR2(10 BYTE), 
	"SYSTEM_TYPE" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROC_COUNSELING_HISTORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_COUNSELING_HISTORY" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"COUNSELING_CONTENT" CLOB, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM"  ;
--------------------------------------------------------
--  DDL for Table PROC_DELETE_HISTORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_DELETE_HISTORY" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"PROC_ID" NUMBER, 
	"REQ_TYPE" VARCHAR2(8 BYTE), 
	"REQ_ZONE" VARCHAR2(40 BYTE), 
	"REQ_PATH" VARCHAR2(8 BYTE), 
	"CONTENT" CLOB, 
	"REQ_USER_ID" VARCHAR2(40 BYTE), 
	"REG_USER_ID" VARCHAR2(40 BYTE), 
	"REQ_DT" DATE, 
	"REG_DT" DATE, 
	"END_DT" DATE, 
	"PROC_VER" VARCHAR2(20 BYTE), 
	"UP_SR_ID" VARCHAR2(20 BYTE), 
	"END_TYPE" VARCHAR2(8 BYTE), 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"TITLE" VARCHAR2(200 BYTE), 
	"WORK_STATE" VARCHAR2(8 BYTE), 
	"DELETE_REASON" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM"  ;
--------------------------------------------------------
--  DDL for Table PROC_DETAIL
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_DETAIL" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"SEQ" NUMBER, 
	"ACTUALOWNER_ID" VARCHAR2(255 BYTE), 
	"WORK_STATE" VARCHAR2(30 BYTE), 
	"COMPLETEDON" DATE, 
	"COMMENT_TEXT" VARCHAR2(3000 BYTE), 
	"INS_DT" DATE, 
	"REJECT_YN" CHAR(1 BYTE) DEFAULT 'N', 
	"CONF_TYPE" CHAR(1 BYTE) DEFAULT 'N'
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROC_DETAIL_DEL_20160902
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_DETAIL_DEL_20160902" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"SEQ" NUMBER, 
	"ACTUALOWNER_ID" VARCHAR2(255 BYTE), 
	"WORK_STATE" VARCHAR2(30 BYTE), 
	"COMPLETEDON" DATE, 
	"COMMENT_TEXT" VARCHAR2(3000 BYTE), 
	"INS_DT" DATE, 
	"REJECT_YN" CHAR(1 BYTE), 
	"CONF_TYPE" CHAR(1 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROC_INCIDENT
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_INCIDENT" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"INC_ACCIDENT_DT" DATE, 
	"INC_KNOWN_DT" DATE, 
	"INC_CAUSE" VARCHAR2(50 BYTE), 
	"INC_LEVEL" VARCHAR2(50 BYTE), 
	"INC_RECOVER_DT" DATE, 
	"INC_SOLVE_TYPE" VARCHAR2(50 BYTE), 
	"INC_WORK_RESULT" CLOB, 
	"CHANGE_SR_ID" VARCHAR2(20 BYTE), 
	"PROBLEM_SR_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(50 BYTE), 
	"UPD_DT" DATE, 
	"INC_RESULT_CONTENT" CLOB, 
	"INC_IMPACT" VARCHAR2(50 BYTE), 
	"INC_SERIOUS" VARCHAR2(50 BYTE), 
	"RESULT_HOPE_DT" DATE, 
	"SUB_WORK" VARCHAR2(10 BYTE), 
	"SYSTEM_TYPE" VARCHAR2(20 BYTE), 
	"KEDB_ID" VARCHAR2(13 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROC_KEDB
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_KEDB" 
   (	"KEDB_ID" VARCHAR2(13 BYTE), 
	"TITLE" VARCHAR2(500 BYTE), 
	"CONTENT" VARCHAR2(4000 BYTE), 
	"CAUSE_TYPE" VARCHAR2(40 BYTE), 
	"TEMP_RESOLUTION" VARCHAR2(4000 BYTE), 
	"ROOT_CAUSE" VARCHAR2(4000 BYTE), 
	"RESOLUTION" VARCHAR2(4000 BYTE), 
	"WORK_CONTENT" VARCHAR2(4000 BYTE), 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."PROC_KMDB" 
   (	"KMDB_ID" VARCHAR2(20 BYTE), 
	"CATEGORY_ID" VARCHAR2(10 BYTE), 
	"TITLE" VARCHAR2(500 BYTE), 
	"CONTENT" VARCHAR2(4000 BYTE), 
	"KMDB_STATE" VARCHAR2(50 BYTE), 
	"KMDB_CNT" NUMBER, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"APPROVAL_USER_ID" VARCHAR2(20 BYTE), 
	"APPROVAL_DT" DATE, 
	"END_TYPE" VARCHAR2(50 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROC_MASTER
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_MASTER" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"PROC_ID" NUMBER, 
	"TASK_ID" NUMBER, 
	"REQ_TYPE" VARCHAR2(40 BYTE), 
	"REQ_ZONE" VARCHAR2(40 BYTE), 
	"REQ_PATH" VARCHAR2(8 BYTE), 
	"REQ_USER_ID" VARCHAR2(40 BYTE), 
	"REG_USER_ID" VARCHAR2(40 BYTE), 
	"REQ_DT" DATE, 
	"REG_DT" DATE, 
	"ASSIGN_DT" DATE, 
	"WORK_DT" DATE, 
	"END_DT" DATE, 
	"HOPE_DT" DATE, 
	"DUE_DT" DATE, 
	"DEL_YN" CHAR(1 BYTE), 
	"PROC_VER" VARCHAR2(20 BYTE), 
	"UP_SR_ID" VARCHAR2(20 BYTE), 
	"REL_INC_SR_ID" VARCHAR2(20 BYTE), 
	"END_TYPE" VARCHAR2(8 BYTE), 
	"HAPPYCALL_YN" CHAR(1 BYTE), 
	"FIRST_YN" CHAR(1 BYTE), 
	"STATIS_RESULT" VARCHAR2(3 BYTE), 
	"STATIS_CONTENT" VARCHAR2(2000 BYTE), 
	"STATIS_END_TYPE" VARCHAR2(8 BYTE), 
	"STATIS_END_DT" DATE, 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"TITLE" VARCHAR2(1000 BYTE), 
	"WORK_STATE" VARCHAR2(30 BYTE), 
	"REC_DT" DATE, 
	"STATIS_CHECK" VARCHAR2(1 BYTE), 
	"DISCONTENT_PROC_YN" CHAR(1 BYTE), 
	"LINK_REL" CHAR(1 BYTE), 
	"PROC_STATE" VARCHAR2(50 BYTE), 
	"ACCURACY_RESULT" VARCHAR2(3 BYTE), 
	"SPEED_RESULT" VARCHAR2(3 BYTE), 
	"CONTENT" VARCHAR2(3000 BYTE), 
	"RESULT_CONTENT" VARCHAR2(3000 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROC_MASTER_DEL_20160902
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_MASTER_DEL_20160902" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"PROC_ID" NUMBER, 
	"TASK_ID" NUMBER, 
	"REQ_TYPE" VARCHAR2(40 BYTE), 
	"REQ_ZONE" VARCHAR2(40 BYTE), 
	"REQ_PATH" VARCHAR2(8 BYTE), 
	"REQ_USER_ID" VARCHAR2(40 BYTE), 
	"REG_USER_ID" VARCHAR2(40 BYTE), 
	"REQ_DT" DATE, 
	"REG_DT" DATE, 
	"ASSIGN_DT" DATE, 
	"WORK_DT" DATE, 
	"END_DT" DATE, 
	"HOPE_DT" DATE, 
	"DUE_DT" DATE, 
	"DEL_YN" CHAR(1 BYTE), 
	"PROC_VER" VARCHAR2(20 BYTE), 
	"UP_SR_ID" VARCHAR2(20 BYTE), 
	"REL_INC_SR_ID" VARCHAR2(20 BYTE), 
	"END_TYPE" VARCHAR2(8 BYTE), 
	"HAPPYCALL_YN" CHAR(1 BYTE), 
	"FIRST_YN" CHAR(1 BYTE), 
	"STATIS_RESULT" VARCHAR2(3 BYTE), 
	"STATIS_CONTENT" VARCHAR2(2000 BYTE), 
	"STATIS_END_TYPE" VARCHAR2(8 BYTE), 
	"STATIS_END_DT" DATE, 
	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"TITLE" VARCHAR2(1000 BYTE), 
	"WORK_STATE" VARCHAR2(30 BYTE), 
	"REC_DT" DATE, 
	"STATIS_CHECK" VARCHAR2(1 BYTE), 
	"DISCONTENT_PROC_YN" CHAR(1 BYTE), 
	"LINK_REL" CHAR(1 BYTE), 
	"PROC_STATE" VARCHAR2(50 BYTE), 
	"ACCURACY_RESULT" VARCHAR2(3 BYTE), 
	"SPEED_RESULT" VARCHAR2(3 BYTE), 
	"CONTENT" VARCHAR2(3000 BYTE), 
	"RESULT_CONTENT" VARCHAR2(3000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROC_OLD_SERVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_OLD_SERVICE" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"OLD_SR_ID" VARCHAR2(30 BYTE), 
	"TITLE" VARCHAR2(300 BYTE), 
	"CONTENT" CLOB, 
	"REQ_USER_ID" VARCHAR2(20 BYTE), 
	"REQ_USER_NM" VARCHAR2(20 BYTE), 
	"CUST_NM" VARCHAR2(50 BYTE), 
	"CUST_ID" VARCHAR2(20 BYTE), 
	"REQ_DT" DATE, 
	"UP_SERVICE_NM" VARCHAR2(200 BYTE), 
	"UP_SERVICE_ID" VARCHAR2(30 BYTE), 
	"SERVICE_NM" VARCHAR2(200 BYTE), 
	"SERVICE_ID" VARCHAR2(30 BYTE), 
	"PROC_STATE" VARCHAR2(20 BYTE), 
	"SERVICE_TYPE" VARCHAR2(100 BYTE), 
	"DETAIL_SER_TYPE" VARCHAR2(40 BYTE), 
	"REJECT_TYPE" VARCHAR2(20 BYTE), 
	"SER_IMPORT" VARCHAR2(20 BYTE), 
	"SER_LEVEL" VARCHAR2(20 BYTE), 
	"ACCEPT_USER_NM" VARCHAR2(20 BYTE), 
	"REQ_PATH" VARCHAR2(20 BYTE), 
	"ACCEPT_DT" DATE, 
	"ACCEPT_CONTENT" CLOB, 
	"RESULT_SERVICE_TYPE" VARCHAR2(100 BYTE), 
	"REQ_DETAIL" VARCHAR2(100 BYTE), 
	"RESULT_USER" VARCHAR2(20 BYTE), 
	"RESULT_DT" DATE, 
	"WORK_RESULT" CLOB, 
	"RESOURCES_TYPE" VARCHAR2(20 BYTE), 
	"INPUT_MM" VARCHAR2(20 BYTE), 
	"INPUT_MONEY" VARCHAR2(20 BYTE), 
	"SPEED_RESULT" VARCHAR2(20 BYTE), 
	"ACCURACY_RESULT" VARCHAR2(20 BYTE), 
	"STATIS_RESULT" VARCHAR2(20 BYTE), 
	"AVG_RESULT" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM"  ;
--------------------------------------------------------
--  DDL for Table PROC_OPER
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_OPER" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"OPER_TYPE" VARCHAR2(15 BYTE), 
	"SEQ" NUMBER, 
	"OPER_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"SELECT_TYPE" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROC_REL_CONF
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_REL_CONF" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"ITEM_ID" VARCHAR2(20 BYTE), 
	"ITEM_TYPE" VARCHAR2(50 BYTE)
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."PROC_SERVICE" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"SERVICE_TYPE" VARCHAR2(50 BYTE), 
	"APPROVAL_YN" VARCHAR2(50 BYTE), 
	"WORK_RESULT" CLOB, 
	"CHANGE_SR_ID" VARCHAR2(20 BYTE), 
	"INCIDENT_SR_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(20 BYTE), 
	"UPD_DT" DATE, 
	"RESULT_HOPE_DT" DATE, 
	"RESULT_SERVICE_TYPE" VARCHAR2(50 BYTE), 
	"SUB_WORK" VARCHAR2(10 BYTE), 
	"SYSTEM_TYPE" VARCHAR2(20 BYTE), 
	"KEDB_ID" VARCHAR2(13 BYTE)
   ) TABLESPACE "ITSM"  ;
--------------------------------------------------------
--  DDL for Table PROC_SERVICE_DEL_20160902
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_SERVICE_DEL_20160902" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"SERVICE_TYPE" VARCHAR2(50 BYTE), 
	"APPROVAL_YN" VARCHAR2(50 BYTE), 
	"WORK_RESULT" CLOB, 
	"CHANGE_SR_ID" VARCHAR2(20 BYTE), 
	"INCIDENT_SR_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(20 BYTE), 
	"UPD_DT" DATE, 
	"RESULT_HOPE_DT" DATE, 
	"RESULT_SERVICE_TYPE" VARCHAR2(50 BYTE), 
	"SUB_WORK" VARCHAR2(10 BYTE), 
	"SYSTEM_TYPE" VARCHAR2(20 BYTE), 
	"KEDB_ID" VARCHAR2(13 BYTE)
   ) TABLESPACE "ITSM";
--------------------------------------------------------
--  DDL for Table PROC_TEMPLATE_FILE
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROC_TEMPLATE_FILE" 
   (	"TEM_ID" NUMBER, 
	"TEM_FILE_NM" VARCHAR2(100 BYTE), 
	"REMARKS" VARCHAR2(2000 BYTE), 
	"SAVE_FILE_NM" VARCHAR2(100 BYTE), 
	"REQ_TYPE" VARCHAR2(40 BYTE), 
	"TEM_CODE" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"ORIGIN_FILE_NM" VARCHAR2(100 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."PROPERTY_CLASS" 
   (	"CLASS_ID" NUMBER(*,0), 
	"SYSTEM_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"PROPERTY_NAME" VARCHAR2(255 BYTE), 
	"DATA_TYPE" VARCHAR2(255 BYTE), 
	"IS_BOUNDARY" NUMBER(1,0), 
	"BOUNDARY_DEPTH" NUMBER(*,0), 
	"IS_EDITABLE" NUMBER(1,0), 
	"IS_REQUIRED" NUMBER(1,0), 
	"IS_USER_DEFINED" NUMBER(1,0), 
	"IS_ENCRIPTED" NUMBER(1,0), 
	"IS_LIVE" NUMBER(1,0), 
	"LIVE_OBJECT_NAME" VARCHAR2(4000 BYTE), 
	"LIVE_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"ATTRIBUTE_NAME" VARCHAR2(255 BYTE), 
	"DEFAULT_INTEGER_VALUE" NUMBER(*,0), 
	"DEFAULT_STRING_VALUE" VARCHAR2(4000 BYTE), 
	"DEFAULT_DATE_VALUE" TIMESTAMP (6), 
	"DEFAULT_DOUBLE_VALUE" FLOAT(126), 
	"DEFAULT_BOOLEAN_VALUE" NUMBER(1,0), 
	"DEFAULT_LONG_VALUE" NUMBER(*,0), 
	"DESCRIPTION" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROPERTY_INSTANCE
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROPERTY_INSTANCE" 
   (	"INSTANCE_ID" NUMBER(*,0), 
	"OBJECT_ID" NUMBER(*,0), 
	"CLASS_ID" NUMBER(*,0), 
	"INTEGER_VALUE" NUMBER(*,0), 
	"STRING_VALUE" VARCHAR2(4000 BYTE), 
	"BOOLEAN_VALUE" NUMBER(1,0), 
	"DOUBLE_VALUE" FLOAT(126), 
	"DATE_VALUE" TIMESTAMP (6), 
	"LONG_VALUE" NUMBER(*,0), 
	"DEPTH1" VARCHAR2(255 BYTE), 
	"DEPTH2" VARCHAR2(255 BYTE), 
	"DEPTH3" VARCHAR2(255 BYTE), 
	"DEPTH4" VARCHAR2(255 BYTE), 
	"DEPTH5" VARCHAR2(255 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROPERTY_INTEGER_BOUNDARY
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROPERTY_INTEGER_BOUNDARY" 
   (	"ITEM_ID" NUMBER(*,0), 
	"CLASS_ID" NUMBER(*,0), 
	"FROM_VALUE" NUMBER(*,0), 
	"TO_VALUE" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table PROPERTY_STRING_BOUNDARY
--------------------------------------------------------

  CREATE TABLE "ITSM"."PROPERTY_STRING_BOUNDARY" 
   (	"ITEM_ID" NUMBER(*,0), 
	"CLASS_ID" NUMBER(*,0), 
	"STRING_VALUE" VARCHAR2(4000 BYTE), 
	"DEPTH1" VARCHAR2(255 BYTE), 
	"DEPTH2" VARCHAR2(255 BYTE), 
	"DEPTH3" VARCHAR2(255 BYTE), 
	"DEPTH4" VARCHAR2(255 BYTE), 
	"DEPTH5" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_CRON_TRIGGERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_CRON_TRIGGERS" 
   (	"TRIGGER_NAME" VARCHAR2(200 BYTE), 
	"TRIGGER_GROUP" VARCHAR2(200 BYTE), 
	"CRON_EXPRESSION" VARCHAR2(120 BYTE), 
	"TIME_ZONE_ID" VARCHAR2(80 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_FIRED_TRIGGERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_FIRED_TRIGGERS" 
   (	"ENTRY_ID" VARCHAR2(95 BYTE), 
	"TRIGGER_NAME" VARCHAR2(200 BYTE), 
	"TRIGGER_GROUP" VARCHAR2(200 BYTE), 
	"IS_VOLATILE" VARCHAR2(1 BYTE), 
	"INSTANCE_NAME" VARCHAR2(200 BYTE), 
	"FIRED_TIME" NUMBER(13,0), 
	"PRIORITY" NUMBER(13,0), 
	"STATE" VARCHAR2(16 BYTE), 
	"JOB_NAME" VARCHAR2(200 BYTE), 
	"JOB_GROUP" VARCHAR2(200 BYTE), 
	"IS_STATEFUL" VARCHAR2(1 BYTE), 
	"REQUESTS_RECOVERY" VARCHAR2(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_JOB_LISTENERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_JOB_LISTENERS" 
   (	"JOB_NAME" VARCHAR2(200 BYTE), 
	"JOB_GROUP" VARCHAR2(200 BYTE), 
	"JOB_LISTENER" VARCHAR2(200 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_LOCKS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_LOCKS" 
   (	"LOCK_NAME" VARCHAR2(40 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_PAUSED_TRIGGER_GRPS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_PAUSED_TRIGGER_GRPS" 
   (	"TRIGGER_GROUP" VARCHAR2(200 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_SCHEDULER_STATE
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_SCHEDULER_STATE" 
   (	"INSTANCE_NAME" VARCHAR2(200 BYTE), 
	"LAST_CHECKIN_TIME" NUMBER(13,0), 
	"CHECKIN_INTERVAL" NUMBER(13,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_SIMPLE_TRIGGERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_SIMPLE_TRIGGERS" 
   (	"TRIGGER_NAME" VARCHAR2(200 BYTE), 
	"TRIGGER_GROUP" VARCHAR2(200 BYTE), 
	"REPEAT_COUNT" NUMBER(7,0), 
	"REPEAT_INTERVAL" NUMBER(12,0), 
	"TIMES_TRIGGERED" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_STAR_CRON_TRIGGERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_STAR_CRON_TRIGGERS" 
   (	"TRIGGER_NAME" VARCHAR2(200 BYTE), 
	"TRIGGER_GROUP" VARCHAR2(200 BYTE), 
	"CRON_EXPRESSION" VARCHAR2(120 BYTE), 
	"TIME_ZONE_ID" VARCHAR2(80 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_STAR_FIRED_TRIGGERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_STAR_FIRED_TRIGGERS" 
   (	"ENTRY_ID" VARCHAR2(95 BYTE), 
	"TRIGGER_NAME" VARCHAR2(200 BYTE), 
	"TRIGGER_GROUP" VARCHAR2(200 BYTE), 
	"IS_VOLATILE" VARCHAR2(1 BYTE), 
	"INSTANCE_NAME" VARCHAR2(200 BYTE), 
	"FIRED_TIME" NUMBER(13,0), 
	"PRIORITY" NUMBER(13,0), 
	"STATE" VARCHAR2(16 BYTE), 
	"JOB_NAME" VARCHAR2(200 BYTE), 
	"JOB_GROUP" VARCHAR2(200 BYTE), 
	"IS_STATEFUL" VARCHAR2(1 BYTE), 
	"REQUESTS_RECOVERY" VARCHAR2(1 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_STAR_JOB_LISTENERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_STAR_JOB_LISTENERS" 
   (	"JOB_NAME" VARCHAR2(200 BYTE), 
	"JOB_GROUP" VARCHAR2(200 BYTE), 
	"JOB_LISTENER" VARCHAR2(200 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_STAR_LOCKS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_STAR_LOCKS" 
   (	"LOCK_NAME" VARCHAR2(40 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_STAR_PAUSED_TRIGGER_GRPS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_STAR_PAUSED_TRIGGER_GRPS" 
   (	"TRIGGER_GROUP" VARCHAR2(200 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_STAR_SCHEDULER_STATE
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_STAR_SCHEDULER_STATE" 
   (	"INSTANCE_NAME" VARCHAR2(200 BYTE), 
	"LAST_CHECKIN_TIME" NUMBER(13,0), 
	"CHECKIN_INTERVAL" NUMBER(13,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_STAR_SIMPLE_TRIGGERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_STAR_SIMPLE_TRIGGERS" 
   (	"TRIGGER_NAME" VARCHAR2(200 BYTE), 
	"TRIGGER_GROUP" VARCHAR2(200 BYTE), 
	"REPEAT_COUNT" NUMBER(7,0), 
	"REPEAT_INTERVAL" NUMBER(12,0), 
	"TIMES_TRIGGERED" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_STAR_TRIGGER_LISTENERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_STAR_TRIGGER_LISTENERS" 
   (	"TRIGGER_NAME" VARCHAR2(200 BYTE), 
	"TRIGGER_GROUP" VARCHAR2(200 BYTE), 
	"TRIGGER_LISTENER" VARCHAR2(200 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table QRTZ_TRIGGER_LISTENERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."QRTZ_TRIGGER_LISTENERS" 
   (	"TRIGGER_NAME" VARCHAR2(200 BYTE), 
	"TRIGGER_GROUP" VARCHAR2(200 BYTE), 
	"TRIGGER_LISTENER" VARCHAR2(200 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table RAW_DATA_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."RAW_DATA_BACK" 
   (	"WORK_DT" VARCHAR2(8 BYTE), 
	"SR_ID" VARCHAR2(13 BYTE), 
	"REQ_TYPE" VARCHAR2(8 BYTE), 
	"TITLE" VARCHAR2(200 BYTE), 
	"COL_DATA1" VARCHAR2(500 BYTE), 
	"COL_DATA2" VARCHAR2(500 BYTE), 
	"COL_DATA3" VARCHAR2(500 BYTE), 
	"COL_DATA4" VARCHAR2(500 BYTE), 
	"COL_DATA5" VARCHAR2(500 BYTE), 
	"COL_DATA6" VARCHAR2(500 BYTE), 
	"COL_DATA7" VARCHAR2(500 BYTE), 
	"COL_DATA8" VARCHAR2(500 BYTE), 
	"COL_DATA9" VARCHAR2(500 BYTE), 
	"COL_DATA10" VARCHAR2(500 BYTE), 
	"INS_DT" DATE, 
	"COL_DATA11" VARCHAR2(500 BYTE), 
	"COL_DATA12" VARCHAR2(500 BYTE), 
	"COL_DATA13" VARCHAR2(500 BYTE), 
	"COL_DATA14" VARCHAR2(500 BYTE), 
	"COL_DATA15" VARCHAR2(500 BYTE), 
	"COL_DATA16" VARCHAR2(500 BYTE), 
	"COL_DATA17" VARCHAR2(500 BYTE), 
	"COL_DATA18" VARCHAR2(500 BYTE), 
	"COL_DATA19" VARCHAR2(500 BYTE), 
	"COL_DATA20" VARCHAR2(500 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table REASSIGNMENT
--------------------------------------------------------

  CREATE TABLE "ITSM"."REASSIGNMENT" 
   (	"ID" NUMBER(19,0), 
	"ESCALATION_REASSIGNMENTS_ID" NUMBER(19,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table REASSIGNMENT_POTENTIALOWNERS
--------------------------------------------------------

  CREATE TABLE "ITSM"."REASSIGNMENT_POTENTIALOWNERS" 
   (	"TASK_ID" NUMBER(19,0), 
	"ENTITY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table REPORT_FORMAT
--------------------------------------------------------

  CREATE TABLE "ITSM"."REPORT_FORMAT" 
   (	"REPORT_ID" VARCHAR2(255 BYTE), 
	"REPORT_NAME" VARCHAR2(255 BYTE), 
	"REPORT_TYPE" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table REPORT_PARAMETER
--------------------------------------------------------

  CREATE TABLE "ITSM"."REPORT_PARAMETER" 
   (	"PARAMETER_ID" NUMBER(*,0), 
	"REPORT_ID" VARCHAR2(255 BYTE), 
	"PARAMETER_NAME" VARCHAR2(255 BYTE), 
	"PARAMETER_TYPE" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table REPORT_PARAMETER_VALUE
--------------------------------------------------------

  CREATE TABLE "ITSM"."REPORT_PARAMETER_VALUE" 
   (	"VALUE_ID" NUMBER(*,0), 
	"SCHEDULE_ID" NUMBER(*,0), 
	"PARAMETER_ID" NUMBER(*,0), 
	"PARAMETER_VALUE" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table REPORT_SCHEDULED
--------------------------------------------------------

  CREATE TABLE "ITSM"."REPORT_SCHEDULED" 
   (	"SCHEDULE_ID" NUMBER(*,0), 
	"REPORT_ID" VARCHAR2(255 BYTE), 
	"USER_ID" VARCHAR2(255 BYTE), 
	"MAIL_RECEIVER" VARCHAR2(4000 BYTE), 
	"IS_IGNORE_EMPTY" NUMBER(1,0), 
	"IS_PDF" NUMBER(1,0), 
	"IS_XLS" NUMBER(1,0), 
	"IS_DOC" NUMBER(1,0), 
	"IS_PPT" NUMBER(1,0), 
	"CRON_EXPRESSION" VARCHAR2(255 BYTE), 
	"EXPRESSION_SUMMARY" VARCHAR2(255 BYTE), 
	"INTERVAL_TYPE" NUMBER(*,0), 
	"IS_TO_ME" NUMBER(1,0), 
	"USER_LIST" VARCHAR2(4000 CHAR), 
	"ROLE_LIST" VARCHAR2(4000 CHAR)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table REQUIREMENT_CHECK_LIST
--------------------------------------------------------

  CREATE TABLE "ITSM"."REQUIREMENT_CHECK_LIST" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"CHECK_AREA" VARCHAR2(60 BYTE), 
	"CHECK_INDEX" VARCHAR2(60 BYTE), 
	"INDEX_ITEM" VARCHAR2(40 BYTE), 
	"INDEX_WEIGHT" VARCHAR2(3 BYTE), 
	"INDEX_SCORE" VARCHAR2(3 BYTE), 
	"INS_USER_ID" VARCHAR2(20 BYTE), 
	"INS_DT" DATE, 
	"CATEGORY_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table ROLE_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."ROLE_OBJECT" 
   (	"OBJECT_ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0), 
	"UUID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SCRIPT_TYPE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SCRIPT_TYPE" 
   (	"SCRIPT_TYPE" VARCHAR2(255 BYTE), 
	"SCRIPT_COMMAND" VARCHAR2(255 BYTE), 
	"FILE_EXTENTION" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SDK_SMS_SEND
--------------------------------------------------------

  CREATE TABLE "ITSM"."SDK_SMS_SEND" 
   (	"MSG_ID" NUMBER(10,0), 
	"USER_ID" VARCHAR2(60 BYTE), 
	"SCHEDULE_TYPE" NUMBER(10,0), 
	"SUBJECT" VARCHAR2(150 BYTE), 
	"SMS_MSG" VARCHAR2(600 BYTE), 
	"CALLBACK_URL" VARCHAR2(600 BYTE), 
	"NOW_DATE" VARCHAR2(60 BYTE), 
	"SEND_DATE" VARCHAR2(60 BYTE), 
	"CALLBACK" VARCHAR2(60 BYTE), 
	"DEST_TYPE" NUMBER(10,0), 
	"DEST_COUNT" NUMBER(10,0), 
	"DEST_INFO" VARCHAR2(150 BYTE), 
	"KT_OFFICE_CODE" VARCHAR2(60 BYTE), 
	"CDR_ID" VARCHAR2(60 BYTE), 
	"RESERVED1" VARCHAR2(150 BYTE), 
	"RESERVED2" VARCHAR2(150 BYTE), 
	"RESERVED3" VARCHAR2(150 BYTE), 
	"RESERVED4" VARCHAR2(150 BYTE), 
	"RESERVED5" VARCHAR2(150 BYTE), 
	"SEND_STATUS" NUMBER(10,0), 
	"SEND_COUNT" NUMBER(10,0), 
	"SEND_RESULT" NUMBER(10,0), 
	"SEND_PROC_TIME" VARCHAR2(60 BYTE), 
	"RESERVED6" VARCHAR2(150 BYTE), 
	"STD_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SERVER_TRANSCATION_LOCK
--------------------------------------------------------

  CREATE TABLE "ITSM"."SERVER_TRANSCATION_LOCK" 
   (	"LOCKKEY_ID" VARCHAR2(255 CHAR), 
	"DEVICE_IP" VARCHAR2(255 CHAR), 
	"LIMITED_DATE" DATE, 
	"LOCK_TYPE" VARCHAR2(255 CHAR), 
	"MANAGER_IP" VARCHAR2(255 CHAR), 
	"MESSAGE" VARCHAR2(4000 CHAR), 
	"STARTED_DATE" DATE, 
	"TIMEOUT_SEC" NUMBER(10,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SERVICE_PLUGGED
--------------------------------------------------------

  CREATE TABLE "ITSM"."SERVICE_PLUGGED" 
   (	"SERVICE_ID" NUMBER(*,0), 
	"SERVICE_NAME" VARCHAR2(255 BYTE), 
	"PLUGIN_CLASS" VARCHAR2(255 BYTE), 
	"IS_ENABLED" NUMBER(1,0), 
	"CRON_EXPRESSION" VARCHAR2(255 BYTE), 
	"EXPRESSION_SUMMARY" VARCHAR2(255 BYTE), 
	"INTERVAL_TYPE" NUMBER(*,0), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"EXECUTION_TIMEOUT" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SERVICE_PROPERTY
--------------------------------------------------------

  CREATE TABLE "ITSM"."SERVICE_PROPERTY" 
   (	"PROPERTY_ID" NUMBER(*,0), 
	"SERVICE_ID" NUMBER(*,0), 
	"PROPERTY_KEY" VARCHAR2(255 BYTE), 
	"PROPERTY_NAME" VARCHAR2(255 BYTE), 
	"PROPERTY_VALUE" VARCHAR2(2000 BYTE), 
	"VALID_FORMAT" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SERVICE_RESOURCES
--------------------------------------------------------

  CREATE TABLE "ITSM"."SERVICE_RESOURCES" 
   (	"SR_ID" VARCHAR2(20 BYTE), 
	"SEQ" NUMBER, 
	"MAIN_RESULT_CONTENT" CLOB, 
	"NOTE" CLOB, 
	"INPUT_RESOURCES" VARCHAR2(200 BYTE), 
	"RESOURCES_TYPE" VARCHAR2(50 BYTE), 
	"USER_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM"  ;
--------------------------------------------------------
--  DDL for Table SERVICE_STATE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SERVICE_STATE" 
   (	"STATE_ID" VARCHAR2(255 CHAR), 
	"SERVICE_ID" NUMBER(10,0), 
	"MANAGER_ID" VARCHAR2(255 CHAR), 
	"SERVICE_STATE" VARCHAR2(255 CHAR), 
	"START_DATE" TIMESTAMP (6), 
	"END_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SESSIONINFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."SESSIONINFO" 
   (	"ID" NUMBER(10,0), 
	"LASTMODIFICATIONDATE" DATE, 
	"RULESBYTEARRAY" BLOB, 
	"STARTDATE" DATE, 
	"OPTLOCK" NUMBER(10,0)
   )  TABLESPACE "ITSM"  ;
--------------------------------------------------------
--  DDL for Table SEVERITY_TYPE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SEVERITY_TYPE" 
   (	"SEVERITY" NUMBER(10,0), 
	"DISPLAY_NAME" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_AM_CLASS
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_AM_CLASS" 
   (	"WORK_YM" VARCHAR2(6 BYTE), 
	"CLASS_ID" VARCHAR2(20 BYTE), 
	"CLASS_NM" VARCHAR2(50 BYTE), 
	"R_CLASS_ID" VARCHAR2(100 BYTE), 
	"UP_CLASS_ID" VARCHAR2(20 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE DEFAULT SYSDATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_AM_CLASS_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_AM_CLASS_BACK" 
   (	"WORK_YM" VARCHAR2(6 BYTE), 
	"CLASS_ID" VARCHAR2(20 BYTE), 
	"CLASS_NM" VARCHAR2(50 BYTE), 
	"R_CLASS_ID" VARCHAR2(100 BYTE), 
	"UP_CLASS_ID" VARCHAR2(20 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_AM_CLASS_BACK1
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_AM_CLASS_BACK1" 
   (	"WORK_YM" VARCHAR2(6 BYTE), 
	"CLASS_ID" VARCHAR2(20 BYTE), 
	"CLASS_NM" VARCHAR2(50 BYTE), 
	"R_CLASS_ID" VARCHAR2(100 BYTE), 
	"UP_CLASS_ID" VARCHAR2(20 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_ASL_LEVEL
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_ASL_LEVEL" 
   (	"ASL_LEVEL" VARCHAR2(2 BYTE), 
	"ASL" NUMBER(15,5), 
	"START_YM" VARCHAR2(6 BYTE), 
	"INS_DT" DATE, 
	"END_YM" VARCHAR2(6 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_BATCH_MON
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_BATCH_MON" 
   (	"BATCH_ID" VARCHAR2(40 BYTE), 
	"WORK_YM" VARCHAR2(6 BYTE), 
	"STATUS" VARCHAR2(50 BYTE), 
	"START_DT" DATE, 
	"END_DT" DATE, 
	"WORK_CNT" NUMBER(15,0), 
	"ERR_DESCR" VARCHAR2(2000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_COLUMN
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_COLUMN" 
   (	"LW_YN" VARCHAR2(1 BYTE), 
	"MW_YN" VARCHAR2(1 BYTE), 
	"ESL_YN" VARCHAR2(1 BYTE), 
	"MSL_YN" VARCHAR2(1 BYTE), 
	"ASL_YN" VARCHAR2(1 BYTE), 
	"UNIT_YN" VARCHAR2(1 BYTE), 
	"RULE_YN" VARCHAR2(1 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"SCORE_LEVEL" VARCHAR2(2 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_CONF_SERVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_CONF_SERVICE" 
   (	"SERVICE_ID" VARCHAR2(20 BYTE), 
	"WORK_YM" VARCHAR2(6 BYTE), 
	"SERVICE_NM" VARCHAR2(100 BYTE), 
	"SERVICE_DESC" VARCHAR2(500 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"UP_SERVICE_ID" VARCHAR2(20 BYTE), 
	"DEPTH" NUMBER, 
	"DISPLAY_SEQ" NUMBER, 
	"LAST_NODE_YN" CHAR(1 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_CONF_SERVICE_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_CONF_SERVICE_BACK" 
   (	"SERVICE_ID" VARCHAR2(20 BYTE), 
	"WORK_YM" VARCHAR2(6 BYTE), 
	"SERVICE_NM" VARCHAR2(100 BYTE), 
	"SERVICE_DESC" VARCHAR2(500 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"UP_SERVICE_ID" VARCHAR2(20 BYTE), 
	"DEPTH" NUMBER, 
	"DISPLAY_SEQ" NUMBER, 
	"LAST_NODE_YN" CHAR(1 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_CUST_CLASS
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_CUST_CLASS" 
   (	"LCLASS_WEIGHT" NUMBER(8,5), 
	"START_YM" VARCHAR2(6 BYTE), 
	"MCLASS_WEIGHT" NUMBER(8,5), 
	"END_YM" VARCHAR2(6 BYTE), 
	"MSL" NUMBER(15,5), 
	"ESL" NUMBER(15,5), 
	"UNIT" VARCHAR2(10 BYTE), 
	"SET_DIGIT" VARCHAR2(13 BYTE), 
	"INS_DT" DATE, 
	"ACHIEVE_TYPE" VARCHAR2(2 BYTE), 
	"ACHIEVE_NULL_CHK" VARCHAR2(2 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"AUTO_DESC" VARCHAR2(2000 BYTE), 
	"WORK_ID" VARCHAR2(20 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE), 
	"SL_TYPE" VARCHAR2(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_DATA_POOL_MAPPING
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_DATA_POOL_MAPPING" 
   (	"WORK_DT" VARCHAR2(8 BYTE), 
	"SR_ID" VARCHAR2(13 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE), 
	"WORK_ID" VARCHAR2(20 BYTE), 
	"INS_DT" DATE, 
	"COL_TITLE" VARCHAR2(20 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_DAY_INPUT
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_DAY_INPUT" 
   (	"WORK_DT" VARCHAR2(8 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"MCLASS_ID" VARCHAR2(5 BYTE), 
	"USE_YN" VARCHAR2(1 BYTE), 
	"WORK_ID" VARCHAR2(20 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_DAY_MONITOR
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_DAY_MONITOR" 
   (	"WORK_DT" VARCHAR2(8 BYTE), 
	"MCLASS_WEIGHT" NUMBER(3,3), 
	"HOPE_VAL" NUMBER(16,3), 
	"REAL_VAL" NUMBER(16,3), 
	"VAL" NUMBER(6,3), 
	"MSL" NUMBER(6,3), 
	"ESL" NUMBER(6,3), 
	"TARGET" VARCHAR2(20 BYTE), 
	"LCLASS_WEIGHT" NUMBER(3,3), 
	"INS_DT" DATE, 
	"WORK_ID" VARCHAR2(20 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE), 
	"GRADE" VARCHAR2(2 BYTE), 
	"SCORE" VARCHAR2(8 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_DOC
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_DOC" 
   (	"TITLE" VARCHAR2(170 BYTE), 
	"CUST_NM" VARCHAR2(100 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"DESCR" VARCHAR2(2000 BYTE), 
	"START_YM" VARCHAR2(6 BYTE), 
	"END_YM" VARCHAR2(6 BYTE), 
	"FILE_ID" VARCHAR2(13 BYTE), 
	"DATA_NUM" NUMBER(10,0), 
	"DOC_TYPE" VARCHAR2(8 BYTE), 
	"DOC_COUNT" NUMBER DEFAULT 0
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_GRADE_STATUS
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_GRADE_STATUS" 
   (	"S_LEVEL_1" NUMBER(7,4), 
	"START_YM" VARCHAR2(6 BYTE), 
	"S_LEVEL_2" NUMBER(7,4), 
	"END_YM" VARCHAR2(6 BYTE), 
	"S_LEVEL_3" NUMBER(7,4), 
	"S_LEVEL_4" NUMBER(7,4), 
	"S_LEVEL_5" NUMBER(7,4), 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE), 
	"S_LEVEL_6" NUMBER(7,4)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_MCLASS_ITEM
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_MCLASS_ITEM" 
   (	"MCLASS_ID" VARCHAR2(5 BYTE), 
	"MCLASS_ITEM" VARCHAR2(50 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_MON_MONITOR
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_MON_MONITOR" 
   (	"MCLASS_WEIGHT" NUMBER(3,3), 
	"WORK_YM" VARCHAR2(6 BYTE), 
	"HOPE_VAL" NUMBER(16,3), 
	"REAL_VAL" NUMBER(16,3), 
	"VAL" NUMBER(6,3), 
	"TARGET" VARCHAR2(20 BYTE), 
	"MSL" NUMBER(5,3), 
	"ESL" NUMBER(5,3), 
	"INS_DT" DATE, 
	"WORK_ID" VARCHAR2(20 BYTE), 
	"LCLASS_WEIGHT" NUMBER(3,3), 
	"GRADE" VARCHAR2(2 BYTE), 
	"SCORE" VARCHAR2(8 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_POOL_LCLASS
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_POOL_LCLASS" 
   (	"LCLASS_ID" VARCHAR2(5 BYTE), 
	"LCLASS_NM" VARCHAR2(50 BYTE), 
	"DESCR" VARCHAR2(2000 BYTE), 
	"USE_YN" VARCHAR2(1 BYTE), 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"UP_LCLASS_ID" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_POOL_MCLASS
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_POOL_MCLASS" 
   (	"MCLASS_ID" VARCHAR2(5 BYTE), 
	"MCLASS_NM" VARCHAR2(50 BYTE), 
	"EXEC_METHOD" CHAR(1 BYTE), 
	"USE_YN" VARCHAR2(1 BYTE), 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"SERVICE_GRP" VARCHAR2(10 BYTE), 
	"LCLASS_ID" VARCHAR2(5 BYTE), 
	"RAWDATA_TYPE" VARCHAR2(20 BYTE), 
	"DESCR" VARCHAR2(2000 BYTE), 
	"SLMS_CYCLE" VARCHAR2(10 BYTE), 
	"CYCLE_DETAIL" VARCHAR2(30 BYTE), 
	"MCLASS_ITEM_TYPE" VARCHAR2(15 BYTE), 
	"GRADE_TYPE" VARCHAR2(20 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_PRO_ERROR
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_PRO_ERROR" 
   (	"SLMS_ID" VARCHAR2(50 BYTE), 
	"WORK_DT" VARCHAR2(8 BYTE), 
	"ERR_MSG" VARCHAR2(500 BYTE), 
	"PROC_ID" VARCHAR2(20 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_RAW_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_RAW_DATA" 
   (	"WORK_DT" VARCHAR2(8 BYTE), 
	"SR_ID" VARCHAR2(13 BYTE), 
	"REQ_TYPE" VARCHAR2(8 BYTE), 
	"TITLE" VARCHAR2(200 BYTE), 
	"COL_DATA1" VARCHAR2(500 BYTE), 
	"COL_DATA2" VARCHAR2(500 BYTE), 
	"COL_DATA3" VARCHAR2(500 BYTE), 
	"COL_DATA4" VARCHAR2(500 BYTE), 
	"COL_DATA5" VARCHAR2(500 BYTE), 
	"COL_DATA6" VARCHAR2(500 BYTE), 
	"COL_DATA7" VARCHAR2(500 BYTE), 
	"COL_DATA8" VARCHAR2(500 BYTE), 
	"COL_DATA9" VARCHAR2(500 BYTE), 
	"COL_DATA10" VARCHAR2(500 BYTE), 
	"INS_DT" DATE, 
	"COL_DATA11" VARCHAR2(500 BYTE), 
	"COL_DATA12" VARCHAR2(500 BYTE), 
	"COL_DATA13" VARCHAR2(500 BYTE), 
	"COL_DATA14" VARCHAR2(500 BYTE), 
	"COL_DATA15" VARCHAR2(500 BYTE), 
	"COL_DATA16" VARCHAR2(500 BYTE), 
	"COL_DATA17" VARCHAR2(500 BYTE), 
	"COL_DATA18" VARCHAR2(500 BYTE), 
	"COL_DATA19" VARCHAR2(500 BYTE), 
	"COL_DATA20" VARCHAR2(500 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_RAW_DATA_TITLE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_RAW_DATA_TITLE" 
   (	"COL_TITLE" VARCHAR2(20 BYTE), 
	"COL_TITLE_NM" VARCHAR2(100 BYTE), 
	"COL_DATA1" VARCHAR2(20 BYTE), 
	"COL_DATA2" VARCHAR2(20 BYTE), 
	"COL_DATA3" VARCHAR2(20 BYTE), 
	"COL_DATA4" VARCHAR2(20 BYTE), 
	"COL_DATA5" VARCHAR2(20 BYTE), 
	"COL_DATA6" VARCHAR2(20 BYTE), 
	"COL_DATA7" VARCHAR2(20 BYTE), 
	"COL_DATA8" VARCHAR2(20 BYTE), 
	"COL_DATA9" VARCHAR2(20 BYTE), 
	"COL_DATA10" VARCHAR2(20 BYTE), 
	"INS_DT" DATE, 
	"COL_DATA11" VARCHAR2(20 BYTE), 
	"COL_DATA12" VARCHAR2(20 BYTE), 
	"COL_DATA13" VARCHAR2(20 BYTE), 
	"COL_DATA14" VARCHAR2(20 BYTE), 
	"COL_DATA15" VARCHAR2(20 BYTE), 
	"COL_DATA16" VARCHAR2(20 BYTE), 
	"COL_DATA17" VARCHAR2(20 BYTE), 
	"COL_DATA18" VARCHAR2(20 BYTE), 
	"COL_DATA19" VARCHAR2(20 BYTE), 
	"COL_DATA20" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_RECALC_RESULT
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_RECALC_RESULT" 
   (	"WORK_DT" VARCHAR2(20 BYTE), 
	"WORK_ID" VARCHAR2(20 BYTE), 
	"INS_DT" DATE, 
	"ID" NUMBER, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"RESULT" VARCHAR2(20 BYTE), 
	"RECALC_TYPE" VARCHAR2(4 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_RESULT_MNG
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_RESULT_MNG" 
   (	"WORK_YM" VARCHAR2(6 BYTE), 
	"VAL" NUMBER(6,3), 
	"MSL" NUMBER(6,3), 
	"ESL" NUMBER(6,3), 
	"DESCR" VARCHAR2(500 BYTE), 
	"UNIT" VARCHAR2(10 BYTE), 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SCORE_STATUS
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SCORE_STATUS" 
   (	"S_SCORE_1" NUMBER(7,4), 
	"S_SCORE_2" NUMBER(7,4), 
	"S_SCORE_3" NUMBER(7,4), 
	"S_SCORE_4" NUMBER(7,4), 
	"S_SCORE_5" NUMBER(7,4), 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE), 
	"START_YM" VARCHAR2(6 BYTE), 
	"END_YM" VARCHAR2(6 BYTE), 
	"S_SCORE_6" NUMBER(7,4)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SERVER_AVAIL
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SERVER_AVAIL" 
   (	"NOR_OP_STIME" VARCHAR2(4 BYTE), 
	"NOR_OP_ETIME" VARCHAR2(4 BYTE), 
	"SAT_OP_STIME" VARCHAR2(4 BYTE), 
	"SAT_OP_ETIME" VARCHAR2(4 BYTE), 
	"HOL_OP_STIME" VARCHAR2(4 BYTE), 
	"HOL_OP_ETIME" VARCHAR2(4 BYTE), 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"START_YM" VARCHAR2(6 BYTE), 
	"END_YM" VARCHAR2(6 BYTE), 
	"CONF_ID" VARCHAR2(40 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SERVER_AVAIL_MONITOR
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SERVER_AVAIL_MONITOR" 
   (	"WORK_DT" VARCHAR2(8 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"TARGET" VARCHAR2(20 BYTE), 
	"PLAN_TIME" NUMBER(8,3), 
	"IM_TIME" NUMBER(8,3), 
	"IM_CNT" NUMBER(4,0), 
	"AVAIL_VAL" NUMBER(9,4), 
	"INS_DT" DATE, 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SERVER_AVAIL_MONITOR_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SERVER_AVAIL_MONITOR_BACK" 
   (	"WORK_DT" VARCHAR2(8 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"TARGET" VARCHAR2(20 BYTE), 
	"PLAN_TIME" NUMBER(8,3), 
	"IM_TIME" NUMBER(8,3), 
	"IM_CNT" NUMBER(4,0), 
	"AVAIL_VAL" NUMBER(9,4), 
	"INS_DT" DATE, 
	"SLMS_ID" VARCHAR2(50 BYTE), 
	"CI_ID" VARCHAR2(40 BYTE), 
	"RANK" NUMBER
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SERVER_CUST
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SERVER_CUST" 
   (	"START_YM" VARCHAR2(6 BYTE), 
	"INS_DT" DATE, 
	"CONF_ID" VARCHAR2(40 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"END_YM" VARCHAR2(6 BYTE), 
	"CONF_NM" VARCHAR2(400 BYTE), 
	"MODEL_NM" VARCHAR2(400 BYTE), 
	"HOST_NM" VARCHAR2(400 BYTE), 
	"WORK_YM" VARCHAR2(6 BYTE), 
	"ASSET_ID" VARCHAR2(400 BYTE), 
	"CLASS_ID" VARCHAR2(20 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SERVER_CUST_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SERVER_CUST_BACK" 
   (	"START_YM" VARCHAR2(6 BYTE), 
	"INS_DT" DATE, 
	"CONF_ID" VARCHAR2(40 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"END_YM" VARCHAR2(6 BYTE), 
	"CONF_NM" VARCHAR2(400 BYTE), 
	"MODEL_NM" VARCHAR2(400 BYTE), 
	"HOST_NM" VARCHAR2(400 BYTE), 
	"WORK_YM" VARCHAR2(6 BYTE), 
	"ASSET_ID" VARCHAR2(400 BYTE), 
	"CLASS_ID" VARCHAR2(20 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SERVICE_AVAIL
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SERVICE_AVAIL" 
   (	"NOR_OP_STIME" VARCHAR2(4 BYTE), 
	"NOR_OP_ETIME" VARCHAR2(4 BYTE), 
	"SAT_OP_STIME" VARCHAR2(4 BYTE), 
	"SAT_OP_ETIME" VARCHAR2(4 BYTE), 
	"HOL_OP_STIME" VARCHAR2(4 BYTE), 
	"HOL_OP_ETIME" VARCHAR2(4 BYTE), 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"START_YM" VARCHAR2(6 BYTE), 
	"END_YM" VARCHAR2(6 BYTE), 
	"SERVICE_ID" VARCHAR2(20 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SERVICE_AVAIL_MONITOR
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SERVICE_AVAIL_MONITOR" 
   (	"WORK_DT" VARCHAR2(8 BYTE), 
	"SERVICE_ID" VARCHAR2(20 BYTE), 
	"TARGET" VARCHAR2(20 BYTE), 
	"PLAN_TIME" NUMBER(8,3), 
	"IM_TIME" NUMBER(8,3), 
	"IM_CNT" NUMBER(4,0), 
	"AVAIL_VAL" NUMBER(9,4), 
	"S_EFFECT_SCALE" NUMBER(10,0), 
	"W_EFFECT_SCALE" NUMBER(10,0), 
	"INS_DT" DATE, 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SERVICE_CUST
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SERVICE_CUST" 
   (	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"START_YM" VARCHAR2(6 BYTE), 
	"END_YM" VARCHAR2(6 BYTE), 
	"SERVICE_ID" VARCHAR2(20 BYTE), 
	"SERVICE_WEIGHT" NUMBER(3,3), 
	"EFFECT_SCALE" NUMBER, 
	"WORK_YM" VARCHAR2(6 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SEVERITY
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SEVERITY" 
   (	"IM_LVL" VARCHAR2(4 BYTE), 
	"START_YM" VARCHAR2(6 BYTE), 
	"RESO_TIME" VARCHAR2(10 BYTE), 
	"END_YM" VARCHAR2(6 BYTE), 
	"USE_YN" VARCHAR2(1 BYTE), 
	"INS_DT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"PROB_CNT" VARCHAR2(5 BYTE), 
	"PROB_WEIGHT" VARCHAR2(3 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SLMS_CALEN
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SLMS_CALEN" 
   (	"SOLAR" NUMBER, 
	"YUN" VARCHAR2(1 BYTE), 
	"WEEK" NUMBER, 
	"HOLI_YN" VARCHAR2(1 BYTE), 
	"LUNAR" NUMBER, 
	"DESCR" VARCHAR2(100 BYTE), 
	"REG_DT" DATE, 
	"REG_USER" VARCHAR2(14 BYTE), 
	"MOD_DT" DATE, 
	"MOD_USER" VARCHAR2(14 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SLMS_CLASS
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SLMS_CLASS" 
   (	"CUST_ID" VARCHAR2(40 BYTE), 
	"SLMS_ID" VARCHAR2(50 BYTE), 
	"MCLASS_ID" VARCHAR2(5 BYTE), 
	"LCLASS_ID" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SLMS_CLASS_HISTORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SLMS_CLASS_HISTORY" 
   (	"SLMS_ID" VARCHAR2(50 BYTE), 
	"START_YM" VARCHAR2(6 BYTE), 
	"END_YM" VARCHAR2(6 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SLA_SMS_USER
--------------------------------------------------------

  CREATE TABLE "ITSM"."SLA_SMS_USER" 
   (	"CUST_ID" VARCHAR2(20 BYTE), 
	"USER_ID" VARCHAR2(40 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SMS_GROUP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SMS_GROUP" 
   (	"SMS_GRP_ID" VARCHAR2(10 BYTE), 
	"SMS_GRP_NM" VARCHAR2(100 BYTE), 
	"UP_SMS_GRP_ID" VARCHAR2(10 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" VARCHAR2(1 BYTE), 
	"DEFAULT_MSG" VARCHAR2(2000 BYTE), 
	"REG_USER_ID" VARCHAR2(40 BYTE), 
	"REG_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SMS_GROUP_USER" 
   (	"USER_ID" VARCHAR2(40 BYTE), 
	"SMS_GRP_ID" VARCHAR2(10 BYTE), 
	"REG_USER_ID" VARCHAR2(40 BYTE), 
	"REG_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SP_LIST_DATA" 
   (	"GRP_ID" VARCHAR2(30 BYTE), 
	"COMM_ID" VARCHAR2(100 BYTE), 
	"COMM_NM" VARCHAR2(100 BYTE), 
	"COMM_DESC" VARCHAR2(200 BYTE), 
	"REL_ID" VARCHAR2(200 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"SORT" NUMBER, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MULTI_ID" VARCHAR2(20 BYTE), 
	"TABLE_ID" VARCHAR2(50 BYTE), 
	"MODIFY_YN" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SP_TREE_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."SP_TREE_DATA" 
   (	"CUST_ID" VARCHAR2(40 BYTE), 
	"CUST_NM" VARCHAR2(100 BYTE), 
	"UP_CUST_ID" VARCHAR2(40 BYTE), 
	"CUST_DESC" VARCHAR2(2000 BYTE), 
	"DEPTH" NUMBER(16,0), 
	"DISPLAY_SEQ" NUMBER(16,0), 
	"USE_YN" CHAR(1 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"TEL_NO" VARCHAR2(30 BYTE), 
	"FAX_NO" VARCHAR2(30 BYTE), 
	"R_CUST_ID" VARCHAR2(40 BYTE), 
	"ENGLISH_NAME" VARCHAR2(100 BYTE), 
	"IS_ORGANIZATION" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SR_IMPORT_HANNIE_20150812
--------------------------------------------------------

  CREATE TABLE "ITSM"."SR_IMPORT_HANNIE_20150812" 
   (	"SR_ID" VARCHAR2(1000 BYTE), 
	"REQ_USER" VARCHAR2(1000 BYTE), 
	"TITLE" VARCHAR2(1000 BYTE), 
	"REQ_COMMENT" VARCHAR2(1000 BYTE), 
	"REQ_DATE" VARCHAR2(1000 BYTE), 
	"HOPE_DATE" VARCHAR2(1000 BYTE), 
	"PLAN_DATE" VARCHAR2(1000 BYTE), 
	"GROUP_COMMENT" VARCHAR2(1000 BYTE), 
	"END_DATE" VARCHAR2(1000 BYTE), 
	"RESULT_COMMENT" VARCHAR2(1000 BYTE), 
	"SYSTEM_TYPE" VARCHAR2(1000 BYTE), 
	"SUB_WORK" VARCHAR2(1000 BYTE), 
	"SERVICE_TYPE" VARCHAR2(1000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SR_IMPORT_HANNIE_20150824
--------------------------------------------------------

  CREATE TABLE "ITSM"."SR_IMPORT_HANNIE_20150824" 
   (	"SR_ID" VARCHAR2(1000 BYTE), 
	"REQ_USER" VARCHAR2(1000 BYTE), 
	"TITLE" VARCHAR2(1000 BYTE), 
	"REQ_COMMENT" VARCHAR2(2000 BYTE), 
	"REQ_DATE" VARCHAR2(1000 BYTE), 
	"HOPE_DATE" VARCHAR2(1000 BYTE), 
	"PLAN_DATE" VARCHAR2(1000 BYTE), 
	"GROUP_COMMENT" VARCHAR2(2000 BYTE), 
	"END_DATE" VARCHAR2(1000 BYTE), 
	"RESULT_COMMENT" VARCHAR2(2000 BYTE), 
	"SYSTEM_TYPE" VARCHAR2(1000 BYTE), 
	"SUB_WORK" VARCHAR2(1000 BYTE), 
	"SERVICE_TYPE" VARCHAR2(1000 BYTE), 
	"MANAGER" VARCHAR2(100 BYTE), 
	"SUB_MANAGER" VARCHAR2(100 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_DAY_201404
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_DAY_201404" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_DAY_201405
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_DAY_201405" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_DAY_201406
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_DAY_201406" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_HOUR_2014041
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_HOUR_2014041" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_HOUR_2014042
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_HOUR_2014042" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_HOUR_2014043
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_HOUR_2014043" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_HOUR_2014050
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_HOUR_2014050" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_HOUR_2014051
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_HOUR_2014051" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_HOUR_2014061
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_HOUR_2014061" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_HOUR_2014062
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_HOUR_2014062" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_HOUR_2014063
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_HOUR_2014063" 
   (	"ATTRIBUTE_ID" NUMBER(*,0), 
	"STAT_DATE" VARCHAR2(12 BYTE), 
	"MIN_VALUE" NUMBER, 
	"MAX_VALUE" NUMBER, 
	"TOTAL_VALUE" NUMBER, 
	"TOTAL_COUNT" NUMBER(*,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table STAT_TABLE_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."STAT_TABLE_INFO" 
   (	"TABLE_NAME" VARCHAR2(255 CHAR), 
	"CREATE_DATE" TIMESTAMP (6), 
	"LAST_DATE" TIMESTAMP (6), 
	"ROW_COUNT" NUMBER(19,0), 
	"STAT_TYPE" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SUBTASKSSTRATEGY
--------------------------------------------------------

  CREATE TABLE "ITSM"."SUBTASKSSTRATEGY" 
   (	"DTYPE" VARCHAR2(100 BYTE), 
	"ID" NUMBER(19,0), 
	"NAME" VARCHAR2(255 BYTE), 
	"TASK_ID" NUMBER(19,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_EOS_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_EOS_OBJECT" 
   (	"SWEOS_ID" NUMBER(10,0), 
	"SERVICE" NUMBER(10,0), 
	"SERVICEENDDATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_GATHER_RESULT
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_GATHER_RESULT" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"SWMASTER_ID" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0), 
	"FAILCAUSE" VARCHAR2(255 CHAR), 
	"STATUS" NUMBER(10,0), 
	"GATHERDATE" TIMESTAMP (6), 
	"SCRIPTVERSION" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_LICENSE_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_LICENSE_OBJECT" 
   (	"SWLICENSE_ID" NUMBER(10,0), 
	"LICENSETYPE" VARCHAR2(255 CHAR), 
	"LICENSECNT" NUMBER(10,0), 
	"VENDOR" VARCHAR2(255 CHAR), 
	"UNLIMITEDLICENSECNT" NUMBER(1,0), 
	"LICENSESTARTDATE" TIMESTAMP (6), 
	"LICENSEENDDATE" TIMESTAMP (6), 
	"PERMANENTLICENSE" NUMBER(1,0), 
	"COMPLIANT" NUMBER(10,0), 
	"PERMITCOMPLIANT" NUMBER(1,0), 
	"COUNTCOMPLIANT" NUMBER(1,0), 
	"PERIODCOMPLIANT" NUMBER(1,0), 
	"INSTALLEDCNT" NUMBER(10,0), 
	"UNPERMITTEDCNT" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_LIVESW
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_LIVESW" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"NAME" VARCHAR2(255 CHAR), 
	"PATH" VARCHAR2(255 CHAR), 
	"VERSION" VARCHAR2(255 CHAR), 
	"INSTALLEDDATE" TIMESTAMP (6), 
	"DEVICE_ID" NUMBER(10,0), 
	"SWMASTER_ID" NUMBER(10,0), 
	"INSTANCECNT" NUMBER(10,0), 
	"DATE_CREATED" TIMESTAMP (6), 
	"DATE_DELETED" TIMESTAMP (6), 
	"SWLICENSE_ID" NUMBER(10,0), 
	"INNERSERVERSWKEY" VARCHAR2(255 CHAR), 
	"PERMITTED" NUMBER(10,0), 
	"MANAGED" NUMBER(10,0), 
	"SCRIPTVERSION" VARCHAR2(255 CHAR), 
	"SWEOS_ID" NUMBER(10,0), 
	"SWEDITION" VARCHAR2(255 CHAR), 
	"INNERNAME" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_MAIN_SCRIPT_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_MAIN_SCRIPT_INFO" 
   (	"OSTYPE" VARCHAR2(255 CHAR), 
	"SCIPTINFO" LONG
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_MASTERSW_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_MASTERSW_INFO" 
   (	"OBJECTID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_MASTER_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_MASTER_OBJECT" 
   (	"SWMASTER_ID" NUMBER(10,0), 
	"MASTER" NUMBER(1,0), 
	"SWUUID" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_MASTER_OSS
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_MASTER_OSS" 
   (	"SWMASTER_ID" NUMBER(10,0), 
	"OSSLICENSE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_OSSLICENSE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_OSSLICENSE" 
   (	"OSSLICENSE_ID" NUMBER(10,0), 
	"USEFREE" NUMBER(1,0), 
	"DEPLOY" NUMBER(1,0), 
	"ACCEPTSOURCECODE" NUMBER(1,0), 
	"UPDATESOUCECODE" NUMBER(1,0), 
	"SECONDPRODUCTOPEN" NUMBER(1,0), 
	"SWCOMBINE" NUMBER(1,0), 
	"SOURCEURL" VARCHAR2(255 CHAR), 
	"LICENSEVERSION" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_PERMITTED_DEVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_PERMITTED_DEVICE" 
   (	"SWLICENSE_ID" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_PERMITTED_DEVICE_GROUP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_PERMITTED_DEVICE_GROUP" 
   (	"SWLICENSE_ID" NUMBER(10,0), 
	"GROUP_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_REGISTERED
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_REGISTERED" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"NAME" VARCHAR2(255 CHAR), 
	"VERSION" VARCHAR2(255 CHAR), 
	"SWLICENSE_ID" NUMBER(10,0), 
	"SWEOS_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_SCRIPT_INDEX
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_SCRIPT_INDEX" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"OSTYPE" VARCHAR2(255 CHAR), 
	"SWMASTERNAME" VARCHAR2(255 CHAR), 
	"SCRIPTINDEX" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_SCRIPT_VER
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_SCRIPT_VER" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"HASTOUPDATE" NUMBER(1,0), 
	"MINORUPDATE" NUMBER(1,0), 
	"CUSTOMUPDATE" NUMBER(1,0), 
	"MAJOR" NUMBER(10,0), 
	"MINOR" NUMBER(10,0), 
	"CUSTOM" NUMBER(10,0), 
	"TEMP" NUMBER(10,0), 
	"VERSIONINFO" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_SERVER_RESULT
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_SERVER_RESULT" 
   (	"SW_SERVER_RESULT_ID" NUMBER(10,0), 
	"DEPLOYWINLIB" NUMBER(1,0), 
	"DEPLOYSCRIPT" NUMBER(1,0), 
	"FAULTCAUSEWINLIB" VARCHAR2(255 CHAR), 
	"FAULTCAUSESCRIPT" VARCHAR2(255 CHAR), 
	"DEVICE_ID" NUMBER(10,0), 
	"WINLIBDATE" TIMESTAMP (6), 
	"SCRIPTDATE" TIMESTAMP (6)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_SERVER_VER
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_SERVER_VER" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0), 
	"VERSIONINFO" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_SWLICENSE_OSSLICENSE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_SWLICENSE_OSSLICENSE" 
   (	"SWLICENSE_ID" NUMBER(10,0), 
	"OBJECT_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_TARGET_DEVICE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_TARGET_DEVICE" 
   (	"SWLICENSE_ID" NUMBER(10,0), 
	"DEVICE_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SW_TARGET_DEVICE_GROUP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SW_TARGET_DEVICE_GROUP" 
   (	"SWLICENSE_ID" NUMBER(10,0), 
	"GROUP_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYSTEM_FLAG
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYSTEM_FLAG" 
   (	"FLAG_NAME" VARCHAR2(255 BYTE), 
	"FLAG_VALUE" VARCHAR2(4000 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYSTEM_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYSTEM_OBJECT" 
   (	"OBJECT_ID" NUMBER(*,0), 
	"SYSTEM_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"OBJECT_NAME" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"OS_TYPE" VARCHAR2(255 BYTE), 
	"DATE_CREATED" TIMESTAMP (6), 
	"DATE_MODIFIED" TIMESTAMP (6), 
	"USER_CREATED" VARCHAR2(255 BYTE), 
	"USER_MODIFIED" VARCHAR2(255 BYTE), 
	"DATE_DELETED" TIMESTAMP (6), 
	"USER_DELETED" VARCHAR2(255 BYTE), 
	"CLASSIFICATION" VARCHAR2(4000 BYTE), 
	"IS_STARRED" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYSTEM_OBJECT_TYPE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYSTEM_OBJECT_TYPE" 
   (	"SYSTEM_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"JAVA_CLASS" VARCHAR2(4000 BYTE), 
	"PARENT_OBJECT_TYPE" VARCHAR2(255 BYTE), 
	"OBJECT_TYPE_PATH" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYSTEM_PROPERTY
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYSTEM_PROPERTY" 
   (	"PROPERTY_KEY" VARCHAR2(255 BYTE), 
	"PROPERTY_NAME" VARCHAR2(255 BYTE), 
	"PROPERTY_VALUE" VARCHAR2(4000 BYTE), 
	"DEFAULT_VALUE" VARCHAR2(4000 BYTE), 
	"PROPERTY_TYPE" VARCHAR2(255 BYTE), 
	"VALID_FORMAT" VARCHAR2(255 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_ATCH_FILE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_ATCH_FILE" 
   (	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"SOURCE_URL" VARCHAR2(200 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_ATCH_FILE_DETAIL" 
   (	"ATCH_FILE_ID" VARCHAR2(20 BYTE), 
	"FILE_IDX" NUMBER, 
	"FILE_STORE_COURS" VARCHAR2(2000 BYTE), 
	"STORE_FILE_NAME" VARCHAR2(200 BYTE), 
	"ORIGNL_FILE_NAME" VARCHAR2(200 BYTE), 
	"FILE_CONTENT_TYPE" VARCHAR2(200 BYTE), 
	"FILE_EXTSN" VARCHAR2(20 BYTE), 
	"FILE_SIZE" NUMBER, 
	"FILE_BINARY" BLOB, 
	"DEL_YN" CHAR(1 BYTE), 
	"TEMP_SAVE_YN" CHAR(1 BYTE), 
	"TASK_ID" VARCHAR2(50 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"WORK_STATE" VARCHAR2(30 BYTE)
   )  TABLESPACE "ITSM"  ;
--------------------------------------------------------
--  DDL for Table SYS_AUTH
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_AUTH" 
   (	"AUTH_ID" VARCHAR2(20 BYTE), 
	"AUTH_NM" VARCHAR2(100 BYTE), 
	"AUTH_DESC" VARCHAR2(1000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"USE_YN" CHAR(1 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_AUTH_TO_MENU
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_AUTH_TO_MENU" 
   (	"AUTH_ID" VARCHAR2(20 BYTE), 
	"MENU_ID" VARCHAR2(20 BYTE), 
	"AUTH_CUDE" VARCHAR2(4 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_CATEGORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_CATEGORY" 
   (	"CATEGORY_TYPE" VARCHAR2(50 BYTE), 
	"CATEGORY_ID" VARCHAR2(10 BYTE), 
	"CATEGORY_NM" VARCHAR2(100 BYTE), 
	"R_CATEGORY_ID" VARCHAR2(10 BYTE), 
	"UP_CATEGORY_ID" VARCHAR2(10 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_CODE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_CODE" 
   (	"CODE_GRP_ID" VARCHAR2(50 BYTE), 
	"CODE_ID" VARCHAR2(50 BYTE), 
	"CODE_NM" VARCHAR2(100 BYTE), 
	"CODE_DESC" VARCHAR2(1000 BYTE), 
	"UP_CODE_ID" VARCHAR2(20 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_COLUMN_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_COLUMN_INFO" 
   (	"LIST_ID" VARCHAR2(100 BYTE), 
	"SEQ" NUMBER, 
	"COLUMN_NM" VARCHAR2(100 BYTE), 
	"LABEL_NM" VARCHAR2(100 BYTE), 
	"ROWS_ORDERBY" VARCHAR2(5 BYTE), 
	"COLUMN_LENGTH" VARCHAR2(5 BYTE), 
	"COLUMN_ORDERBY" VARCHAR2(100 BYTE), 
	"VIEW_TYPE" VARCHAR2(250 BYTE), 
	"VIEW_YN" CHAR(1 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"TABLE_NM" VARCHAR2(20 BYTE), 
	"FUNC_TYPE" VARCHAR2(10 BYTE), 
	"DATA_TYPE" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_CUST" 
   (	"CUST_ID" VARCHAR2(40 BYTE), 
	"CUST_NM" VARCHAR2(100 BYTE), 
	"UP_CUST_ID" VARCHAR2(40 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"R_CUST_ID" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_CUST_BACK
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_CUST_BACK" 
   (	"CUST_ID" VARCHAR2(40 BYTE), 
	"CUST_NM" VARCHAR2(100 BYTE), 
	"UP_CUST_ID" VARCHAR2(40 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"R_CUST_ID" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_CUST_CHARGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_CUST_CHARGE" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"CONF_TYPE" VARCHAR2(8 BYTE), 
	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_CUST_CONF_CHARGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_CUST_CONF_CHARGE" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"CONF_TYPE" VARCHAR2(8 BYTE), 
	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DATE" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_CUST_SERVICE_CHARGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_CUST_SERVICE_CHARGE" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"SERVICE_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DATE" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_CUST_TMP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_CUST_TMP" 
   (	"CUST_ID" VARCHAR2(40 BYTE), 
	"CUST_NM" VARCHAR2(100 BYTE), 
	"UP_CUST_ID" VARCHAR2(40 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"R_CUST_ID" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_DEPT_CONF_TYPE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_DEPT_CONF_TYPE" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"COL_TYPE" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_DEPT_CONF_TYPE_BACK_0828
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_DEPT_CONF_TYPE_BACK_0828" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"SV" CHAR(1 BYTE), 
	"ST" CHAR(1 BYTE), 
	"SC" CHAR(1 BYTE), 
	"BK" CHAR(1 BYTE), 
	"NW" CHAR(1 BYTE), 
	"SW" CHAR(1 BYTE), 
	"ET" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_EACH_CONF_TYPE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_EACH_CONF_TYPE" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_EXCEL_HISTORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_EXCEL_HISTORY" 
   (	"EXCEL_FILE_ID" VARCHAR2(20 BYTE), 
	"FILE_NM" VARCHAR2(500 BYTE), 
	"REAL_FILE_NM" VARCHAR2(500 BYTE), 
	"FILE_EXTSN" VARCHAR2(20 BYTE), 
	"DOWN_USER_ID" VARCHAR2(40 BYTE), 
	"DOWN_DT" DATE, 
	"NAVIGATION" VARCHAR2(100 BYTE), 
	"UPLOAD_PATH" VARCHAR2(500 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_EXCEL_HISTORY_DETAIL
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_EXCEL_HISTORY_DETAIL" 
   (	"EXCEL_FILE_ID" VARCHAR2(20 BYTE), 
	"SHEET_IDX" NUMBER, 
	"SHEET_NM" VARCHAR2(200 BYTE), 
	"SHEET_DATA" VARCHAR2(200 BYTE), 
	"SHEET_ROW_CNT" VARCHAR2(200 BYTE), 
	"SHEET_COL_CNT" VARCHAR2(200 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_INCIDENT_LVL
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_INCIDENT_LVL" 
   (	"EFFECT" CHAR(1 BYTE), 
	"URGENCY1" CHAR(1 BYTE), 
	"URGENCY2" CHAR(1 BYTE), 
	"URGENCY3" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_INCIDENT_TIME
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_INCIDENT_TIME" 
   (	"INC_LVL" CHAR(1 BYTE), 
	"INC_LVL_TIME" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_JOIN_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_JOIN_INFO" 
   (	"LIST_ID" VARCHAR2(100 BYTE), 
	"SEQ" NUMBER, 
	"JOIN_KEY" VARCHAR2(500 BYTE), 
	"USER_ADD_TYPE" VARCHAR2(8 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_LIST_MASTER" 
   (	"LIST_ID" VARCHAR2(100 BYTE), 
	"LIST_NM" VARCHAR2(100 BYTE), 
	"MENU_ID" VARCHAR2(20 BYTE), 
	"STATE" VARCHAR2(8 BYTE), 
	"EXCEL_TYPE" VARCHAR2(8 BYTE), 
	"QRY" VARCHAR2(4000 BYTE), 
	"LINK_INFO" VARCHAR2(100 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"LIST_COMMENT" VARCHAR2(4000 BYTE), 
	"FIX_WHERE" VARCHAR2(200 BYTE), 
	"LINK_ID" VARCHAR2(10 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_LOC" 
   (	"LOC_CODE" VARCHAR2(20 BYTE), 
	"LOC_NM" VARCHAR2(100 BYTE), 
	"UP_LOC_CODE" VARCHAR2(20 BYTE), 
	"LOC_TYPE" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"REMARKS" VARCHAR2(2000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_LOC_INFO" 
   (	"LOC_CODE" VARCHAR2(20 BYTE), 
	"LOC_NM" VARCHAR2(100 BYTE), 
	"UP_LOC_CODE" VARCHAR2(20 BYTE), 
	"LOC_TYPE" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"REMARKS" VARCHAR2(2000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_LOC_PLAN" 
   (	"LOC_PLAN_CODE" VARCHAR2(20 BYTE), 
	"LOC_CODE" VARCHAR2(20 BYTE), 
	"LOC_PLAN_X" NUMBER, 
	"LOC_PLAN_Y" NUMBER, 
	"REMARKS" VARCHAR2(2000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"LOC_PLAN_NM" VARCHAR2(200 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_MENU" 
   (	"MENU_ID" VARCHAR2(20 BYTE), 
	"MENU_NM" VARCHAR2(100 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MENU_DESC" VARCHAR2(1000 BYTE), 
	"UP_MENU_ID" VARCHAR2(20 BYTE), 
	"R_MENU_ID" VARCHAR2(20 BYTE), 
	"MENU_URL" VARCHAR2(100 BYTE), 
	"MENU_TYPE" VARCHAR2(8 BYTE), 
	"MENU_IMG" VARCHAR2(100 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_MENU_0303_2
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_MENU_0303_2" 
   (	"MENU_ID" VARCHAR2(20 BYTE), 
	"MENU_NM" VARCHAR2(100 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MENU_DESC" VARCHAR2(1000 BYTE), 
	"UP_MENU_ID" VARCHAR2(20 BYTE), 
	"R_MENU_ID" VARCHAR2(20 BYTE), 
	"MENU_URL" VARCHAR2(100 BYTE), 
	"MENU_TYPE" VARCHAR2(8 BYTE), 
	"MENU_IMG" VARCHAR2(100 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_MENU_TMP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_MENU_TMP" 
   (	"MENU_ID" VARCHAR2(20 BYTE), 
	"MENU_NM" VARCHAR2(100 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"MENU_DESC" VARCHAR2(1000 BYTE), 
	"UP_MENU_ID" VARCHAR2(20 BYTE), 
	"R_MENU_ID" VARCHAR2(20 BYTE), 
	"MENU_URL" VARCHAR2(100 BYTE), 
	"MENU_TYPE" VARCHAR2(8 BYTE), 
	"MENU_IMG" VARCHAR2(100 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_MODEL
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_MODEL" 
   (	"MODEL_ID" VARCHAR2(20 BYTE), 
	"MODEL_NM" VARCHAR2(100 BYTE), 
	"UP_MODEL_ID" VARCHAR2(20 BYTE), 
	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"REMARKS" VARCHAR2(2000 BYTE), 
	"VENDOR_NM" VARCHAR2(100 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_POPUP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_POPUP" 
   (	"POPUP_ID" NUMBER, 
	"POPUP_NM" VARCHAR2(50 BYTE), 
	"POPUP_DESC" VARCHAR2(4000 BYTE), 
	"POPUP_SCRIPT" VARCHAR2(4000 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_PROC_AUTH
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_PROC_AUTH" 
   (	"PROC_AUTH_ID" VARCHAR2(20 BYTE), 
	"PROC_AUTH_NM" VARCHAR2(100 BYTE), 
	"PROC_AUTH_DESC" VARCHAR2(2000 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_PROC_AUTH_TO_USERGRP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_PROC_AUTH_TO_USERGRP" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"PROC_AUTH_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_REQ_ZONE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_REQ_ZONE" 
   (	"CUST_ID" VARCHAR2(40 BYTE), 
	"CUST_NM" VARCHAR2(100 BYTE), 
	"UP_CUST_ID" VARCHAR2(40 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"USE_YN" CHAR(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_SCHEDULE
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_SCHEDULE" 
   (	"SCHEDULE_ID" VARCHAR2(20 BYTE), 
	"SCHEDULE_NM" VARCHAR2(200 BYTE), 
	"SCHEDULE_BEAN" VARCHAR2(200 BYTE), 
	"EXECUTE_METHOD" VARCHAR2(50 BYTE), 
	"CRONEXPRESSION" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"REMARKS" VARCHAR2(2000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_SCHEDULE_RESULT" 
   (	"SCHEDULE_ID" VARCHAR2(20 BYTE), 
	"IDX" NUMBER, 
	"SCHEDULE_NM" VARCHAR2(200 BYTE), 
	"EXECUTE_START_DT" DATE, 
	"EXECUTE_END_DT" DATE, 
	"EXECUTE_RESULT" VARCHAR2(20 BYTE), 
	"ERROR_MSG" VARCHAR2(4000 BYTE), 
	"SCHEDULE_EXECUTOR" VARCHAR2(40 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_SEARCH_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_SEARCH_INFO" 
   (	"LIST_ID" VARCHAR2(100 BYTE), 
	"SEQ" NUMBER, 
	"COLUMN_NM" VARCHAR2(100 BYTE), 
	"LABEL_NM" VARCHAR2(20 BYTE), 
	"FIELD_TYPE" VARCHAR2(100 BYTE), 
	"MERGE_YN" CHAR(1 BYTE), 
	"DETAIL_USED_YN" CHAR(1 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"TABLE_NM" VARCHAR2(20 BYTE), 
	"FIELD_TYPE_CONDITION" VARCHAR2(100 BYTE), 
	"FIELD_WIDTH" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_SEARCH_INFO_20150604" 
   (	"LIST_ID" VARCHAR2(100 BYTE), 
	"SEQ" NUMBER, 
	"COLUMN_NM" VARCHAR2(100 BYTE), 
	"LABEL_NM" VARCHAR2(20 BYTE), 
	"FIELD_TYPE" VARCHAR2(100 BYTE), 
	"MERGE_YN" CHAR(1 BYTE), 
	"DETAIL_USED_YN" CHAR(1 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"TABLE_NM" VARCHAR2(20 BYTE), 
	"FIELD_TYPE_CONDITION" VARCHAR2(100 BYTE), 
	"FIELD_WIDTH" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_SEARCH_INFO_BAK
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_SEARCH_INFO_BAK" 
   (	"LIST_ID" VARCHAR2(100 BYTE), 
	"SEQ" NUMBER, 
	"COLUMN_NM" VARCHAR2(20 BYTE), 
	"LABEL_NM" VARCHAR2(20 BYTE), 
	"FIELD_TYPE" VARCHAR2(100 BYTE), 
	"MERGE_YN" CHAR(1 BYTE), 
	"DETAIL_USED_YN" CHAR(1 BYTE), 
	"DISPLAY_NO" NUMBER, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"TABLE_NM" VARCHAR2(20 BYTE), 
	"FIELD_TYPE_CONDITION" VARCHAR2(100 BYTE), 
	"FIELD_WIDTH" VARCHAR2(5 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_SEQ
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_SEQ" 
   (	"TABLE_NAME" VARCHAR2(20 BYTE), 
	"NEXT_ID" NUMBER(30,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_SYSTEM_TO_USER
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_SYSTEM_TO_USER" 
   (	"SYSTEM_ID" VARCHAR2(20 BYTE), 
	"SUB_SYSTEM_ID" VARCHAR2(20 BYTE), 
	"USER_ID" VARCHAR2(40 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_TABLE_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_TABLE_INFO" 
   (	"LIST_ID" VARCHAR2(100 BYTE), 
	"SEQ" NUMBER, 
	"SCHEMA_NM" VARCHAR2(200 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   )  TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_TRG_LOG" 
   (	"TRG_NAME" VARCHAR2(100 BYTE), 
	"RESULT_MSG" VARCHAR2(500 BYTE), 
	"SQL_ERROR_CODE" VARCHAR2(200 BYTE), 
	"SQL_ERROR_MSG" VARCHAR2(500 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_USER" 
   (	"USER_ID" VARCHAR2(40 BYTE), 
	"PW" VARCHAR2(300 BYTE), 
	"USER_NM" VARCHAR2(100 BYTE), 
	"CUST_OP_TYPE" VARCHAR2(8 BYTE), 
	"SID" CHAR(13 BYTE), 
	"TEL_NO" VARCHAR2(20 BYTE), 
	"HP_NO" VARCHAR2(20 BYTE), 
	"EMAIL" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE) DEFAULT 'Y', 
	"ABSENT_ID" VARCHAR2(40 BYTE), 
	"POSITION" VARCHAR2(40 BYTE), 
	"EMP_ID" VARCHAR2(40 BYTE), 
	"FAX_NO" VARCHAR2(20 BYTE), 
	"REL_PATH" VARCHAR2(8 BYTE), 
	"MSG_ID" VARCHAR2(40 BYTE), 
	"ESIGN_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE DEFAULT SYSDATE, 
	"HOME_TEL_NO" VARCHAR2(40 BYTE), 
	"TEL_EXT" VARCHAR2(20 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"ABSENT_SDT" DATE, 
	"ABSENT_EDT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"NPKI_DN" VARCHAR2(200 BYTE), 
	"EXTERNAL_YN" VARCHAR2(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_USERGRP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_USERGRP" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"USER_GRP_NM" VARCHAR2(100 BYTE), 
	"USE_YN" CHAR(1 BYTE) DEFAULT 'Y', 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE DEFAULT SYSDATE, 
	"UP_USER_GRP_ID" VARCHAR2(20 BYTE), 
	"R_USER_GRP_ID" VARCHAR2(20 BYTE), 
	"USER_CLASS" VARCHAR2(40 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_USERGRP_TO_AUTH
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_USERGRP_TO_AUTH" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"AUTH_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_USERGRP_TO_USER
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_USERGRP_TO_USER" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"USER_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_USERGRP_TO_USER_TMP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_USERGRP_TO_USER_TMP" 
   (	"USER_GRP_ID" VARCHAR2(20 BYTE), 
	"USER_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_USER_PW_HISTORY
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_USER_PW_HISTORY" 
   (	"UPD_DT" DATE DEFAULT SYSDATE, 
	"OLD_PW" VARCHAR2(300 BYTE), 
	"NEW_PW" VARCHAR2(300 BYTE), 
	"USER_ID" VARCHAR2(40 BYTE), 
	"UPD_ID" VARCHAR2(20 BYTE), 
	"NO" NUMBER, 
	"UPD_POPUP_SHOW" VARCHAR2(5 BYTE), 
	"UPD_POPUP_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_USER_QRY
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_USER_QRY" 
   (	"QRY_NO" VARCHAR2(200 BYTE), 
	"QRY_NM" VARCHAR2(100 BYTE), 
	"QRY_CONTENT" VARCHAR2(4000 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_USER_REQ
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_USER_REQ" 
   (	"CUST_ID" VARCHAR2(40 BYTE), 
	"USER_CLASS" VARCHAR2(8 BYTE), 
	"USER_ID" VARCHAR2(40 BYTE), 
	"USER_NM" VARCHAR2(100 BYTE), 
	"PW" VARCHAR2(300 BYTE), 
	"SERIAL_NUMBER" VARCHAR2(40 BYTE), 
	"POSITION" VARCHAR2(40 BYTE), 
	"EMAIL" VARCHAR2(40 BYTE), 
	"HP_NO" VARCHAR2(20 BYTE), 
	"HOME_TEL_NO" VARCHAR2(40 BYTE), 
	"FAX_NO" VARCHAR2(20 BYTE), 
	"TEL_EXT" VARCHAR2(20 BYTE), 
	"REQ_CAUSE" VARCHAR2(200 BYTE), 
	"CHARGER" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"APP_YN" VARCHAR2(8 BYTE), 
	"REJECT" VARCHAR2(2000 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_USER_TMP
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_USER_TMP" 
   (	"USER_ID" VARCHAR2(40 BYTE), 
	"PW" VARCHAR2(300 BYTE), 
	"USER_NM" VARCHAR2(100 BYTE), 
	"CUST_OP_TYPE" VARCHAR2(8 BYTE), 
	"SID" CHAR(13 BYTE), 
	"TEL_NO" VARCHAR2(20 BYTE), 
	"HP_NO" VARCHAR2(20 BYTE), 
	"EMAIL" VARCHAR2(40 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"ABSENT_ID" VARCHAR2(40 BYTE), 
	"POSITION" VARCHAR2(40 BYTE), 
	"EMP_ID" VARCHAR2(40 BYTE), 
	"FAX_NO" VARCHAR2(20 BYTE), 
	"REL_PATH" VARCHAR2(8 BYTE), 
	"MSG_ID" VARCHAR2(40 BYTE), 
	"ESIGN_ID" VARCHAR2(40 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"HOME_TEL_NO" VARCHAR2(40 BYTE), 
	"TEL_EXT" VARCHAR2(20 BYTE), 
	"CUST_ID" VARCHAR2(40 BYTE), 
	"ABSENT_SDT" DATE, 
	"ABSENT_EDT" DATE, 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE, 
	"NPKI_DN" VARCHAR2(200 BYTE), 
	"EXTERNAL_YN" VARCHAR2(1 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table SYS_VENDOR
--------------------------------------------------------

  CREATE TABLE "ITSM"."SYS_VENDOR" 
   (	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"VENDOR_NM" VARCHAR2(100 BYTE), 
	"BIZ_NO" VARCHAR2(40 BYTE), 
	"CDE_NM" VARCHAR2(100 BYTE), 
	"VENDOR_FAX_NO" VARCHAR2(20 BYTE), 
	"VENDOR_TEL_NO" VARCHAR2(20 BYTE), 
	"VENDOR_EMAIL" VARCHAR2(40 BYTE), 
	"VENDOR_ADDR" VARCHAR2(200 BYTE), 
	"HOME_PAGE" VARCHAR2(100 BYTE), 
	"SALES_USER_NM" VARCHAR2(100 BYTE), 
	"SALES_USER_TEL" VARCHAR2(20 BYTE), 
	"SALES_USER_EMAIL" VARCHAR2(40 BYTE), 
	"TECH_USER_NM" VARCHAR2(100 BYTE), 
	"TECH_USER_TEL" VARCHAR2(20 BYTE), 
	"TECH_USER_EMAIL" VARCHAR2(40 BYTE), 
	"VENDOR_DESC" VARCHAR2(1000 BYTE), 
	"USE_YN" CHAR(1 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"VENDOR_USER_ID" VARCHAR2(40 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."SYS_VENDOR_TYPE" 
   (	"VENDOR_TYPE" VARCHAR2(8 BYTE), 
	"VENDOR_ID" VARCHAR2(20 BYTE), 
	"UPD_USER_ID" VARCHAR2(40 BYTE), 
	"UPD_DT" DATE, 
	"AS_FLAG" VARCHAR2(3 BYTE), 
	"SALE_FLAG" VARCHAR2(3 BYTE), 
	"PT_FLAG" VARCHAR2(3 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."TARGET_SCORE" 
   (	"CUST_ID" VARCHAR2(40 BYTE), 
	"START_YM" VARCHAR2(6 BYTE), 
	"END_YM" VARCHAR2(6 BYTE), 
	"TARGET_SCORE" VARCHAR2(20 BYTE), 
	"INS_USER_ID" VARCHAR2(40 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK" 
   (	"ID" NUMBER(19,0), 
	"ARCHIVED" NUMBER(5,0), 
	"ALLOWEDTODELEGATE" VARCHAR2(255 BYTE), 
	"PRIORITY" NUMBER(10,0), 
	"ACCEPTTIME" DATE, 
	"ACTIVATIONTIME" DATE, 
	"COMPLETEDON" DATE, 
	"CREATEDON" DATE, 
	"DOCUMENTACCESSTYPE" NUMBER(10,0), 
	"DOCUMENTCONTENTID" NUMBER(19,0), 
	"DOCUMENTTYPE" VARCHAR2(255 BYTE), 
	"EMAILSENDED" VARCHAR2(255 BYTE), 
	"EXPIRATIONTIME" DATE, 
	"FAULTACCESSTYPE" NUMBER(10,0), 
	"FAULTCONTENTID" NUMBER(19,0), 
	"FAULTNAME" VARCHAR2(255 BYTE), 
	"FAULTTYPE" VARCHAR2(255 BYTE), 
	"NODEID" VARCHAR2(255 BYTE), 
	"OUTPUTACCESSTYPE" NUMBER(10,0), 
	"OUTPUTCONTENTID" NUMBER(19,0), 
	"OUTPUTTYPE" VARCHAR2(255 BYTE), 
	"PARENTID" NUMBER(19,0), 
	"PREVIOUSSTATUS" NUMBER(10,0), 
	"PROCESSID" VARCHAR2(255 BYTE), 
	"PROCESSINSTANCEID" NUMBER(19,0), 
	"PROCESSSESSIONID" NUMBER(10,0), 
	"READED" VARCHAR2(255 BYTE), 
	"REJECTED" VARCHAR2(255 BYTE), 
	"SKIPABLE" NUMBER(1,0), 
	"STATUS" VARCHAR2(255 BYTE), 
	"TASK_NAME" VARCHAR2(255 BYTE), 
	"WORKITEMID" NUMBER(19,0), 
	"OPTLOCK" NUMBER(10,0), 
	"TASKINITIATOR_ID" VARCHAR2(255 BYTE), 
	"ACTUALOWNER_ID" VARCHAR2(255 BYTE), 
	"CREATEDBY_ID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_COMMENT
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_COMMENT" 
   (	"ID" NUMBER(19,0), 
	"ADDEDAT" DATE, 
	"TASK_NAME" VARCHAR2(255 BYTE), 
	"TEXT" CLOB, 
	"ADDEDBY_ID" VARCHAR2(255 BYTE), 
	"TASKDATA_COMMENTS_ID" NUMBER(19,0)
   ) TABLESPACE "ITSM"  ;
--------------------------------------------------------
--  DDL for Table TASK_CONFIRM
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_CONFIRM" 
   (	"CONFIRMMESSAGE" VARCHAR2(4000 CHAR), 
	"MAILNOTI" NUMBER(1,0), 
	"ROLELIST" VARCHAR2(4000 CHAR), 
	"SMSNOTI" NUMBER(1,0), 
	"USERLIST" VARCHAR2(4000 CHAR), 
	"ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_EXECUTE
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_EXECUTE" 
   (	"ARGUMENTS" VARCHAR2(4000 CHAR), 
	"ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_EXPRESSION
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_EXPRESSION" 
   (	"EXPRESSION" VARCHAR2(4000 CHAR), 
	"ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_GROUP
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_GROUP" 
   (	"TASKTHREADS" NUMBER(10,0), 
	"ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_GROUP_TASK_ROOT
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_GROUP_TASK_ROOT" 
   (	"TASK_GROUP_ID" NUMBER(10,0), 
	"SUBTASKS_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_REBOOT
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_REBOOT" 
   (	"ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_ROOT
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_ROOT" 
   (	"ID" NUMBER(10,0), 
	"COMPARISONMESSAGE" VARCHAR2(4000 CHAR), 
	"CONTAINSMESSAGE" NUMBER(1,0), 
	"DESCRIPTION" VARCHAR2(4000 CHAR), 
	"DISABLE" NUMBER(1,0), 
	"NAME" VARCHAR2(255 CHAR), 
	"ERR_FLOWTYPE" NUMBER(10,0), 
	"ERR_LIMITWAITCOUNT" NUMBER(10,0), 
	"ERR_LIMITWAITFLOWTYPE" NUMBER(10,0), 
	"ERR_ROLELIST" VARCHAR2(4000 CHAR), 
	"ERR_SENDMAIL" NUMBER(1,0), 
	"ERR_SENDSMS" NUMBER(1,0), 
	"ERR_USERLIST" VARCHAR2(4000 CHAR), 
	"ERR_WAITTIME" NUMBER(10,0), 
	"SUCC_FLOWTYPE" NUMBER(10,0), 
	"SUCC_LIMITWAITCOUNT" NUMBER(10,0), 
	"SUCC_LIMITWAITFLOWTYPE" NUMBER(10,0), 
	"SUCC_ROLELIST" VARCHAR2(4000 CHAR), 
	"SUCC_SENDMAIL" NUMBER(1,0), 
	"SUCC_SENDSMS" NUMBER(1,0), 
	"SUCC_USERLIST" VARCHAR2(4000 CHAR), 
	"SUCC_WAITTIME" NUMBER(10,0), 
	"OUTPUTCHECK" NUMBER(1,0), 
	"RUNCHECK" NUMBER(1,0), 
	"SLEEPTIME" NUMBER(10,0), 
	"TASKGROUP" NUMBER(10,0), 
	"TASKORDER" NUMBER(10,0), 
	"TASKTYPE" VARCHAR2(255 CHAR), 
	"TIMEOUT" NUMBER(10,0), 
	"ERR_GOTOTASK_ID" NUMBER(10,0), 
	"SUCC_GOTOTASK_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_SET_VARIABLES
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_SET_VARIABLES" 
   (	"ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_SET_VARIABLES_DETAIL
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_SET_VARIABLES_DETAIL" 
   (	"TASK_ID" NUMBER(10,0), 
	"VAR_KEY" VARCHAR2(255 CHAR), 
	"VAR_VALUE" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_SHUTDOWN
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_SHUTDOWN" 
   (	"ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_SMS
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_SMS" 
   (	"MESSAGE" VARCHAR2(4000 CHAR), 
	"RECEIVER" VARCHAR2(4000 CHAR), 
	"ROLELIST" VARCHAR2(4000 CHAR), 
	"USERLIST" VARCHAR2(4000 CHAR), 
	"ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TASK_WAIT
--------------------------------------------------------

  CREATE TABLE "ITSM"."TASK_WAIT" 
   (	"HOURS" NUMBER(10,0), 
	"MILLISECONDS" NUMBER(10,0), 
	"MINUTES" NUMBER(10,0), 
	"SECONDS" NUMBER(10,0), 
	"ID" NUMBER(10,0)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TEST_AM_ASSET
--------------------------------------------------------

  CREATE TABLE "ITSM"."TEST_AM_ASSET" 
   (	"TEST_ASSET_ID" VARCHAR2(20 BYTE), 
	"TEST_ASSET_NM" VARCHAR2(300 BYTE), 
	"CONF_ID" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."TEST_AM_INFRA" 
   (	"TEST_CONF_NM" VARCHAR2(300 BYTE), 
	"TEST_CONF_ID" VARCHAR2(20 BYTE), 
	"TEST_CONF_DATE" DATE, 
	"CONF_ID" VARCHAR2(1 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."THRESHOLD_PROFILE" 
   (	"THRESHOLD_ID" NUMBER(10,0), 
	"NAME" VARCHAR2(255 CHAR), 
	"DESCRIPTION" VARCHAR2(4000 CHAR), 
	"THRESHOLD_TYPE" NUMBER(10,0), 
	"TARGET_ATTRIBUTE_CODE" VARCHAR2(4000 CHAR)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table THRESHOLD_RULE
--------------------------------------------------------

  CREATE TABLE "ITSM"."THRESHOLD_RULE" 
   (	"RULE_ID" NUMBER(10,0), 
	"SEVERITY" NUMBER(10,0), 
	"COMPARISON_METHOD" VARCHAR2(255 CHAR), 
	"STRING_THRESHOLD" VARCHAR2(4000 CHAR), 
	"NUMERIC_THRESHOLD" FLOAT(126), 
	"CONSECUTIVE_TIMES" NUMBER(10,0), 
	"THRESHOLD_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TMP_KYSONG_LIST
--------------------------------------------------------

  CREATE TABLE "ITSM"."TMP_KYSONG_LIST" 
   (	"SR_ID" VARCHAR2(255 BYTE), 
	"REQUESTER_ID" VARCHAR2(255 BYTE), 
	"MANAGER_ID" VARCHAR2(320 BYTE), 
	"WORKER_ID" VARCHAR2(255 BYTE), 
	"TITLE" VARCHAR2(255 BYTE), 
	"CONTENT" VARCHAR2(255 BYTE), 
	"WORK_STATE" VARCHAR2(255 BYTE), 
	"REG_DT" DATE, 
	"DUE_DT" DATE, 
	"COMPLETE_DT" DATE, 
	"SERVICE_TYPE" VARCHAR2(255 BYTE), 
	"SYSTEM_TYPE" VARCHAR2(255 BYTE), 
	"SUB_WORK" VARCHAR2(255 BYTE), 
	"WORK_FG" VARCHAR2(1 BYTE)
   ) TABLESPACE "ITSM" ;

  CREATE TABLE "ITSM"."TS_ORG_INFO" 
   (	"CUST_ID" VARCHAR2(96 BYTE), 
	"CUST_NM" VARCHAR2(768 BYTE), 
	"CUST_PARENT_ID" VARCHAR2(96 BYTE), 
	"CUST_ORDER" NUMBER(8,0), 
	"TEL_NO" VARCHAR2(60 BYTE), 
	"FAX_NO" VARCHAR2(60 BYTE), 
	"USE_YN" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TS_USER_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."TS_USER_INFO" 
   (	"USER_ID" VARCHAR2(96 BYTE), 
	"USER_NM" VARCHAR2(192 BYTE), 
	"TEL_NO" VARCHAR2(60 BYTE), 
	"HP_NO" VARCHAR2(60 BYTE), 
	"EMAIL" VARCHAR2(150 BYTE), 
	"POSITION" VARCHAR2(192 BYTE), 
	"FAX_NO" VARCHAR2(60 BYTE), 
	"CUST_ID" VARCHAR2(96 BYTE), 
	"CUST_NM" VARCHAR2(768 BYTE), 
	"USE_YN" VARCHAR2(3 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TX_TEST
--------------------------------------------------------

  CREATE TABLE "ITSM"."TX_TEST" 
   (	"ID" VARCHAR2(1 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table TX_TEST2
--------------------------------------------------------

  CREATE TABLE "ITSM"."TX_TEST2" 
   (	"ID" VARCHAR2(1 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"INS_DT" DATE
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table USER_TEST
--------------------------------------------------------

  CREATE TABLE "ITSM"."USER_TEST" 
   (	"USER_ID" VARCHAR2(20 BYTE), 
	"TEL" VARCHAR2(20 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VARIABLEINSTANCELOG
--------------------------------------------------------

  CREATE TABLE "ITSM"."VARIABLEINSTANCELOG" 
   (	"ID" NUMBER(19,0), 
	"LOG_DATE" DATE, 
	"PROCESSID" VARCHAR2(255 BYTE), 
	"PROCESSINSTANCEID" NUMBER(19,0), 
	"VALUE" VARCHAR2(255 BYTE), 
	"VARIABLEID" VARCHAR2(255 BYTE), 
	"VARIABLEINSTANCEID" VARCHAR2(255 BYTE)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_CLUSTER
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_CLUSTER" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"DATACENTERNAME" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_DATACENTER
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_DATACENTER" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"INNERNAME" VARCHAR2(255 CHAR), 
	"SYNCHNAME" NUMBER(1,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_DISK_PERFORMANCE_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_DISK_PERFORMANCE_DATA" 
   (	"INNERID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"LIVE_OBJECT_NAME" VARCHAR2(255 CHAR), 
	"SIMPLE_NAME" VARCHAR2(255 CHAR), 
	"VMINNERID" VARCHAR2(255 CHAR), 
	"HOSTID" NUMBER(10,0), 
	"UUID" VARCHAR2(255 CHAR), 
	"SRUUID" VARCHAR2(255 CHAR), 
	"CLUSTERID" NUMBER(10,0), 
	"DISKTOTALSIZE" FLOAT(126), 
	"TYPE" VARCHAR2(255 CHAR), 
	"DESCRITPTION" VARCHAR2(255 CHAR), 
	"VMNAME" VARCHAR2(255 CHAR), 
	"VMID" NUMBER(10,0), 
	"STORAGEID" NUMBER(10,0), 
	"STORAGENAME" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_HOST
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_HOST" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"IS_MASTER_HOST" NUMBER(1,0), 
	"DCA_AGENT_ID" VARCHAR2(255 CHAR), 
	"CLUSTERNAME" VARCHAR2(255 CHAR), 
	"DATACENTERNAME" VARCHAR2(255 CHAR), 
	"IP" VARCHAR2(255 CHAR), 
	"SERIALNUMBER" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_HOST_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_HOST_DATA" 
   (	"INNERID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"STACKMANAGEDOBJECTKEY" VARCHAR2(255 CHAR), 
	"MANAGINGKEY" VARCHAR2(255 CHAR), 
	"NAME" VARCHAR2(255 CHAR), 
	"CLUSTERNAME" VARCHAR2(255 CHAR), 
	"DATACENTERNAME" VARCHAR2(255 CHAR), 
	"DCAAGENTID" VARCHAR2(255 CHAR), 
	"DESCRIPTION" VARCHAR2(255 CHAR), 
	"CLUSTERID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_HOST_PERFORMANCE_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_HOST_PERFORMANCE_DATA" 
   (	"MANAGED_OBJECT_ID" NUMBER(10,0), 
	"DATACENTERID" NUMBER(10,0), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"INNERID" VARCHAR2(255 CHAR), 
	"LIVEOBJECTNAME" VARCHAR2(255 CHAR), 
	"SIMPLENAME" VARCHAR2(255 CHAR), 
	"CLUSTERID" NUMBER(10,0), 
	"STATUS" VARCHAR2(255 CHAR), 
	"VMTOTALCNT" NUMBER(10,0), 
	"CPUCORECNT" NUMBER(10,0), 
	"CPUMODEL" VARCHAR2(255 CHAR), 
	"CPUUTILIZATION" FLOAT(126), 
	"MEMUTILIZATION" FLOAT(126), 
	"MEMTOTALSIZE" FLOAT(126), 
	"MEMUSEDSIZE" FLOAT(126), 
	"MEMFREESIZE" FLOAT(126), 
	"NETWORKUTILIZATION" FLOAT(126), 
	"VMACTIVECNT" NUMBER(10,0), 
	"VCORECNT" NUMBER(10,0), 
	"MEMALLOCATEDSIZE" FLOAT(126), 
	"STORAGEALLOCATEDSIZE" FLOAT(126), 
	"IP" VARCHAR2(255 CHAR), 
	"MEMVIRTUALIZATIONRATE" FLOAT(126), 
	"CPUVIRTUALIZATIONRATE" FLOAT(126), 
	"NICCNT" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_HOST_PERFZEN_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_HOST_PERFZEN_DATA" 
   (	"INNER_ID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"LIVEOBJECTNAME" VARCHAR2(255 CHAR), 
	"SIMPLENAME" VARCHAR2(255 CHAR), 
	"CLUSTERID" NUMBER(10,0), 
	"STATUS" VARCHAR2(255 CHAR), 
	"VMTOTALCNT" NUMBER(10,0), 
	"CPUCORECNT" NUMBER(10,0), 
	"CPUMODEL" VARCHAR2(255 CHAR), 
	"CPUUTILIZATION" FLOAT(126), 
	"MEMUTILIZATION" FLOAT(126), 
	"MEMTOTALSIZE" FLOAT(126), 
	"MEMUSEDSIZE" FLOAT(126), 
	"MEMFREESIZE" FLOAT(126), 
	"NETWORKUTILIZATION" FLOAT(126), 
	"VMACTIVECNT" NUMBER(10,0), 
	"VCORECNT" NUMBER(10,0), 
	"MEMALLOCATEDSIZE" FLOAT(126), 
	"STORAGEALLOCATEDSIZE" FLOAT(126), 
	"IP" VARCHAR2(255 CHAR), 
	"MEMVIRTUALIZATIONRATE" FLOAT(126), 
	"CPUVIRTUALIZATIONRATE" FLOAT(126), 
	"NICCNT" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_NETWORKIF_PERF_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_NETWORKIF_PERF_DATA" 
   (	"INNERID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"LIVEOBJECTNAME" VARCHAR2(255 CHAR), 
	"SIMPLENAME" VARCHAR2(255 CHAR), 
	"HOSTID" NUMBER(10,0), 
	"CLUSTERID" NUMBER(10,0), 
	"UUID" VARCHAR2(255 CHAR), 
	"MANAGED_OBJECT_ID" NUMBER(10,0), 
	"MACADDRESS" VARCHAR2(255 CHAR), 
	"IP" VARCHAR2(255 CHAR), 
	"NETWORKNAME" VARCHAR2(255 CHAR), 
	"BANDWIDTH" FLOAT(126)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_REGISTERED_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_REGISTERED_OBJECT" 
   (	"REGISTERED_OBJECT_ID" NUMBER(10,0), 
	"GATHER_DATE" TIMESTAMP (6), 
	"GATHER_RESULT" NUMBER(10,0), 
	"GATHER_FAIL_CAUSE" VARCHAR2(255 CHAR), 
	"REGISTERED_NAME" VARCHAR2(255 CHAR), 
	"DBURL" VARCHAR2(255 CHAR), 
	"DBID" VARCHAR2(255 CHAR), 
	"DBPASSWD" VARCHAR2(255 CHAR), 
	"WEBURL" VARCHAR2(255 CHAR), 
	"WEBID" VARCHAR2(255 CHAR), 
	"WEBPASSWD" VARCHAR2(255 CHAR), 
	"PROVIDERHOSTIP" VARCHAR2(255 CHAR), 
	"PROVIDERHOSTACCOUNTID" VARCHAR2(255 CHAR), 
	"REGISTEREDDATE" TIMESTAMP (6), 
	"UPDATEDATE" TIMESTAMP (6), 
	"VIRTUALIZATIONTYPE" VARCHAR2(255 CHAR), 
	"PROVIDERHOSTACCOUNTPASSWD" VARCHAR2(255 CHAR), 
	"DATACENTERNAME" VARCHAR2(255 CHAR), 
	"AGENTKEY" VARCHAR2(255 CHAR), 
	"MASTERHOST" NUMBER(1,0), 
	"MANAGERGROUP" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"LOCALAGENT" NUMBER(1,0), 
	"OBJECT_ID" NUMBER(10,0), 
	"MANAGERID" VARCHAR2(255 CHAR), 
	"VIRTUALIZATIONVERSION" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_STORAGE
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_STORAGE" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"DATACENTERNAME" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_STORAGEDATA_VIRTUALOBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_STORAGEDATA_VIRTUALOBJECT" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"INNERID" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_STORAGE_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_STORAGE_DATA" 
   (	"INNERID" VARCHAR2(255 CHAR), 
	"STACKMANAGEDOBJECTKEY" VARCHAR2(255 CHAR), 
	"MANAGINGKEY" VARCHAR2(255 CHAR), 
	"DATACENTERNAME" VARCHAR2(255 CHAR), 
	"NAME" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"UUID" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_STORAGE_PERFORMANCE_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_STORAGE_PERFORMANCE_DATA" 
   (	"INNERID" VARCHAR2(255 CHAR), 
	"MANAGEDOBJECTID" NUMBER(10,0), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"TOTALSIZE" FLOAT(126), 
	"FREESIZE" FLOAT(126), 
	"TYPE" VARCHAR2(255 CHAR), 
	"USEDSIZE" FLOAT(126), 
	"DISKUTILIZATION" FLOAT(126), 
	"VIRTUALDISKCNT" FLOAT(126), 
	"TEMPLATEDISKCNT" FLOAT(126), 
	"DISKALLOCATEDRATE" FLOAT(126), 
	"DISKALLOCATEDSIZE" FLOAT(126)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_STORAGE_VIRTUALOBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_STORAGE_VIRTUALOBJECT" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"STORAGE_OBJECT_ID" NUMBER(10,0)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_TEMP_DISK_PERF_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_TEMP_DISK_PERF_DATA" 
   (	"INNERID" VARCHAR2(255 CHAR), 
	"GUID" VARCHAR2(255 CHAR), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"STORAGEUUID" VARCHAR2(255 CHAR), 
	"MANAGED_OBJECT_ID" NUMBER(10,0), 
	"DISKTOTALSIZE" FLOAT(126), 
	"LIVE_OBJECT_NAME" VARCHAR2(255 CHAR), 
	"SIMPLE_NAME" VARCHAR2(255 CHAR), 
	"DESCRIPTION" VARCHAR2(255 CHAR), 
	"VMTGUID" VARCHAR2(255 CHAR), 
	"DISKTYPE" VARCHAR2(255 CHAR), 
	"STORAGEID" NUMBER(10,0), 
	"STORAGENAME" VARCHAR2(255 CHAR), 
	"TEMPLATENAME" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_TEMP_PERF_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_TEMP_PERF_DATA" 
   (	"INNERID" VARCHAR2(255 CHAR), 
	"GUID" VARCHAR2(255 CHAR), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"MANAGED_OBJECT_ID" NUMBER(10,0), 
	"STACK_KEY" VARCHAR2(255 CHAR), 
	"MEMTOTALSIZE" FLOAT(126), 
	"CORECNT" NUMBER(10,0), 
	"DISKTOTALSIZE" FLOAT(126), 
	"DESCRIPTION" VARCHAR2(255 CHAR), 
	"OS" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_VIRTUAL_MANAGED_OBJECT
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_VIRTUAL_MANAGED_OBJECT" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"STACKMANAGEDOBJECTKEY" VARCHAR2(255 CHAR), 
	"VIRTUALIZATIONTYPE" VARCHAR2(255 CHAR), 
	"DATACENTER_ID" NUMBER(10,0), 
	"CLUSTER_ID" NUMBER(10,0), 
	"REGISTERED_OBJECT_ID" NUMBER(10,0), 
	"INNERID" VARCHAR2(255 CHAR), 
	"PARENTSTACKMANAGEDOBJECTKEY" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_VM
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_VM" 
   (	"OBJECT_ID" NUMBER(10,0), 
	"DATACENTERNAME" VARCHAR2(255 CHAR), 
	"CLUSTERNAME" VARCHAR2(255 CHAR), 
	"HOSTNAME" VARCHAR2(255 CHAR), 
	"HOSTID" NUMBER(10,0), 
	"DNSNAME" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_VM_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_VM_DATA" 
   (	"INNERID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"STACKMANAGEDOBJECTKEY" VARCHAR2(255 CHAR), 
	"MANAGINGKEY" VARCHAR2(255 CHAR), 
	"NAME" VARCHAR2(255 CHAR), 
	"HOSTID" NUMBER(10,0), 
	"HOSTNAME" VARCHAR2(255 CHAR), 
	"CLUSTERID" NUMBER(10,0), 
	"UUID" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_VM_PERFORMANCE_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_VM_PERFORMANCE_DATA" 
   (	"VMINNERID" VARCHAR2(255 CHAR), 
	"INNERID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"LIVEOBJECTNAME" VARCHAR2(255 CHAR), 
	"SIMPLENAME" VARCHAR2(255 CHAR), 
	"HOSTID" NUMBER(10,0), 
	"CLUSTERID" NUMBER(10,0), 
	"IP" VARCHAR2(255 CHAR), 
	"STATUS" VARCHAR2(255 CHAR), 
	"OS" VARCHAR2(255 CHAR), 
	"CPUUTILIZATION" FLOAT(126), 
	"MEMUTILIZATION" FLOAT(126), 
	"MEMTOTALSIZE" FLOAT(126), 
	"MEMUSEDSIZE" FLOAT(126), 
	"MEMFREESIZE" FLOAT(126), 
	"NETWORKUTILIZATION" FLOAT(126), 
	"VCORECNT" NUMBER(10,0), 
	"DISKTOTALSIZE" FLOAT(126), 
	"BOOTUPTIME" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table VR_VNETWORKIF_PERF_DATA
--------------------------------------------------------

  CREATE TABLE "ITSM"."VR_VNETWORKIF_PERF_DATA" 
   (	"INNERID" VARCHAR2(255 CHAR), 
	"DATACENTERID" NUMBER(10,0), 
	"PARENTINNERID" VARCHAR2(255 CHAR), 
	"LIVEOBJECTNAME" VARCHAR2(255 CHAR), 
	"SIMPLENAME" VARCHAR2(255 CHAR), 
	"MACADDRESS" VARCHAR2(255 CHAR), 
	"NETWORKNAME" VARCHAR2(255 CHAR), 
	"VMINNERID" VARCHAR2(255 CHAR), 
	"HOSTID" NUMBER(10,0), 
	"CLUSTERID" NUMBER(10,0), 
	"UUID" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table WINDOWS_UPDATE_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."WINDOWS_UPDATE_INFO" 
   (	"INFO_ID" NUMBER(*,0), 
	"DEVICE_ID" NUMBER(*,0), 
	"UPDATE_ID" VARCHAR2(255 BYTE), 
	"ANALYSIS_DATE" TIMESTAMP (6), 
	"IS_INSTALLED" NUMBER(1,0), 
	"IS_EXCLUDED" NUMBER(1,0), 
	"INSTALL_DATE" TIMESTAMP (6)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table WINDOWS_UPDATE_INFO_ABNORMAL
--------------------------------------------------------

  CREATE TABLE "ITSM"."WINDOWS_UPDATE_INFO_ABNORMAL" 
   (	"DEVICE_ID" NUMBER(10,0), 
	"ANALYSIS_DATE" TIMESTAMP (6), 
	"IS_INSTALLED" NUMBER(1,0), 
	"INSTALL_DATE" TIMESTAMP (6), 
	"ANALYSIS_STATUS" VARCHAR2(255 CHAR)
   ) TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table WINDOWS_UPDATE_MASTER_INFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."WINDOWS_UPDATE_MASTER_INFO" 
   (	"UPDATE_ID" VARCHAR2(255 BYTE), 
	"KB_ARTICLE_ID" VARCHAR2(255 BYTE), 
	"PRODUCT" VARCHAR2(255 BYTE), 
	"BULLETIN_ID" VARCHAR2(255 BYTE), 
	"SEVERITY" VARCHAR2(255 BYTE), 
	"TITLE" VARCHAR2(255 BYTE), 
	"CATEGORY" VARCHAR2(255 BYTE), 
	"IS_RESTART" NUMBER(1,0), 
	"PUBLISHED_DATE" TIMESTAMP (6), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"DOWNLOAD_URL" VARCHAR2(255 BYTE), 
	"DOWNLOAD_SIZE" NUMBER(*,0), 
	"INFO_URL" VARCHAR2(255 BYTE), 
	"IS_MASTER_EXCLUDED" NUMBER(1,0), 
	"IS_INTERACTIVE_MODE" NUMBER(1,0), 
	"UPDATE_TYPE" VARCHAR2(255 BYTE)
   )  TABLESPACE "ITSM" ;
--------------------------------------------------------
--  DDL for Table WORKITEMINFO
--------------------------------------------------------

  CREATE TABLE "ITSM"."WORKITEMINFO" 
   (	"WORKITEMID" NUMBER(19,0), 
	"CREATIONDATE" DATE, 
	"NAME" VARCHAR2(255 BYTE), 
	"PROCESSINSTANCEID" NUMBER(19,0), 
	"STATE" NUMBER(19,0), 
	"OPTLOCK" NUMBER(10,0), 
	"WORKITEMBYTEARRAY" BLOB
   ) TABLESPACE "ITSM"  ;
